package com.google.android.gms.internal;

import java.util.Map;

public class zzbsu {
    private final String zzbxW;
    private final Map<String, Object> zzcky;

    public zzbsu(String str, Map<String, Object> map) {
        this.zzbxW = str;
        this.zzcky = map;
    }

    public static zzbsu zzjd(String str) {
        if (!str.startsWith("gauth|")) {
            return null;
        }
        try {
            Map zzje = zzbsv.zzje(str.substring("gauth|".length()));
            return new zzbsu((String) zzje.get("token"), (Map) zzje.get("auth"));
        } catch (Throwable e) {
            throw new RuntimeException("Failed to parse gauth token", e);
        }
    }

    public String getToken() {
        return this.zzbxW;
    }

    public Map<String, Object> zzabJ() {
        return this.zzcky;
    }
}
