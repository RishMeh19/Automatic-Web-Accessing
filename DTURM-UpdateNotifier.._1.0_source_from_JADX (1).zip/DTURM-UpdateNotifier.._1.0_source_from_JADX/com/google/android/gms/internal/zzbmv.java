package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.annotation.Nullable;
import com.google.android.gms.common.internal.safeparcel.zza;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class zzbmv extends zza {
    public static final Creator<zzbmv> CREATOR = new zzbmw();
    @zzbmb
    public final int zzaiI;
    @zzbvv("values")
    private List<String> zzbYO;

    public zzbmv() {
        this(null);
    }

    zzbmv(int i, List<String> list) {
        this.zzaiI = i;
        if (list == null || list.isEmpty()) {
            this.zzbYO = Collections.emptyList();
        } else {
            this.zzbYO = Collections.unmodifiableList(list);
        }
    }

    public zzbmv(@Nullable List<String> list) {
        this.zzaiI = 1;
        this.zzbYO = new ArrayList();
        if (list != null && !list.isEmpty()) {
            this.zzbYO.addAll(list);
        }
    }

    public static zzbmv zzWn() {
        return new zzbmv(null);
    }

    public static zzbmv zza(zzbmv com_google_android_gms_internal_zzbmv) {
        return new zzbmv(com_google_android_gms_internal_zzbmv != null ? com_google_android_gms_internal_zzbmv.zzWm() : null);
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzbmw.zza(this, parcel, i);
    }

    public List<String> zzWm() {
        return this.zzbYO;
    }
}
