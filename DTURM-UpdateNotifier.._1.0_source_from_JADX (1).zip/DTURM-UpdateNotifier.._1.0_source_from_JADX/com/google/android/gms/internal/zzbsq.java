package com.google.android.gms.internal;

public class zzbsq {
    private byte[] zzckl;
    private String zzckm;
    private byte zzckn = (byte) 1;

    public zzbsq(String str) {
        this.zzckm = str;
    }

    public zzbsq(byte[] bArr) {
        this.zzckl = bArr;
    }

    public String getText() {
        return this.zzckm;
    }
}
