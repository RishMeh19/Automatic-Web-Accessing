package com.google.android.gms.internal;

public interface zzbuw {
    boolean zza(zzbux com_google_android_gms_internal_zzbux);

    boolean zzg(Class<?> cls);
}
