package com.google.android.gms.internal;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public final class zzbwl extends zzbvs<Date> {
    public static final zzbvt zzcsz = new C05601();
    private final DateFormat zzcqJ = DateFormat.getDateTimeInstance(2, 2, Locale.US);
    private final DateFormat zzcqK = DateFormat.getDateTimeInstance(2, 2);
    private final DateFormat zzcqL = zzaem();

    static class C05601 implements zzbvt {
        C05601() {
        }

        public <T> zzbvs<T> zza(zzbva com_google_android_gms_internal_zzbva, zzbww<T> com_google_android_gms_internal_zzbww_T) {
            return com_google_android_gms_internal_zzbww_T.zzaey() == Date.class ? new zzbwl() : null;
        }
    }

    private static DateFormat zzaem() {
        DateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        return simpleDateFormat;
    }

    private synchronized Date zzkn(String str) {
        Date parse;
        try {
            parse = this.zzcqK.parse(str);
        } catch (ParseException e) {
            try {
                parse = this.zzcqJ.parse(str);
            } catch (ParseException e2) {
                try {
                    parse = this.zzcqL.parse(str);
                } catch (Throwable e3) {
                    throw new zzbvp(str, e3);
                }
            }
        }
        return parse;
    }

    public synchronized void zza(zzbwz com_google_android_gms_internal_zzbwz, Date date) throws IOException {
        if (date == null) {
            com_google_android_gms_internal_zzbwz.zzaex();
        } else {
            com_google_android_gms_internal_zzbwz.zzkp(this.zzcqJ.format(date));
        }
    }

    public /* synthetic */ Object zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
        return zzk(com_google_android_gms_internal_zzbwx);
    }

    public Date zzk(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
        if (com_google_android_gms_internal_zzbwx.zzaen() != zzbwy.NULL) {
            return zzkn(com_google_android_gms_internal_zzbwx.nextString());
        }
        com_google_android_gms_internal_zzbwx.nextNull();
        return null;
    }
}
