package com.google.android.gms.internal;

import java.util.Map.Entry;

public class zzbqs<T> {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbqs.class.desiredAssertionStatus());
    private zzbrq zzchD;
    private zzbqs<T> zzchE;
    private zzbqt<T> zzchF;

    public interface zza<T> {
        boolean zze(zzbqs<T> com_google_android_gms_internal_zzbqs_T);
    }

    public interface zzb<T> {
        void zzd(zzbqs<T> com_google_android_gms_internal_zzbqs_T);
    }

    public zzbqs() {
        this(null, null, new zzbqt());
    }

    public zzbqs(zzbrq com_google_android_gms_internal_zzbrq, zzbqs<T> com_google_android_gms_internal_zzbqs_T, zzbqt<T> com_google_android_gms_internal_zzbqt_T) {
        this.zzchD = com_google_android_gms_internal_zzbrq;
        this.zzchE = com_google_android_gms_internal_zzbqs_T;
        this.zzchF = com_google_android_gms_internal_zzbqt_T;
    }

    private void zzZR() {
        if (this.zzchE != null) {
            this.zzchE.zza(this.zzchD, this);
        }
    }

    private void zza(zzbrq com_google_android_gms_internal_zzbrq, zzbqs<T> com_google_android_gms_internal_zzbqs_T) {
        boolean isEmpty = com_google_android_gms_internal_zzbqs_T.isEmpty();
        boolean containsKey = this.zzchF.zzcfE.containsKey(com_google_android_gms_internal_zzbrq);
        if (isEmpty && containsKey) {
            this.zzchF.zzcfE.remove(com_google_android_gms_internal_zzbrq);
            zzZR();
        } else if (!isEmpty && !containsKey) {
            this.zzchF.zzcfE.put(com_google_android_gms_internal_zzbrq, com_google_android_gms_internal_zzbqs_T.zzchF);
            zzZR();
        }
    }

    public T getValue() {
        return this.zzchF.value;
    }

    public boolean hasChildren() {
        return !this.zzchF.zzcfE.isEmpty();
    }

    public boolean isEmpty() {
        return this.zzchF.value == null && this.zzchF.zzcfE.isEmpty();
    }

    public void setValue(T t) {
        this.zzchF.value = t;
        zzZR();
    }

    public String toString() {
        return toString("");
    }

    String toString(String str) {
        String asString = this.zzchD == null ? "<anon>" : this.zzchD.asString();
        String valueOf = String.valueOf(this.zzchF.toString(String.valueOf(str).concat("\t")));
        return new StringBuilder(((String.valueOf(str).length() + 1) + String.valueOf(asString).length()) + String.valueOf(valueOf).length()).append(str).append(asString).append("\n").append(valueOf).toString();
    }

    public zzbqs<T> zzL(zzbph com_google_android_gms_internal_zzbph) {
        zzbqs<T> com_google_android_gms_internal_zzbqs_T;
        zzbrq zzYU = com_google_android_gms_internal_zzbph.zzYU();
        while (zzYU != null) {
            zzbqs<T> com_google_android_gms_internal_zzbqs = new zzbqs(zzYU, com_google_android_gms_internal_zzbqs_T, com_google_android_gms_internal_zzbqs_T.zzchF.zzcfE.containsKey(zzYU) ? (zzbqt) com_google_android_gms_internal_zzbqs_T.zzchF.zzcfE.get(zzYU) : new zzbqt());
            com_google_android_gms_internal_zzbph = com_google_android_gms_internal_zzbph.zzYV();
            zzYU = com_google_android_gms_internal_zzbph.zzYU();
            com_google_android_gms_internal_zzbqs_T = com_google_android_gms_internal_zzbqs;
        }
        return com_google_android_gms_internal_zzbqs_T;
    }

    public zzbph zzWO() {
        if (this.zzchE != null) {
            if ($assertionsDisabled || this.zzchD != null) {
                return this.zzchE.zzWO().zza(this.zzchD);
            }
            throw new AssertionError();
        } else if (this.zzchD == null) {
            return zzbph.zzYR();
        } else {
            return new zzbph(this.zzchD);
        }
    }

    public void zza(zzb<T> com_google_android_gms_internal_zzbqs_zzb_T) {
        zza(com_google_android_gms_internal_zzbqs_zzb_T, false, false);
    }

    public void zza(final zzb<T> com_google_android_gms_internal_zzbqs_zzb_T, boolean z, final boolean z2) {
        if (z && !z2) {
            com_google_android_gms_internal_zzbqs_zzb_T.zzd(this);
        }
        zzb(new zzb<T>(this) {
            public void zzd(zzbqs<T> com_google_android_gms_internal_zzbqs_T) {
                com_google_android_gms_internal_zzbqs_T.zza(com_google_android_gms_internal_zzbqs_zzb_T, true, z2);
            }
        });
        if (z && z2) {
            com_google_android_gms_internal_zzbqs_zzb_T.zzd(this);
        }
    }

    public boolean zza(zza<T> com_google_android_gms_internal_zzbqs_zza_T) {
        return zza((zza) com_google_android_gms_internal_zzbqs_zza_T, false);
    }

    public boolean zza(zza<T> com_google_android_gms_internal_zzbqs_zza_T, boolean z) {
        if (!z) {
            this = this.zzchE;
        }
        while (this != null) {
            com_google_android_gms_internal_zzbqs_zza_T.zze(this);
            this = this.zzchE;
        }
        return false;
    }

    public void zzb(zzb<T> com_google_android_gms_internal_zzbqs_zzb_T) {
        Object[] toArray = this.zzchF.zzcfE.entrySet().toArray();
        for (Object obj : toArray) {
            Entry entry = (Entry) obj;
            com_google_android_gms_internal_zzbqs_zzb_T.zzd(new zzbqs((zzbrq) entry.getKey(), this, (zzbqt) entry.getValue()));
        }
    }
}
