package com.google.android.gms.internal;

import java.util.concurrent.ScheduledExecutorService;

public class zzbol {
    private final ScheduledExecutorService zzcav;
    private final zzbok zzcbF;
    private final zzbro zzcbG;
    private final boolean zzcbH;
    private final String zzcbI;
    private final String zzcbJ;

    public zzbol(zzbro com_google_android_gms_internal_zzbro, zzbok com_google_android_gms_internal_zzbok, ScheduledExecutorService scheduledExecutorService, boolean z, String str, String str2) {
        this.zzcbG = com_google_android_gms_internal_zzbro;
        this.zzcbF = com_google_android_gms_internal_zzbok;
        this.zzcav = scheduledExecutorService;
        this.zzcbH = z;
        this.zzcbI = str;
        this.zzcbJ = str2;
    }

    public zzbro zzXt() {
        return this.zzcbG;
    }

    public zzbok zzXu() {
        return this.zzcbF;
    }

    public ScheduledExecutorService zzXv() {
        return this.zzcav;
    }

    public boolean zzXw() {
        return this.zzcbH;
    }

    public String zzXx() {
        return this.zzcbI;
    }

    public String zzkn() {
        return this.zzcbJ;
    }
}
