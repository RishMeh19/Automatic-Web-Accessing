package com.google.android.gms.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzb;

public class zzzy implements zzabs {
    public Exception zzA(Status status) {
        return zzb.zzG(status);
    }
}
