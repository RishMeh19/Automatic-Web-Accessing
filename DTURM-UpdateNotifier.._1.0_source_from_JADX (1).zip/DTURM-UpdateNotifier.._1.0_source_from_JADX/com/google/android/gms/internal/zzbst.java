package com.google.android.gms.internal;

public class zzbst {
    private static final boolean zzckx = zzabH();

    private static boolean zzabH() {
        try {
            Class.forName("android.app.Activity");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    public static boolean zzabI() {
        return zzckx;
    }
}
