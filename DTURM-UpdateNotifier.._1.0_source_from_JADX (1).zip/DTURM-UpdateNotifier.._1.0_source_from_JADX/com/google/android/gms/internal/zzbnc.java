package com.google.android.gms.internal;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.google.android.gms.common.internal.zzac;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;

public class zzbnc implements AuthResult {
    private zzbnf zzbYU;

    public zzbnc(@NonNull zzbnf com_google_android_gms_internal_zzbnf) {
        this.zzbYU = (zzbnf) zzac.zzw(com_google_android_gms_internal_zzbnf);
    }

    @Nullable
    public FirebaseUser getUser() {
        return this.zzbYU;
    }
}
