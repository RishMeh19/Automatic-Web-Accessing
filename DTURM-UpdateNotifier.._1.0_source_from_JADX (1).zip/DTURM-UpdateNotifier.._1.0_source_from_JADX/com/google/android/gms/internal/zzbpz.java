package com.google.android.gms.internal;

import java.util.Collections;
import java.util.List;

public class zzbpz {
    private final zzbph zzcgD;
    private final zzbpy zzcgE;

    public zzbpz(zzbph com_google_android_gms_internal_zzbph, zzbpy com_google_android_gms_internal_zzbpy) {
        this.zzcgD = com_google_android_gms_internal_zzbph;
        this.zzcgE = com_google_android_gms_internal_zzbpy;
    }

    public zzbsb zza(zzbsc com_google_android_gms_internal_zzbsc, zzbsb com_google_android_gms_internal_zzbsb, boolean z, zzbrw com_google_android_gms_internal_zzbrw) {
        return this.zzcgE.zza(this.zzcgD, com_google_android_gms_internal_zzbsc, com_google_android_gms_internal_zzbsb, z, com_google_android_gms_internal_zzbrw);
    }

    public zzbsc zza(zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc, zzbsc com_google_android_gms_internal_zzbsc2) {
        return this.zzcgE.zza(this.zzcgD, com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbsc, com_google_android_gms_internal_zzbsc2);
    }

    public zzbsc zza(zzbrq com_google_android_gms_internal_zzbrq, zzbqu com_google_android_gms_internal_zzbqu) {
        return this.zzcgE.zza(this.zzcgD, com_google_android_gms_internal_zzbrq, com_google_android_gms_internal_zzbqu);
    }

    public zzbsc zza(zzbsc com_google_android_gms_internal_zzbsc, List<Long> list) {
        return zza(com_google_android_gms_internal_zzbsc, (List) list, false);
    }

    public zzbsc zza(zzbsc com_google_android_gms_internal_zzbsc, List<Long> list, boolean z) {
        return this.zzcgE.zza(this.zzcgD, com_google_android_gms_internal_zzbsc, (List) list, z);
    }

    public zzbpz zzb(zzbrq com_google_android_gms_internal_zzbrq) {
        return new zzbpz(this.zzcgD.zza(com_google_android_gms_internal_zzbrq), this.zzcgE);
    }

    public zzbsc zzc(zzbsc com_google_android_gms_internal_zzbsc) {
        return zza(com_google_android_gms_internal_zzbsc, Collections.emptyList());
    }

    public zzbsc zzd(zzbsc com_google_android_gms_internal_zzbsc) {
        return this.zzcgE.zzj(this.zzcgD, com_google_android_gms_internal_zzbsc);
    }

    public zzbsc zzv(zzbph com_google_android_gms_internal_zzbph) {
        return this.zzcgE.zzv(this.zzcgD.zzh(com_google_android_gms_internal_zzbph));
    }
}
