package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class zzbvd extends zzbvg implements Iterable<zzbvg> {
    private final List<zzbvg> zzbPr = new ArrayList();

    public boolean equals(Object obj) {
        return obj == this || ((obj instanceof zzbvd) && ((zzbvd) obj).zzbPr.equals(this.zzbPr));
    }

    public boolean getAsBoolean() {
        if (this.zzbPr.size() == 1) {
            return ((zzbvg) this.zzbPr.get(0)).getAsBoolean();
        }
        throw new IllegalStateException();
    }

    public double getAsDouble() {
        if (this.zzbPr.size() == 1) {
            return ((zzbvg) this.zzbPr.get(0)).getAsDouble();
        }
        throw new IllegalStateException();
    }

    public int getAsInt() {
        if (this.zzbPr.size() == 1) {
            return ((zzbvg) this.zzbPr.get(0)).getAsInt();
        }
        throw new IllegalStateException();
    }

    public long getAsLong() {
        if (this.zzbPr.size() == 1) {
            return ((zzbvg) this.zzbPr.get(0)).getAsLong();
        }
        throw new IllegalStateException();
    }

    public int hashCode() {
        return this.zzbPr.hashCode();
    }

    public Iterator<zzbvg> iterator() {
        return this.zzbPr.iterator();
    }

    public int size() {
        return this.zzbPr.size();
    }

    public Number zzadQ() {
        if (this.zzbPr.size() == 1) {
            return ((zzbvg) this.zzbPr.get(0)).zzadQ();
        }
        throw new IllegalStateException();
    }

    public String zzadR() {
        if (this.zzbPr.size() == 1) {
            return ((zzbvg) this.zzbPr.get(0)).zzadR();
        }
        throw new IllegalStateException();
    }

    public void zzc(zzbvg com_google_android_gms_internal_zzbvg) {
        Object obj;
        if (com_google_android_gms_internal_zzbvg == null) {
            obj = zzbvi.zzcrn;
        }
        this.zzbPr.add(obj);
    }

    public zzbvg zzqY(int i) {
        return (zzbvg) this.zzbPr.get(i);
    }
}
