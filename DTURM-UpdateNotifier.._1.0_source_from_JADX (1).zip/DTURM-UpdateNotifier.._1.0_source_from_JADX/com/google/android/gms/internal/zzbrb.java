package com.google.android.gms.internal;

import java.util.HashMap;
import java.util.Map;

public class zzbrb {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbrb.class.desiredAssertionStatus());
    public static final zzbrb zzcie = new zzbrb();
    private zzbrw zzcia = zzbsf.zzabm();
    private Integer zzcif;
    private zza zzcig;
    private zzbsc zzcih = null;
    private zzbrq zzcii = null;
    private zzbsc zzcij = null;
    private zzbrq zzcik = null;
    private String zzcil = null;

    private enum zza {
        LEFT,
        RIGHT
    }

    public static zzbrb zzaE(Map<String, Object> map) {
        String str;
        zzbrb com_google_android_gms_internal_zzbrb = new zzbrb();
        com_google_android_gms_internal_zzbrb.zzcif = (Integer) map.get("l");
        if (map.containsKey("sp")) {
            com_google_android_gms_internal_zzbrb.zzcih = zze(zzbsd.zzau(map.get("sp")));
            str = (String) map.get("sn");
            if (str != null) {
                com_google_android_gms_internal_zzbrb.zzcii = zzbrq.zzja(str);
            }
        }
        if (map.containsKey("ep")) {
            com_google_android_gms_internal_zzbrb.zzcij = zze(zzbsd.zzau(map.get("ep")));
            str = (String) map.get("en");
            if (str != null) {
                com_google_android_gms_internal_zzbrb.zzcik = zzbrq.zzja(str);
            }
        }
        str = (String) map.get("vf");
        if (str != null) {
            com_google_android_gms_internal_zzbrb.zzcig = str.equals("l") ? zza.LEFT : zza.RIGHT;
        }
        str = (String) map.get("i");
        if (str != null) {
            com_google_android_gms_internal_zzbrb.zzcia = zzbrw.zzjb(str);
        }
        return com_google_android_gms_internal_zzbrb;
    }

    private zzbrb zzaam() {
        zzbrb com_google_android_gms_internal_zzbrb = new zzbrb();
        com_google_android_gms_internal_zzbrb.zzcif = this.zzcif;
        com_google_android_gms_internal_zzbrb.zzcih = this.zzcih;
        com_google_android_gms_internal_zzbrb.zzcii = this.zzcii;
        com_google_android_gms_internal_zzbrb.zzcij = this.zzcij;
        com_google_android_gms_internal_zzbrb.zzcik = this.zzcik;
        com_google_android_gms_internal_zzbrb.zzcig = this.zzcig;
        com_google_android_gms_internal_zzbrb.zzcia = this.zzcia;
        return com_google_android_gms_internal_zzbrb;
    }

    private static zzbsc zze(zzbsc com_google_android_gms_internal_zzbsc) {
        if ((com_google_android_gms_internal_zzbsc instanceof zzbsi) || (com_google_android_gms_internal_zzbsc instanceof zzbrp) || (com_google_android_gms_internal_zzbsc instanceof zzbru) || (com_google_android_gms_internal_zzbsc instanceof zzbrv)) {
            return com_google_android_gms_internal_zzbsc;
        }
        if (com_google_android_gms_internal_zzbsc instanceof zzbsa) {
            return new zzbru(Double.valueOf(((Long) com_google_android_gms_internal_zzbsc.getValue()).doubleValue()), zzbsg.zzabn());
        }
        String valueOf = String.valueOf(com_google_android_gms_internal_zzbsc.getValue());
        throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 43).append("Unexpected value passed to normalizeValue: ").append(valueOf).toString());
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        zzbrb com_google_android_gms_internal_zzbrb = (zzbrb) obj;
        return (this.zzcif == null ? com_google_android_gms_internal_zzbrb.zzcif != null : !this.zzcif.equals(com_google_android_gms_internal_zzbrb.zzcif)) ? false : (this.zzcia == null ? com_google_android_gms_internal_zzbrb.zzcia != null : !this.zzcia.equals(com_google_android_gms_internal_zzbrb.zzcia)) ? false : (this.zzcik == null ? com_google_android_gms_internal_zzbrb.zzcik != null : !this.zzcik.equals(com_google_android_gms_internal_zzbrb.zzcik)) ? false : (this.zzcij == null ? com_google_android_gms_internal_zzbrb.zzcij != null : !this.zzcij.equals(com_google_android_gms_internal_zzbrb.zzcij)) ? false : (this.zzcii == null ? com_google_android_gms_internal_zzbrb.zzcii != null : !this.zzcii.equals(com_google_android_gms_internal_zzbrb.zzcii)) ? false : (this.zzcih == null ? com_google_android_gms_internal_zzbrb.zzcih != null : !this.zzcih.equals(com_google_android_gms_internal_zzbrb.zzcih)) ? false : zzaan() == com_google_android_gms_internal_zzbrb.zzaan();
    }

    public int getLimit() {
        if (zzaaj()) {
            return this.zzcif.intValue();
        }
        throw new IllegalArgumentException("Cannot get limit if limit has not been set");
    }

    public int hashCode() {
        int i = 0;
        int hashCode = ((this.zzcik != null ? this.zzcik.hashCode() : 0) + (((this.zzcij != null ? this.zzcij.hashCode() : 0) + (((this.zzcii != null ? this.zzcii.hashCode() : 0) + (((this.zzcih != null ? this.zzcih.hashCode() : 0) + (((zzaan() ? 1231 : 1237) + ((this.zzcif != null ? this.zzcif.intValue() : 0) * 31)) * 31)) * 31)) * 31)) * 31)) * 31;
        if (this.zzcia != null) {
            i = this.zzcia.hashCode();
        }
        return hashCode + i;
    }

    public boolean isDefault() {
        return zzaap() && this.zzcia.equals(zzbsf.zzabm());
    }

    public boolean isValid() {
        return (zzaad() && zzaag() && zzaaj() && !zzaak()) ? false : true;
    }

    public String toString() {
        return zzaao().toString();
    }

    public zzbrb zza(zzbrw com_google_android_gms_internal_zzbrw) {
        zzbrb zzaam = zzaam();
        zzaam.zzcia = com_google_android_gms_internal_zzbrw;
        return zzaam;
    }

    public zzbrb zza(zzbsc com_google_android_gms_internal_zzbsc, zzbrq com_google_android_gms_internal_zzbrq) {
        if ($assertionsDisabled || com_google_android_gms_internal_zzbsc.zzaaP() || com_google_android_gms_internal_zzbsc.isEmpty()) {
            zzbte.zzba(!(com_google_android_gms_internal_zzbsc instanceof zzbsa));
            zzbrb zzaam = zzaam();
            zzaam.zzcih = com_google_android_gms_internal_zzbsc;
            zzaam.zzcii = com_google_android_gms_internal_zzbrq;
            return zzaam;
        }
        throw new AssertionError();
    }

    public boolean zzaad() {
        return this.zzcih != null;
    }

    public zzbsc zzaae() {
        if (zzaad()) {
            return this.zzcih;
        }
        throw new IllegalArgumentException("Cannot get index start value if start has not been set");
    }

    public zzbrq zzaaf() {
        if (zzaad()) {
            return this.zzcii != null ? this.zzcii : zzbrq.zzaaI();
        } else {
            throw new IllegalArgumentException("Cannot get index start name if start has not been set");
        }
    }

    public boolean zzaag() {
        return this.zzcij != null;
    }

    public zzbsc zzaah() {
        if (zzaag()) {
            return this.zzcij;
        }
        throw new IllegalArgumentException("Cannot get index end value if start has not been set");
    }

    public zzbrq zzaai() {
        if (zzaag()) {
            return this.zzcik != null ? this.zzcik : zzbrq.zzaaJ();
        } else {
            throw new IllegalArgumentException("Cannot get index end name if start has not been set");
        }
    }

    public boolean zzaaj() {
        return this.zzcif != null;
    }

    public boolean zzaak() {
        return zzaaj() && this.zzcig != null;
    }

    public zzbrw zzaal() {
        return this.zzcia;
    }

    public boolean zzaan() {
        return this.zzcig != null ? this.zzcig == zza.LEFT : zzaad();
    }

    public Map<String, Object> zzaao() {
        Map<String, Object> hashMap = new HashMap();
        if (zzaad()) {
            hashMap.put("sp", this.zzcih.getValue());
            if (this.zzcii != null) {
                hashMap.put("sn", this.zzcii.asString());
            }
        }
        if (zzaag()) {
            hashMap.put("ep", this.zzcij.getValue());
            if (this.zzcik != null) {
                hashMap.put("en", this.zzcik.asString());
            }
        }
        if (this.zzcif != null) {
            hashMap.put("l", this.zzcif);
            zza com_google_android_gms_internal_zzbrb_zza = this.zzcig;
            if (com_google_android_gms_internal_zzbrb_zza == null) {
                com_google_android_gms_internal_zzbrb_zza = zzaad() ? zza.LEFT : zza.RIGHT;
            }
            switch (com_google_android_gms_internal_zzbrb_zza) {
                case LEFT:
                    hashMap.put("vf", "l");
                    break;
                case RIGHT:
                    hashMap.put("vf", "r");
                    break;
            }
        }
        if (!this.zzcia.equals(zzbsf.zzabm())) {
            hashMap.put("i", this.zzcia.zzabe());
        }
        return hashMap;
    }

    public boolean zzaap() {
        return (zzaad() || zzaag() || zzaaj()) ? false : true;
    }

    public String zzaaq() {
        if (this.zzcil == null) {
            try {
                this.zzcil = zzbsv.zzaF(zzaao());
            } catch (Throwable e) {
                throw new RuntimeException(e);
            }
        }
        return this.zzcil;
    }

    public zzbrj zzaar() {
        return zzaap() ? new zzbrh(zzaal()) : zzaaj() ? new zzbri(this) : new zzbrk(this);
    }

    public zzbrb zzb(zzbsc com_google_android_gms_internal_zzbsc, zzbrq com_google_android_gms_internal_zzbrq) {
        if ($assertionsDisabled || com_google_android_gms_internal_zzbsc.zzaaP() || com_google_android_gms_internal_zzbsc.isEmpty()) {
            zzbte.zzba(!(com_google_android_gms_internal_zzbsc instanceof zzbsa));
            zzbrb zzaam = zzaam();
            zzaam.zzcij = com_google_android_gms_internal_zzbsc;
            zzaam.zzcik = com_google_android_gms_internal_zzbrq;
            return zzaam;
        }
        throw new AssertionError();
    }

    public zzbrb zzqB(int i) {
        zzbrb zzaam = zzaam();
        zzaam.zzcif = Integer.valueOf(i);
        zzaam.zzcig = zza.LEFT;
        return zzaam;
    }

    public zzbrb zzqC(int i) {
        zzbrb zzaam = zzaam();
        zzaam.zzcif = Integer.valueOf(i);
        zzaam.zzcig = zza.RIGHT;
        return zzaam;
    }
}
