package com.google.android.gms.internal;

public class zzbzc {
    public static final zzbzc zzcyh = new C05761();

    static class C05761 extends zzbzc {
        C05761() {
        }
    }
}
