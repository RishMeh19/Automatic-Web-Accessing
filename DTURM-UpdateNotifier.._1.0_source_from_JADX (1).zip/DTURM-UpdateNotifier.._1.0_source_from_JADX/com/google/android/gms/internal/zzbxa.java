package com.google.android.gms.internal;

import java.io.IOException;

public final class zzbxa extends IOException {
    public zzbxa(String str) {
        super(str);
    }
}
