package com.google.android.gms.internal;

public class zzbta implements zzbsw {
    private final zzbsw zzckC;
    private long zzckD = 0;

    public zzbta(zzbsw com_google_android_gms_internal_zzbsw, long j) {
        this.zzckC = com_google_android_gms_internal_zzbsw;
        this.zzckD = j;
    }

    public void zzaT(long j) {
        this.zzckD = j;
    }

    public long zzabK() {
        return this.zzckC.zzabK() + this.zzckD;
    }
}
