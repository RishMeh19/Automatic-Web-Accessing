package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zzue implements Creator<zzud> {
    static void zza(zzud com_google_android_gms_internal_zzud, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 1, com_google_android_gms_internal_zzud.zzahP, i, false);
        zzc.zza(parcel, 2, com_google_android_gms_internal_zzud.zzahQ);
        zzc.zzc(parcel, 3, com_google_android_gms_internal_zzud.zzahR);
        zzc.zza(parcel, 4, com_google_android_gms_internal_zzud.zzAT, false);
        zzc.zza(parcel, 5, com_google_android_gms_internal_zzud.zzahS, i, false);
        zzc.zza(parcel, 6, com_google_android_gms_internal_zzud.zzahT);
        zzc.zzc(parcel, 7, com_google_android_gms_internal_zzud.zzahU);
        zzc.zzc(parcel, 8, com_google_android_gms_internal_zzud.zzahV);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzF(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzaU(i);
    }

    public zzud zzF(Parcel parcel) {
        zztp com_google_android_gms_internal_zztp = null;
        int i = 0;
        int zzaY = zzb.zzaY(parcel);
        long j = 0;
        int i2 = -1;
        boolean z = false;
        String str = null;
        int i3 = 0;
        zztr com_google_android_gms_internal_zztr = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    com_google_android_gms_internal_zztr = (zztr) zzb.zza(parcel, zzaX, zztr.CREATOR);
                    break;
                case 2:
                    j = zzb.zzi(parcel, zzaX);
                    break;
                case 3:
                    i3 = zzb.zzg(parcel, zzaX);
                    break;
                case 4:
                    str = zzb.zzq(parcel, zzaX);
                    break;
                case 5:
                    com_google_android_gms_internal_zztp = (zztp) zzb.zza(parcel, zzaX, zztp.CREATOR);
                    break;
                case 6:
                    z = zzb.zzc(parcel, zzaX);
                    break;
                case 7:
                    i2 = zzb.zzg(parcel, zzaX);
                    break;
                case 8:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzud(com_google_android_gms_internal_zztr, j, i3, str, com_google_android_gms_internal_zztp, z, i2, i);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzud[] zzaU(int i) {
        return new zzud[i];
    }
}
