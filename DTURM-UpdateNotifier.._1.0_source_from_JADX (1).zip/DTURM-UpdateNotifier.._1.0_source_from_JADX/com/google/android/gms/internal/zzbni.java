package com.google.android.gms.internal;

public interface zzbni {
    void zzVG();
}
