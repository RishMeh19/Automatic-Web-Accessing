package com.google.android.gms.internal;

public interface zzbpe {
    void restart();

    void shutdown();

    void zzq(Runnable runnable);
}
