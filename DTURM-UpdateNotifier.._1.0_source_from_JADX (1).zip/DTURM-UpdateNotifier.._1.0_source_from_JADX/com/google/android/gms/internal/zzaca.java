package com.google.android.gms.internal;

public abstract class zzaca<T> {
    private static String READ_PERMISSION = "com.google.android.providers.gsf.permission.READ_GSERVICES";
    private static zza zzaDC = null;
    private static int zzaDD = 0;
    private static final Object zztX = new Object();
    protected final String zzAX;
    protected final T zzAY;
    private T zzaDE = null;

    private interface zza {
    }

    class C04731 extends zzaca<Boolean> {
        C04731(String str, Boolean bool) {
            super(str, bool);
        }
    }

    class C04742 extends zzaca<Long> {
        C04742(String str, Long l) {
            super(str, l);
        }
    }

    class C04753 extends zzaca<Integer> {
        C04753(String str, Integer num) {
            super(str, num);
        }
    }

    class C04764 extends zzaca<Float> {
        C04764(String str, Float f) {
            super(str, f);
        }
    }

    class C04775 extends zzaca<String> {
        C04775(String str, String str2) {
            super(str, str2);
        }
    }

    protected zzaca(String str, T t) {
        this.zzAX = str;
        this.zzAY = t;
    }

    public static zzaca<String> zzB(String str, String str2) {
        return new C04775(str, str2);
    }

    public static zzaca<Float> zza(String str, Float f) {
        return new C04764(str, f);
    }

    public static zzaca<Integer> zza(String str, Integer num) {
        return new C04753(str, num);
    }

    public static zzaca<Long> zza(String str, Long l) {
        return new C04742(str, l);
    }

    public static zzaca<Boolean> zzj(String str, boolean z) {
        return new C04731(str, Boolean.valueOf(z));
    }
}
