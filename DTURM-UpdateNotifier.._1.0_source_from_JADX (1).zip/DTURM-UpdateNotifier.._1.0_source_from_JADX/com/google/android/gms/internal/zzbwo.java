package com.google.android.gms.internal;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

public final class zzbwo extends zzbwz {
    private static final Writer zzcsH = new C03291();
    private static final zzbvm zzcsI = new zzbvm("closed");
    private final List<zzbvg> zzcsG = new ArrayList();
    private String zzcsJ;
    private zzbvg zzcsK = zzbvi.zzcrn;

    static class C03291 extends Writer {
        C03291() {
        }

        public void close() throws IOException {
            throw new AssertionError();
        }

        public void flush() throws IOException {
            throw new AssertionError();
        }

        public void write(char[] cArr, int i, int i2) {
            throw new AssertionError();
        }
    }

    public zzbwo() {
        super(zzcsH);
    }

    private zzbvg zzaes() {
        return (zzbvg) this.zzcsG.get(this.zzcsG.size() - 1);
    }

    private void zzd(zzbvg com_google_android_gms_internal_zzbvg) {
        if (this.zzcsJ != null) {
            if (!com_google_android_gms_internal_zzbvg.zzadV() || zzaeK()) {
                ((zzbvj) zzaes()).zza(this.zzcsJ, com_google_android_gms_internal_zzbvg);
            }
            this.zzcsJ = null;
        } else if (this.zzcsG.isEmpty()) {
            this.zzcsK = com_google_android_gms_internal_zzbvg;
        } else {
            zzbvg zzaes = zzaes();
            if (zzaes instanceof zzbvd) {
                ((zzbvd) zzaes).zzc(com_google_android_gms_internal_zzbvg);
                return;
            }
            throw new IllegalStateException();
        }
    }

    public void close() throws IOException {
        if (this.zzcsG.isEmpty()) {
            this.zzcsG.add(zzcsI);
            return;
        }
        throw new IOException("Incomplete document");
    }

    public void flush() throws IOException {
    }

    public zzbwz zza(Number number) throws IOException {
        if (number == null) {
            return zzaex();
        }
        if (!isLenient()) {
            double doubleValue = number.doubleValue();
            if (Double.isNaN(doubleValue) || Double.isInfinite(doubleValue)) {
                String valueOf = String.valueOf(number);
                throw new IllegalArgumentException(new StringBuilder(String.valueOf(valueOf).length() + 33).append("JSON forbids NaN and infinities: ").append(valueOf).toString());
            }
        }
        zzd(new zzbvm(number));
        return this;
    }

    public zzbvg zzaer() {
        if (this.zzcsG.isEmpty()) {
            return this.zzcsK;
        }
        String valueOf = String.valueOf(this.zzcsG);
        throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 34).append("Expected one JSON element but was ").append(valueOf).toString());
    }

    public zzbwz zzaet() throws IOException {
        zzbvg com_google_android_gms_internal_zzbvd = new zzbvd();
        zzd(com_google_android_gms_internal_zzbvd);
        this.zzcsG.add(com_google_android_gms_internal_zzbvd);
        return this;
    }

    public zzbwz zzaeu() throws IOException {
        if (this.zzcsG.isEmpty() || this.zzcsJ != null) {
            throw new IllegalStateException();
        } else if (zzaes() instanceof zzbvd) {
            this.zzcsG.remove(this.zzcsG.size() - 1);
            return this;
        } else {
            throw new IllegalStateException();
        }
    }

    public zzbwz zzaev() throws IOException {
        zzbvg com_google_android_gms_internal_zzbvj = new zzbvj();
        zzd(com_google_android_gms_internal_zzbvj);
        this.zzcsG.add(com_google_android_gms_internal_zzbvj);
        return this;
    }

    public zzbwz zzaew() throws IOException {
        if (this.zzcsG.isEmpty() || this.zzcsJ != null) {
            throw new IllegalStateException();
        } else if (zzaes() instanceof zzbvj) {
            this.zzcsG.remove(this.zzcsG.size() - 1);
            return this;
        } else {
            throw new IllegalStateException();
        }
    }

    public zzbwz zzaex() throws IOException {
        zzd(zzbvi.zzcrn);
        return this;
    }

    public zzbwz zzbj(long j) throws IOException {
        zzd(new zzbvm(Long.valueOf(j)));
        return this;
    }

    public zzbwz zzbm(boolean z) throws IOException {
        zzd(new zzbvm(Boolean.valueOf(z)));
        return this;
    }

    public zzbwz zzko(String str) throws IOException {
        if (this.zzcsG.isEmpty() || this.zzcsJ != null) {
            throw new IllegalStateException();
        } else if (zzaes() instanceof zzbvj) {
            this.zzcsJ = str;
            return this;
        } else {
            throw new IllegalStateException();
        }
    }

    public zzbwz zzkp(String str) throws IOException {
        if (str == null) {
            return zzaex();
        }
        zzd(new zzbvm(str));
        return this;
    }
}
