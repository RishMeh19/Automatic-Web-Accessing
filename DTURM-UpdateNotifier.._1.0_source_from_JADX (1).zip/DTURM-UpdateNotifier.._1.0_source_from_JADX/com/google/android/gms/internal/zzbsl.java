package com.google.android.gms.internal;

public interface zzbsl {
    void zza(Thread thread, String str);
}
