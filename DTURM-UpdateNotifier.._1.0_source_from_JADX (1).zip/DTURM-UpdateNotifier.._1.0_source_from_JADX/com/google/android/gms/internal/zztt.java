package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzac;

public class zztt extends zza {
    public static final Creator<zztt> CREATOR = new zztu();
    public static final int zzahk = Integer.parseInt("-1");
    private static final zzub zzahl = new zzub.zza("SsbContext").zzY(true).zzcn("blob").zzqH();
    public final String zzahm;
    final zzub zzahn;
    public final int zzaho;
    public final byte[] zzahp;

    public zztt(String str, zzub com_google_android_gms_internal_zzub) {
        this(str, com_google_android_gms_internal_zzub, zzahk, null);
    }

    zztt(String str, zzub com_google_android_gms_internal_zzub, int i, byte[] bArr) {
        boolean z = i == zzahk || zzua.zzaP(i) != null;
        zzac.zzb(z, "Invalid section type " + i);
        this.zzahm = str;
        this.zzahn = com_google_android_gms_internal_zzub;
        this.zzaho = i;
        this.zzahp = bArr;
        String zzqF = zzqF();
        if (zzqF != null) {
            throw new IllegalArgumentException(zzqF);
        }
    }

    public zztt(String str, zzub com_google_android_gms_internal_zzub, String str2) {
        this(str, com_google_android_gms_internal_zzub, zzua.zzcm(str2), null);
    }

    public zztt(byte[] bArr, zzub com_google_android_gms_internal_zzub) {
        this(null, com_google_android_gms_internal_zzub, zzahk, bArr);
    }

    public static zztt zzl(byte[] bArr) {
        return new zztt(bArr, zzahl);
    }

    public void writeToParcel(Parcel parcel, int i) {
        zztu.zza(this, parcel, i);
    }

    public String zzqF() {
        if (this.zzaho == zzahk || zzua.zzaP(this.zzaho) != null) {
            return (this.zzahm == null || this.zzahp == null) ? null : "Both content and blobContent set";
        } else {
            return "Invalid section type " + this.zzaho;
        }
    }
}
