package com.google.android.gms.internal;

public class zzbre {
    private final zzbqu zzciw;
    private final zzbqu zzcix;

    public zzbre(zzbqu com_google_android_gms_internal_zzbqu, zzbqu com_google_android_gms_internal_zzbqu2) {
        this.zzciw = com_google_android_gms_internal_zzbqu;
        this.zzcix = com_google_android_gms_internal_zzbqu2;
    }

    public zzbre zza(zzbrx com_google_android_gms_internal_zzbrx, boolean z, boolean z2) {
        return new zzbre(new zzbqu(com_google_android_gms_internal_zzbrx, z, z2), this.zzcix);
    }

    public zzbqu zzaaw() {
        return this.zzciw;
    }

    public zzbsc zzaax() {
        return this.zzciw.zzZS() ? this.zzciw.zzWK() : null;
    }

    public zzbqu zzaay() {
        return this.zzcix;
    }

    public zzbsc zzaaz() {
        return this.zzcix.zzZS() ? this.zzcix.zzWK() : null;
    }

    public zzbre zzb(zzbrx com_google_android_gms_internal_zzbrx, boolean z, boolean z2) {
        return new zzbre(this.zzciw, new zzbqu(com_google_android_gms_internal_zzbrx, z, z2));
    }
}
