package com.google.android.gms.internal;

public class zzblr implements zzbuw {
    public boolean zza(zzbux com_google_android_gms_internal_zzbux) {
        return com_google_android_gms_internal_zzbux.getAnnotation(zzbmb.class) != null;
    }

    public boolean zzg(Class<?> cls) {
        return cls.getAnnotation(zzbmb.class) != null;
    }
}
