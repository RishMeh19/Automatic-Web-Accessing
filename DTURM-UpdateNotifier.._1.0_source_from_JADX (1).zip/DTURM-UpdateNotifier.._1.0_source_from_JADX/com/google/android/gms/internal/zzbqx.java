package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbqy.zza;
import com.google.firebase.database.DataSnapshot;

public class zzbqx implements zzbqy {
    private final zzbpc zzchL;
    private final zza zzchN;
    private final DataSnapshot zzchR;
    private final String zzchS;

    public zzbqx(zza com_google_android_gms_internal_zzbqy_zza, zzbpc com_google_android_gms_internal_zzbpc, DataSnapshot dataSnapshot, String str) {
        this.zzchN = com_google_android_gms_internal_zzbqy_zza;
        this.zzchL = com_google_android_gms_internal_zzbpc;
        this.zzchR = dataSnapshot;
        this.zzchS = str;
    }

    public String toString() {
        if (this.zzchN == zza.VALUE) {
            String valueOf = String.valueOf(zzWO());
            String valueOf2 = String.valueOf(this.zzchN);
            String valueOf3 = String.valueOf(this.zzchR.getValue(true));
            return new StringBuilder(((String.valueOf(valueOf).length() + 4) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length()).append(valueOf).append(": ").append(valueOf2).append(": ").append(valueOf3).toString();
        }
        valueOf = String.valueOf(zzWO());
        valueOf2 = String.valueOf(this.zzchN);
        valueOf3 = String.valueOf(this.zzchR.getKey());
        String valueOf4 = String.valueOf(this.zzchR.getValue(true));
        return new StringBuilder((((String.valueOf(valueOf).length() + 10) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length()) + String.valueOf(valueOf4).length()).append(valueOf).append(": ").append(valueOf2).append(": { ").append(valueOf3).append(": ").append(valueOf4).append(" }").toString();
    }

    public zzbph zzWO() {
        zzbph zzWO = this.zzchR.getRef().zzWO();
        return this.zzchN == zza.VALUE ? zzWO : zzWO.zzYW();
    }

    public void zzZV() {
        this.zzchL.zza(this);
    }

    public zza zzZX() {
        return this.zzchN;
    }

    public DataSnapshot zzaaa() {
        return this.zzchR;
    }

    public String zzaab() {
        return this.zzchS;
    }
}
