package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.common.util.zzi;

public class zzbmn extends zza {
    public static final Creator<zzbmn> CREATOR = new zzbmo();
    @zzbmb
    public final int zzaiI;
    @zzbvv("access_token")
    private String zzbDW;
    @zzbvv("refresh_token")
    private String zzbXZ;
    @zzbvv("expires_in")
    private Long zzbYG;
    @zzbvv("token_type")
    private String zzbYH;
    @zzbvv("issued_at")
    private Long zzbYI;

    public zzbmn() {
        this.zzaiI = 1;
        this.zzbYI = Long.valueOf(System.currentTimeMillis());
    }

    zzbmn(int i, String str, String str2, Long l, String str3, Long l2) {
        this.zzaiI = i;
        this.zzbXZ = str;
        this.zzbDW = str2;
        this.zzbYG = l;
        this.zzbYH = str3;
        this.zzbYI = l2;
    }

    public String getAccessToken() {
        return this.zzbDW;
    }

    public boolean isValid() {
        return zzi.zzzc().currentTimeMillis() + 300000 < this.zzbYI.longValue() + (this.zzbYG.longValue() * 1000);
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzbmo.zza(this, parcel, i);
    }

    public String zzWe() {
        return this.zzbXZ;
    }

    public long zzWf() {
        return this.zzbYG == null ? 0 : this.zzbYG.longValue();
    }

    @Nullable
    public String zzWg() {
        return this.zzbYH;
    }

    public long zzWh() {
        return this.zzbYI.longValue();
    }

    public void zziy(@NonNull String str) {
        this.zzbXZ = zzac.zzdr(str);
    }
}
