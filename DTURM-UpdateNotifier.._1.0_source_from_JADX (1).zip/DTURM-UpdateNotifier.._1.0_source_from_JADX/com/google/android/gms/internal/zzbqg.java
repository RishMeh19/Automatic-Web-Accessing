package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbqe.zza;

public class zzbqg extends zzbqe {
    private final zzbsc zzcgZ;

    public zzbqg(zzbqf com_google_android_gms_internal_zzbqf, zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc) {
        super(zza.Overwrite, com_google_android_gms_internal_zzbqf, com_google_android_gms_internal_zzbph);
        this.zzcgZ = com_google_android_gms_internal_zzbsc;
    }

    public String toString() {
        return String.format("Overwrite { path=%s, source=%s, snapshot=%s }", new Object[]{zzWO(), zzZA(), this.zzcgZ});
    }

    public zzbsc zzZG() {
        return this.zzcgZ;
    }

    public zzbqe zzc(zzbrq com_google_android_gms_internal_zzbrq) {
        return this.zzcai.isEmpty() ? new zzbqg(this.zzcgL, zzbph.zzYR(), this.zzcgZ.zzm(com_google_android_gms_internal_zzbrq)) : new zzbqg(this.zzcgL, this.zzcai.zzYV(), this.zzcgZ);
    }
}
