package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbrj.zza;
import java.util.Iterator;

public class zzbrk implements zzbrj {
    private final zzbrh zzciG;
    private final zzbsb zzciH;
    private final zzbsb zzciI;
    private final zzbrw zzcia;

    public zzbrk(zzbrb com_google_android_gms_internal_zzbrb) {
        this.zzciG = new zzbrh(com_google_android_gms_internal_zzbrb.zzaal());
        this.zzcia = com_google_android_gms_internal_zzbrb.zzaal();
        this.zzciH = zzd(com_google_android_gms_internal_zzbrb);
        this.zzciI = zze(com_google_android_gms_internal_zzbrb);
    }

    private static zzbsb zzd(zzbrb com_google_android_gms_internal_zzbrb) {
        if (!com_google_android_gms_internal_zzbrb.zzaad()) {
            return com_google_android_gms_internal_zzbrb.zzaal().zzabc();
        }
        return com_google_android_gms_internal_zzbrb.zzaal().zzg(com_google_android_gms_internal_zzbrb.zzaaf(), com_google_android_gms_internal_zzbrb.zzaae());
    }

    private static zzbsb zze(zzbrb com_google_android_gms_internal_zzbrb) {
        if (!com_google_android_gms_internal_zzbrb.zzaag()) {
            return com_google_android_gms_internal_zzbrb.zzaal().zzabd();
        }
        return com_google_android_gms_internal_zzbrb.zzaal().zzg(com_google_android_gms_internal_zzbrb.zzaai(), com_google_android_gms_internal_zzbrb.zzaah());
    }

    public zzbrx zza(zzbrx com_google_android_gms_internal_zzbrx, zzbrq com_google_android_gms_internal_zzbrq, zzbsc com_google_android_gms_internal_zzbsc, zzbph com_google_android_gms_internal_zzbph, zza com_google_android_gms_internal_zzbrj_zza, zzbrg com_google_android_gms_internal_zzbrg) {
        return this.zzciG.zza(com_google_android_gms_internal_zzbrx, com_google_android_gms_internal_zzbrq, !zza(new zzbsb(com_google_android_gms_internal_zzbrq, com_google_android_gms_internal_zzbsc)) ? zzbrv.zzabb() : com_google_android_gms_internal_zzbsc, com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbrj_zza, com_google_android_gms_internal_zzbrg);
    }

    public zzbrx zza(zzbrx com_google_android_gms_internal_zzbrx, zzbrx com_google_android_gms_internal_zzbrx2, zzbrg com_google_android_gms_internal_zzbrg) {
        zzbrx zza;
        if (com_google_android_gms_internal_zzbrx2.zzWK().zzaaP()) {
            zza = zzbrx.zza(zzbrv.zzabb(), this.zzcia);
        } else {
            zzbrx zzo = com_google_android_gms_internal_zzbrx2.zzo(zzbsg.zzabn());
            Iterator it = com_google_android_gms_internal_zzbrx2.iterator();
            zza = zzo;
            while (it.hasNext()) {
                zzbsb com_google_android_gms_internal_zzbsb = (zzbsb) it.next();
                zza = !zza(com_google_android_gms_internal_zzbsb) ? zza.zzh(com_google_android_gms_internal_zzbsb.zzabl(), zzbrv.zzabb()) : zza;
            }
        }
        return this.zzciG.zza(com_google_android_gms_internal_zzbrx, zza, com_google_android_gms_internal_zzbrg);
    }

    public zzbrx zza(zzbrx com_google_android_gms_internal_zzbrx, zzbsc com_google_android_gms_internal_zzbsc) {
        return com_google_android_gms_internal_zzbrx;
    }

    public boolean zza(zzbsb com_google_android_gms_internal_zzbsb) {
        return this.zzcia.compare(zzaaD(), com_google_android_gms_internal_zzbsb) <= 0 && this.zzcia.compare(com_google_android_gms_internal_zzbsb, zzaaE()) <= 0;
    }

    public zzbrj zzaaB() {
        return this.zzciG;
    }

    public boolean zzaaC() {
        return true;
    }

    public zzbsb zzaaD() {
        return this.zzciH;
    }

    public zzbsb zzaaE() {
        return this.zzciI;
    }

    public zzbrw zzaal() {
        return this.zzcia;
    }
}
