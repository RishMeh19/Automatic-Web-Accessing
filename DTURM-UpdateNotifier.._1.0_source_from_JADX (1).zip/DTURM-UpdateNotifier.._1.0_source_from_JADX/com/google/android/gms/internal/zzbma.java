package com.google.android.gms.internal;

import android.content.Context;
import android.os.Looper;
import android.support.annotation.NonNull;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.HasOptions;
import com.google.android.gms.common.api.Api.zzf;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.common.internal.zzg;

public final class zzbma {
    public static final zzf<zzblt> zzaid = new zzf();
    private static final com.google.android.gms.common.api.Api.zza<zzblt, zza> zzbYi = new C06311();
    public static final Api<zza> zzbYj = new Api("InternalFirebaseAuth.FIREBASE_AUTH_API", zzbYi, zzaid);

    class C06311 extends com.google.android.gms.common.api.Api.zza<zzblt, zza> {
        C06311() {
        }

        public zzblt zza(Context context, Looper looper, zzg com_google_android_gms_common_internal_zzg, zza com_google_android_gms_internal_zzbma_zza, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            return new zzblu(context, looper, com_google_android_gms_common_internal_zzg, com_google_android_gms_internal_zzbma_zza, connectionCallbacks, onConnectionFailedListener);
        }
    }

    public static final class zza implements HasOptions {
        private final String zzbWQ;

        public static final class zza {
            private String zzbWQ;

            public zza(@NonNull String str) {
                this.zzbWQ = zzac.zzdr(str);
            }

            public zza zzVV() {
                return new zza(this.zzbWQ);
            }
        }

        private zza(@NonNull String str) {
            this.zzbWQ = zzac.zzh(str, "A valid API key must be provided");
        }

        public String getApiKey() {
            return this.zzbWQ;
        }
    }

    public static zzbls zza(Context context, zza com_google_android_gms_internal_zzbma_zza) {
        return new zzbls(context, com_google_android_gms_internal_zzbma_zza);
    }
}
