package com.google.android.gms.internal;

import com.google.android.gms.common.api.Status;

public class zzbnh {
    public static Status zzWt() {
        return new Status(17024);
    }
}
