package com.google.android.gms.internal;

import android.support.v4.media.session.PlaybackStateCompat;
import com.google.firebase.database.DatabaseError;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Callable;

public class zzbpr {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbpr.class.desiredAssertionStatus());
    private final zzbrn zzcaH;
    private final zzbql zzcfJ;
    private zzbqq<zzbpq> zzcfK = zzbqq.zzZP();
    private final zzbpy zzcfL = new zzbpy();
    private final Map<zzbps, zzbrc> zzcfM = new HashMap();
    private final Map<zzbrc, zzbps> zzcfN = new HashMap();
    private final Set<zzbrc> zzcfO = new HashSet();
    private final zzd zzcfP;
    private long zzcfQ = 1;

    class C03069 implements Callable<List<? extends zzbqy>> {
        final /* synthetic */ zzbpr zzcfV;

        C03069(zzbpr com_google_android_gms_internal_zzbpr) {
            this.zzcfV = com_google_android_gms_internal_zzbpr;
        }

        public /* synthetic */ Object call() throws Exception {
            return zzMP();
        }

        public List<? extends zzbqy> zzMP() throws Exception {
            this.zzcfV.zzcfJ.zzWT();
            if (this.zzcfV.zzcfL.zzZu().isEmpty()) {
                return Collections.emptyList();
            }
            return this.zzcfV.zza(new zzbqb(zzbph.zzYR(), new zzbqq(Boolean.valueOf(true)), true));
        }
    }

    public interface zza {
        List<? extends zzbqy> zzb(DatabaseError databaseError);
    }

    public interface zzd {
        void zza(zzbrc com_google_android_gms_internal_zzbrc, zzbps com_google_android_gms_internal_zzbps);

        void zza(zzbrc com_google_android_gms_internal_zzbrc, zzbps com_google_android_gms_internal_zzbps, zzboo com_google_android_gms_internal_zzboo, zza com_google_android_gms_internal_zzbpr_zza);
    }

    class C05145 implements com.google.android.gms.internal.zzbqq.zza<zzbpq, Void> {
        final /* synthetic */ zzbpr zzcfV;

        C05145(zzbpr com_google_android_gms_internal_zzbpr) {
            this.zzcfV = com_google_android_gms_internal_zzbpr;
        }

        public Void zza(zzbph com_google_android_gms_internal_zzbph, zzbpq com_google_android_gms_internal_zzbpq, Void voidR) {
            zzbrc zzaat;
            if (com_google_android_gms_internal_zzbph.isEmpty() || !com_google_android_gms_internal_zzbpq.zzZj()) {
                for (zzbrd zzaat2 : com_google_android_gms_internal_zzbpq.zzZi()) {
                    zzaat = zzaat2.zzaat();
                    this.zzcfV.zzcfP.zza(this.zzcfV.zzd(zzaat), this.zzcfV.zze(zzaat));
                }
            } else {
                zzaat = com_google_android_gms_internal_zzbpq.zzZk().zzaat();
                this.zzcfV.zzcfP.zza(this.zzcfV.zzd(zzaat), this.zzcfV.zze(zzaat));
            }
            return null;
        }
    }

    private static class zzb extends zzbpc {
        private zzbrc zzcdH;

        public zzb(zzbrc com_google_android_gms_internal_zzbrc) {
            this.zzcdH = com_google_android_gms_internal_zzbrc;
        }

        public boolean equals(Object obj) {
            return (obj instanceof zzb) && ((zzb) obj).zzcdH.equals(this.zzcdH);
        }

        public int hashCode() {
            return this.zzcdH.hashCode();
        }

        public zzbrc zzYp() {
            return this.zzcdH;
        }

        public zzbpc zza(zzbrc com_google_android_gms_internal_zzbrc) {
            return new zzb(com_google_android_gms_internal_zzbrc);
        }

        public zzbqx zza(zzbqw com_google_android_gms_internal_zzbqw, zzbrc com_google_android_gms_internal_zzbrc) {
            return null;
        }

        public void zza(zzbqx com_google_android_gms_internal_zzbqx) {
        }

        public void zza(DatabaseError databaseError) {
        }

        public boolean zza(com.google.android.gms.internal.zzbqy.zza com_google_android_gms_internal_zzbqy_zza) {
            return false;
        }

        public boolean zzc(zzbpc com_google_android_gms_internal_zzbpc) {
            return com_google_android_gms_internal_zzbpc instanceof zzb;
        }
    }

    private class zzc implements zzboo, zza {
        final /* synthetic */ zzbpr zzcfV;
        private final zzbrd zzcgi;
        private final zzbps zzcgj;

        public zzc(zzbpr com_google_android_gms_internal_zzbpr, zzbrd com_google_android_gms_internal_zzbrd) {
            this.zzcfV = com_google_android_gms_internal_zzbpr;
            this.zzcgi = com_google_android_gms_internal_zzbrd;
            this.zzcgj = com_google_android_gms_internal_zzbpr.zze(com_google_android_gms_internal_zzbrd.zzaat());
        }

        public zzboi zzXA() {
            zzbrs zzi = zzbrs.zzi(this.zzcgi.zzaau());
            List<zzbph> zzXr = zzi.zzXr();
            List arrayList = new ArrayList(zzXr.size());
            for (zzbph zzYT : zzXr) {
                arrayList.add(zzYT.zzYT());
            }
            return new zzboi(arrayList, zzi.zzXs());
        }

        public String zzXy() {
            return this.zzcgi.zzaau().zzaaO();
        }

        public boolean zzXz() {
            return zzbsz.zzt(this.zzcgi.zzaau()) > PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID;
        }

        public List<? extends zzbqy> zzb(DatabaseError databaseError) {
            if (databaseError == null) {
                return this.zzcgj != null ? this.zzcfV.zza(this.zzcgj) : this.zzcfV.zzt(this.zzcgi.zzaat().zzWO());
            } else {
                zzbrn zza = this.zzcfV.zzcaH;
                String valueOf = String.valueOf(this.zzcgi.zzaat().zzWO());
                String valueOf2 = String.valueOf(databaseError.toString());
                zza.warn(new StringBuilder((String.valueOf(valueOf).length() + 19) + String.valueOf(valueOf2).length()).append("Listen at ").append(valueOf).append(" failed: ").append(valueOf2).toString());
                return this.zzcfV.zza(this.zzcgi.zzaat(), databaseError);
            }
        }
    }

    public zzbpr(zzbpa com_google_android_gms_internal_zzbpa, zzbql com_google_android_gms_internal_zzbql, zzd com_google_android_gms_internal_zzbpr_zzd) {
        this.zzcfP = com_google_android_gms_internal_zzbpr_zzd;
        this.zzcfJ = com_google_android_gms_internal_zzbql;
        this.zzcaH = com_google_android_gms_internal_zzbpa.zziV("SyncTree");
    }

    private zzbps zzZm() {
        long j = this.zzcfQ;
        this.zzcfQ = 1 + j;
        return new zzbps(j);
    }

    private List<zzbqy> zza(zzbqe com_google_android_gms_internal_zzbqe) {
        return zza(com_google_android_gms_internal_zzbqe, this.zzcfK, null, this.zzcfL.zzu(zzbph.zzYR()));
    }

    private List<zzbqy> zza(zzbqe com_google_android_gms_internal_zzbqe, zzbqq<zzbpq> com_google_android_gms_internal_zzbqq_com_google_android_gms_internal_zzbpq, zzbsc com_google_android_gms_internal_zzbsc, zzbpz com_google_android_gms_internal_zzbpz) {
        if (com_google_android_gms_internal_zzbqe.zzWO().isEmpty()) {
            return zzb(com_google_android_gms_internal_zzbqe, com_google_android_gms_internal_zzbqq_com_google_android_gms_internal_zzbpq, com_google_android_gms_internal_zzbsc, com_google_android_gms_internal_zzbpz);
        }
        zzbpq com_google_android_gms_internal_zzbpq = (zzbpq) com_google_android_gms_internal_zzbqq_com_google_android_gms_internal_zzbpq.getValue();
        if (com_google_android_gms_internal_zzbsc == null && com_google_android_gms_internal_zzbpq != null) {
            com_google_android_gms_internal_zzbsc = com_google_android_gms_internal_zzbpq.zzs(zzbph.zzYR());
        }
        List<zzbqy> arrayList = new ArrayList();
        zzbrq zzYU = com_google_android_gms_internal_zzbqe.zzWO().zzYU();
        zzbqe zzc = com_google_android_gms_internal_zzbqe.zzc(zzYU);
        zzbqq com_google_android_gms_internal_zzbqq = (zzbqq) com_google_android_gms_internal_zzbqq_com_google_android_gms_internal_zzbpq.zzZQ().get(zzYU);
        if (!(com_google_android_gms_internal_zzbqq == null || zzc == null)) {
            arrayList.addAll(zza(zzc, com_google_android_gms_internal_zzbqq, com_google_android_gms_internal_zzbsc != null ? com_google_android_gms_internal_zzbsc.zzm(zzYU) : null, com_google_android_gms_internal_zzbpz.zzb(zzYU)));
        }
        if (com_google_android_gms_internal_zzbpq != null) {
            arrayList.addAll(com_google_android_gms_internal_zzbpq.zza(com_google_android_gms_internal_zzbqe, com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbsc));
        }
        return arrayList;
    }

    private List<zzbrd> zza(zzbqq<zzbpq> com_google_android_gms_internal_zzbqq_com_google_android_gms_internal_zzbpq) {
        List arrayList = new ArrayList();
        zza((zzbqq) com_google_android_gms_internal_zzbqq_com_google_android_gms_internal_zzbpq, arrayList);
        return arrayList;
    }

    private List<? extends zzbqy> zza(zzbrc com_google_android_gms_internal_zzbrc, zzbqe com_google_android_gms_internal_zzbqe) {
        zzbph zzWO = com_google_android_gms_internal_zzbrc.zzWO();
        zzbpq com_google_android_gms_internal_zzbpq = (zzbpq) this.zzcfK.zzK(zzWO);
        if ($assertionsDisabled || com_google_android_gms_internal_zzbpq != null) {
            return com_google_android_gms_internal_zzbpq.zza(com_google_android_gms_internal_zzbqe, this.zzcfL.zzu(zzWO), null);
        }
        throw new AssertionError("Missing sync point for query tag that we're tracking");
    }

    private void zza(zzbqq<zzbpq> com_google_android_gms_internal_zzbqq_com_google_android_gms_internal_zzbpq, List<zzbrd> list) {
        zzbpq com_google_android_gms_internal_zzbpq = (zzbpq) com_google_android_gms_internal_zzbqq_com_google_android_gms_internal_zzbpq.getValue();
        if (com_google_android_gms_internal_zzbpq == null || !com_google_android_gms_internal_zzbpq.zzZj()) {
            if (com_google_android_gms_internal_zzbpq != null) {
                list.addAll(com_google_android_gms_internal_zzbpq.zzZi());
            }
            Iterator it = com_google_android_gms_internal_zzbqq_com_google_android_gms_internal_zzbpq.zzZQ().iterator();
            while (it.hasNext()) {
                zza((zzbqq) ((Entry) it.next()).getValue(), (List) list);
            }
            return;
        }
        list.add(com_google_android_gms_internal_zzbpq.zzZk());
    }

    private void zza(zzbrc com_google_android_gms_internal_zzbrc, zzbrd com_google_android_gms_internal_zzbrd) {
        zzbph zzWO = com_google_android_gms_internal_zzbrc.zzWO();
        zzbps zze = zze(com_google_android_gms_internal_zzbrc);
        Object com_google_android_gms_internal_zzbpr_zzc = new zzc(this, com_google_android_gms_internal_zzbrd);
        this.zzcfP.zza(zzd(com_google_android_gms_internal_zzbrc), zze, com_google_android_gms_internal_zzbpr_zzc, com_google_android_gms_internal_zzbpr_zzc);
        zzbqq zzI = this.zzcfK.zzI(zzWO);
        if (zze == null) {
            zzI.zza(new C05145(this));
        } else if (!$assertionsDisabled && ((zzbpq) zzI.getValue()).zzZj()) {
            throw new AssertionError("If we're adding a query, it shouldn't be shadowed");
        }
    }

    private void zzaa(List<zzbrc> list) {
        for (zzbrc com_google_android_gms_internal_zzbrc : list) {
            if (!com_google_android_gms_internal_zzbrc.zzaap()) {
                zzbps zze = zze(com_google_android_gms_internal_zzbrc);
                if ($assertionsDisabled || zze != null) {
                    this.zzcfN.remove(com_google_android_gms_internal_zzbrc);
                    this.zzcfM.remove(zze);
                } else {
                    throw new AssertionError();
                }
            }
        }
    }

    private zzbrc zzb(zzbps com_google_android_gms_internal_zzbps) {
        return (zzbrc) this.zzcfM.get(com_google_android_gms_internal_zzbps);
    }

    private List<zzbqy> zzb(zzbqe com_google_android_gms_internal_zzbqe, zzbqq<zzbpq> com_google_android_gms_internal_zzbqq_com_google_android_gms_internal_zzbpq, zzbsc com_google_android_gms_internal_zzbsc, zzbpz com_google_android_gms_internal_zzbpz) {
        zzbpq com_google_android_gms_internal_zzbpq = (zzbpq) com_google_android_gms_internal_zzbqq_com_google_android_gms_internal_zzbpq.getValue();
        final zzbsc zzs = (com_google_android_gms_internal_zzbsc != null || com_google_android_gms_internal_zzbpq == null) ? com_google_android_gms_internal_zzbsc : com_google_android_gms_internal_zzbpq.zzs(zzbph.zzYR());
        final List<zzbqy> arrayList = new ArrayList();
        final zzbpz com_google_android_gms_internal_zzbpz2 = com_google_android_gms_internal_zzbpz;
        final zzbqe com_google_android_gms_internal_zzbqe2 = com_google_android_gms_internal_zzbqe;
        com_google_android_gms_internal_zzbqq_com_google_android_gms_internal_zzbpq.zzZQ().zza(new com.google.android.gms.internal.zzbod.zzb<zzbrq, zzbqq<zzbpq>>(this) {
            final /* synthetic */ zzbpr zzcfV;

            public void zza(zzbrq com_google_android_gms_internal_zzbrq, zzbqq<zzbpq> com_google_android_gms_internal_zzbqq_com_google_android_gms_internal_zzbpq) {
                zzbsc com_google_android_gms_internal_zzbsc = null;
                if (zzs != null) {
                    com_google_android_gms_internal_zzbsc = zzs.zzm(com_google_android_gms_internal_zzbrq);
                }
                zzbpz zzb = com_google_android_gms_internal_zzbpz2.zzb(com_google_android_gms_internal_zzbrq);
                zzbqe zzc = com_google_android_gms_internal_zzbqe2.zzc(com_google_android_gms_internal_zzbrq);
                if (zzc != null) {
                    arrayList.addAll(this.zzcfV.zzb(zzc, com_google_android_gms_internal_zzbqq_com_google_android_gms_internal_zzbpq, com_google_android_gms_internal_zzbsc, zzb));
                }
            }

            public /* synthetic */ void zzj(Object obj, Object obj2) {
                zza((zzbrq) obj, (zzbqq) obj2);
            }
        });
        if (com_google_android_gms_internal_zzbpq != null) {
            arrayList.addAll(com_google_android_gms_internal_zzbpq.zza(com_google_android_gms_internal_zzbqe, com_google_android_gms_internal_zzbpz, zzs));
        }
        return arrayList;
    }

    private List<zzbqy> zzb(final zzbrc com_google_android_gms_internal_zzbrc, final zzbpc com_google_android_gms_internal_zzbpc, final DatabaseError databaseError) {
        return (List) this.zzcfJ.zzf(new Callable<List<zzbqy>>(this) {
            static final /* synthetic */ boolean $assertionsDisabled = (!zzbpr.class.desiredAssertionStatus());
            final /* synthetic */ zzbpr zzcfV;

            public /* synthetic */ Object call() throws Exception {
                return zzMP();
            }

            public List<zzbqy> zzMP() {
                zzbph zzWO = com_google_android_gms_internal_zzbrc.zzWO();
                zzbpq com_google_android_gms_internal_zzbpq = (zzbpq) this.zzcfV.zzcfK.zzK(zzWO);
                List<zzbqy> arrayList = new ArrayList();
                if (com_google_android_gms_internal_zzbpq != null && (com_google_android_gms_internal_zzbrc.isDefault() || com_google_android_gms_internal_zzbpq.zzc(com_google_android_gms_internal_zzbrc))) {
                    Object obj;
                    zzbtb zza = com_google_android_gms_internal_zzbpq.zza(com_google_android_gms_internal_zzbrc, com_google_android_gms_internal_zzbpc, databaseError);
                    if (com_google_android_gms_internal_zzbpq.isEmpty()) {
                        this.zzcfV.zzcfK = this.zzcfV.zzcfK.zzJ(zzWO);
                    }
                    List<zzbrc> list = (List) zza.getFirst();
                    arrayList = (List) zza.zzabL();
                    Object obj2 = null;
                    for (zzbrc com_google_android_gms_internal_zzbrc : list) {
                        this.zzcfV.zzcfJ.zzh(com_google_android_gms_internal_zzbrc);
                        obj = (obj2 != null || com_google_android_gms_internal_zzbrc.zzaap()) ? 1 : null;
                        obj2 = obj;
                    }
                    zzbqq zzd = this.zzcfV.zzcfK;
                    obj = (zzd.getValue() == null || !((zzbpq) zzd.getValue()).zzZj()) ? null : 1;
                    Iterator it = zzWO.iterator();
                    zzbqq com_google_android_gms_internal_zzbqq = zzd;
                    Object obj3 = obj;
                    while (it.hasNext()) {
                        com_google_android_gms_internal_zzbqq = com_google_android_gms_internal_zzbqq.zze((zzbrq) it.next());
                        obj = (obj3 != null || (com_google_android_gms_internal_zzbqq.getValue() != null && ((zzbpq) com_google_android_gms_internal_zzbqq.getValue()).zzZj())) ? 1 : null;
                        if (obj != null) {
                            obj3 = obj;
                            break;
                        } else if (com_google_android_gms_internal_zzbqq.isEmpty()) {
                            obj3 = obj;
                            break;
                        } else {
                            obj3 = obj;
                        }
                    }
                    if (obj2 != null && obj3 == null) {
                        zzbqq zzI = this.zzcfV.zzcfK.zzI(zzWO);
                        if (!zzI.isEmpty()) {
                            for (zzbrd com_google_android_gms_internal_zzbrd : this.zzcfV.zza(zzI)) {
                                Object com_google_android_gms_internal_zzbpr_zzc = new zzc(this.zzcfV, com_google_android_gms_internal_zzbrd);
                                this.zzcfV.zzcfP.zza(this.zzcfV.zzd(com_google_android_gms_internal_zzbrd.zzaat()), com_google_android_gms_internal_zzbpr_zzc.zzcgj, com_google_android_gms_internal_zzbpr_zzc, com_google_android_gms_internal_zzbpr_zzc);
                            }
                        }
                    }
                    if (obj3 == null && !list.isEmpty() && databaseError == null) {
                        if (obj2 != null) {
                            this.zzcfV.zzcfP.zza(this.zzcfV.zzd(com_google_android_gms_internal_zzbrc), null);
                        } else {
                            for (zzbrc com_google_android_gms_internal_zzbrc2 : list) {
                                zzbps zza2 = this.zzcfV.zze(com_google_android_gms_internal_zzbrc2);
                                if ($assertionsDisabled || zza2 != null) {
                                    this.zzcfV.zzcfP.zza(this.zzcfV.zzd(com_google_android_gms_internal_zzbrc2), zza2);
                                } else {
                                    throw new AssertionError();
                                }
                            }
                        }
                    }
                    this.zzcfV.zzaa(list);
                }
                return arrayList;
            }
        });
    }

    private zzbrc zzd(zzbrc com_google_android_gms_internal_zzbrc) {
        return (!com_google_android_gms_internal_zzbrc.zzaap() || com_google_android_gms_internal_zzbrc.isDefault()) ? com_google_android_gms_internal_zzbrc : zzbrc.zzN(com_google_android_gms_internal_zzbrc.zzWO());
    }

    private zzbps zze(zzbrc com_google_android_gms_internal_zzbrc) {
        return (zzbps) this.zzcfN.get(com_google_android_gms_internal_zzbrc);
    }

    public boolean isEmpty() {
        return this.zzcfK.isEmpty();
    }

    public List<? extends zzbqy> zzZl() {
        return (List) this.zzcfJ.zzf(new C03069(this));
    }

    public List<? extends zzbqy> zza(long j, boolean z, boolean z2, zzbsw com_google_android_gms_internal_zzbsw) {
        final boolean z3 = z2;
        final long j2 = j;
        final boolean z4 = z;
        final zzbsw com_google_android_gms_internal_zzbsw2 = com_google_android_gms_internal_zzbsw;
        return (List) this.zzcfJ.zzf(new Callable<List<? extends zzbqy>>(this) {
            final /* synthetic */ zzbpr zzcfV;

            public /* synthetic */ Object call() throws Exception {
                return zzMP();
            }

            public List<? extends zzbqy> zzMP() {
                if (z3) {
                    this.zzcfV.zzcfJ.zzaE(j2);
                }
                zzbpv zzaP = this.zzcfV.zzcfL.zzaP(j2);
                boolean zzaQ = this.zzcfV.zzcfL.zzaQ(j2);
                if (zzaP.isVisible() && !z4) {
                    Map zza = zzbpn.zza(com_google_android_gms_internal_zzbsw2);
                    if (zzaP.zzZr()) {
                        this.zzcfV.zzcfJ.zzk(zzaP.zzWO(), zzbpn.zza(zzaP.zzZp(), zza));
                    } else {
                        this.zzcfV.zzcfJ.zzc(zzaP.zzWO(), zzbpn.zza(zzaP.zzZq(), zza));
                    }
                }
                if (!zzaQ) {
                    return Collections.emptyList();
                }
                zzbqq zzb;
                zzbqq zzZP = zzbqq.zzZP();
                if (zzaP.zzZr()) {
                    zzb = zzZP.zzb(zzbph.zzYR(), Boolean.valueOf(true));
                } else {
                    Iterator it = zzaP.zzZq().iterator();
                    zzb = zzZP;
                    while (it.hasNext()) {
                        zzb = zzb.zzb((zzbph) ((Entry) it.next()).getKey(), Boolean.valueOf(true));
                    }
                }
                return this.zzcfV.zza(new zzbqb(zzaP.zzWO(), zzb, z4));
            }
        });
    }

    public List<? extends zzbqy> zza(zzbph com_google_android_gms_internal_zzbph, zzboy com_google_android_gms_internal_zzboy, zzboy com_google_android_gms_internal_zzboy2, long j, boolean z) {
        final boolean z2 = z;
        final zzbph com_google_android_gms_internal_zzbph2 = com_google_android_gms_internal_zzbph;
        final zzboy com_google_android_gms_internal_zzboy3 = com_google_android_gms_internal_zzboy;
        final long j2 = j;
        final zzboy com_google_android_gms_internal_zzboy4 = com_google_android_gms_internal_zzboy2;
        return (List) this.zzcfJ.zzf(new Callable<List<? extends zzbqy>>(this) {
            final /* synthetic */ zzbpr zzcfV;

            public /* synthetic */ Object call() throws Exception {
                return zzMP();
            }

            public List<? extends zzbqy> zzMP() throws Exception {
                if (z2) {
                    this.zzcfV.zzcfJ.zza(com_google_android_gms_internal_zzbph2, com_google_android_gms_internal_zzboy3, j2);
                }
                this.zzcfV.zzcfL.zza(com_google_android_gms_internal_zzbph2, com_google_android_gms_internal_zzboy4, Long.valueOf(j2));
                return this.zzcfV.zza(new zzbqd(zzbqf.zzcgR, com_google_android_gms_internal_zzbph2, com_google_android_gms_internal_zzboy4));
            }
        });
    }

    public List<? extends zzbqy> zza(final zzbph com_google_android_gms_internal_zzbph, final zzbsc com_google_android_gms_internal_zzbsc, final zzbps com_google_android_gms_internal_zzbps) {
        return (List) this.zzcfJ.zzf(new Callable<List<? extends zzbqy>>(this) {
            final /* synthetic */ zzbpr zzcfV;

            public /* synthetic */ Object call() throws Exception {
                return zzMP();
            }

            public List<? extends zzbqy> zzMP() {
                zzbrc zza = this.zzcfV.zzb(com_google_android_gms_internal_zzbps);
                if (zza == null) {
                    return Collections.emptyList();
                }
                zzbph zza2 = zzbph.zza(zza.zzWO(), com_google_android_gms_internal_zzbph);
                this.zzcfV.zzcfJ.zza(zza2.isEmpty() ? zza : zzbrc.zzN(com_google_android_gms_internal_zzbph), com_google_android_gms_internal_zzbsc);
                return this.zzcfV.zza(zza, new zzbqg(zzbqf.zzc(zza.zzaas()), zza2, com_google_android_gms_internal_zzbsc));
            }
        });
    }

    public List<? extends zzbqy> zza(zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc, zzbsc com_google_android_gms_internal_zzbsc2, long j, boolean z, boolean z2) {
        boolean z3 = z || !z2;
        zzbte.zzb(z3, "We shouldn't be persisting non-visible writes.");
        final boolean z4 = z2;
        final zzbph com_google_android_gms_internal_zzbph2 = com_google_android_gms_internal_zzbph;
        final zzbsc com_google_android_gms_internal_zzbsc3 = com_google_android_gms_internal_zzbsc;
        final long j2 = j;
        final zzbsc com_google_android_gms_internal_zzbsc4 = com_google_android_gms_internal_zzbsc2;
        final boolean z5 = z;
        return (List) this.zzcfJ.zzf(new Callable<List<? extends zzbqy>>(this) {
            final /* synthetic */ zzbpr zzcfV;

            public /* synthetic */ Object call() throws Exception {
                return zzMP();
            }

            public List<? extends zzbqy> zzMP() {
                if (z4) {
                    this.zzcfV.zzcfJ.zza(com_google_android_gms_internal_zzbph2, com_google_android_gms_internal_zzbsc3, j2);
                }
                this.zzcfV.zzcfL.zza(com_google_android_gms_internal_zzbph2, com_google_android_gms_internal_zzbsc4, Long.valueOf(j2), z5);
                return !z5 ? Collections.emptyList() : this.zzcfV.zza(new zzbqg(zzbqf.zzcgR, com_google_android_gms_internal_zzbph2, com_google_android_gms_internal_zzbsc4));
            }
        });
    }

    public List<? extends zzbqy> zza(zzbph com_google_android_gms_internal_zzbph, List<zzbsh> list, zzbps com_google_android_gms_internal_zzbps) {
        zzbrc zzb = zzb(com_google_android_gms_internal_zzbps);
        if (zzb == null) {
            return Collections.emptyList();
        }
        if ($assertionsDisabled || com_google_android_gms_internal_zzbph.equals(zzb.zzWO())) {
            zzbpq com_google_android_gms_internal_zzbpq = (zzbpq) this.zzcfK.zzK(zzb.zzWO());
            if ($assertionsDisabled || com_google_android_gms_internal_zzbpq != null) {
                zzbrd zzb2 = com_google_android_gms_internal_zzbpq.zzb(zzb);
                if ($assertionsDisabled || zzb2 != null) {
                    zzbsc zzaau = zzb2.zzaau();
                    zzbsc com_google_android_gms_internal_zzbsc = zzaau;
                    for (zzbsh zzr : list) {
                        com_google_android_gms_internal_zzbsc = zzr.zzr(com_google_android_gms_internal_zzbsc);
                    }
                    return zza(com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbsc, com_google_android_gms_internal_zzbps);
                }
                throw new AssertionError("Missing view for query tag that we're tracking");
            }
            throw new AssertionError("Missing sync point for query tag that we're tracking");
        }
        throw new AssertionError();
    }

    public List<? extends zzbqy> zza(final zzbph com_google_android_gms_internal_zzbph, final Map<zzbph, zzbsc> map) {
        return (List) this.zzcfJ.zzf(new Callable<List<? extends zzbqy>>(this) {
            final /* synthetic */ zzbpr zzcfV;

            public /* synthetic */ Object call() throws Exception {
                return zzMP();
            }

            public List<? extends zzbqy> zzMP() {
                zzboy zzaC = zzboy.zzaC(map);
                this.zzcfV.zzcfJ.zzd(com_google_android_gms_internal_zzbph, zzaC);
                return this.zzcfV.zza(new zzbqd(zzbqf.zzcgS, com_google_android_gms_internal_zzbph, zzaC));
            }
        });
    }

    public List<? extends zzbqy> zza(final zzbph com_google_android_gms_internal_zzbph, final Map<zzbph, zzbsc> map, final zzbps com_google_android_gms_internal_zzbps) {
        return (List) this.zzcfJ.zzf(new Callable<List<? extends zzbqy>>(this) {
            final /* synthetic */ zzbpr zzcfV;

            public /* synthetic */ Object call() throws Exception {
                return zzMP();
            }

            public List<? extends zzbqy> zzMP() {
                zzbrc zza = this.zzcfV.zzb(com_google_android_gms_internal_zzbps);
                if (zza == null) {
                    return Collections.emptyList();
                }
                zzbph zza2 = zzbph.zza(zza.zzWO(), com_google_android_gms_internal_zzbph);
                zzboy zzaC = zzboy.zzaC(map);
                this.zzcfV.zzcfJ.zzd(com_google_android_gms_internal_zzbph, zzaC);
                return this.zzcfV.zza(zza, new zzbqd(zzbqf.zzc(zza.zzaas()), zza2, zzaC));
            }
        });
    }

    public List<? extends zzbqy> zza(final zzbps com_google_android_gms_internal_zzbps) {
        return (List) this.zzcfJ.zzf(new Callable<List<? extends zzbqy>>(this) {
            final /* synthetic */ zzbpr zzcfV;

            public /* synthetic */ Object call() throws Exception {
                return zzMP();
            }

            public List<? extends zzbqy> zzMP() {
                zzbrc zza = this.zzcfV.zzb(com_google_android_gms_internal_zzbps);
                if (zza == null) {
                    return Collections.emptyList();
                }
                this.zzcfV.zzcfJ.zzi(zza);
                return this.zzcfV.zza(zza, new zzbqc(zzbqf.zzc(zza.zzaas()), zzbph.zzYR()));
            }
        });
    }

    public List<zzbqy> zza(zzbrc com_google_android_gms_internal_zzbrc, DatabaseError databaseError) {
        return zzb(com_google_android_gms_internal_zzbrc, null, databaseError);
    }

    public void zza(zzbrc com_google_android_gms_internal_zzbrc, boolean z) {
        if (z && !this.zzcfO.contains(com_google_android_gms_internal_zzbrc)) {
            zzg(new zzb(com_google_android_gms_internal_zzbrc));
            this.zzcfO.add(com_google_android_gms_internal_zzbrc);
        } else if (!z && this.zzcfO.contains(com_google_android_gms_internal_zzbrc)) {
            zzh(new zzb(com_google_android_gms_internal_zzbrc));
            this.zzcfO.remove(com_google_android_gms_internal_zzbrc);
        }
    }

    public List<? extends zzbqy> zzb(zzbph com_google_android_gms_internal_zzbph, List<zzbsh> list) {
        zzbpq com_google_android_gms_internal_zzbpq = (zzbpq) this.zzcfK.zzK(com_google_android_gms_internal_zzbph);
        if (com_google_android_gms_internal_zzbpq == null) {
            return Collections.emptyList();
        }
        zzbrd zzZk = com_google_android_gms_internal_zzbpq.zzZk();
        if (zzZk == null) {
            return Collections.emptyList();
        }
        zzbsc zzaau = zzZk.zzaau();
        zzbsc com_google_android_gms_internal_zzbsc = zzaau;
        for (zzbsh zzr : list) {
            com_google_android_gms_internal_zzbsc = zzr.zzr(com_google_android_gms_internal_zzbsc);
        }
        return zzi(com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbsc);
    }

    public zzbsc zzc(zzbph com_google_android_gms_internal_zzbph, List<Long> list) {
        zzbsc zzs;
        zzbqq com_google_android_gms_internal_zzbqq = this.zzcfK;
        com_google_android_gms_internal_zzbqq.getValue();
        zzbsc com_google_android_gms_internal_zzbsc = null;
        zzbph zzYR = zzbph.zzYR();
        zzbqq com_google_android_gms_internal_zzbqq2 = com_google_android_gms_internal_zzbqq;
        zzbph com_google_android_gms_internal_zzbph2 = com_google_android_gms_internal_zzbph;
        while (true) {
            zzbrq zzYU = com_google_android_gms_internal_zzbph2.zzYU();
            zzbph zzYV = com_google_android_gms_internal_zzbph2.zzYV();
            com_google_android_gms_internal_zzbph2 = zzYR.zza(zzYU);
            zzbph zza = zzbph.zza(com_google_android_gms_internal_zzbph2, com_google_android_gms_internal_zzbph);
            com_google_android_gms_internal_zzbqq2 = zzYU != null ? com_google_android_gms_internal_zzbqq2.zze(zzYU) : zzbqq.zzZP();
            zzbpq com_google_android_gms_internal_zzbpq = (zzbpq) com_google_android_gms_internal_zzbqq2.getValue();
            zzs = com_google_android_gms_internal_zzbpq != null ? com_google_android_gms_internal_zzbpq.zzs(zza) : com_google_android_gms_internal_zzbsc;
            if (!zzYV.isEmpty() && zzs == null) {
                com_google_android_gms_internal_zzbsc = zzs;
                zzYR = com_google_android_gms_internal_zzbph2;
                com_google_android_gms_internal_zzbph2 = zzYV;
            }
        }
        return this.zzcfL.zza(com_google_android_gms_internal_zzbph, zzs, (List) list, true);
    }

    public List<? extends zzbqy> zzg(final zzbpc com_google_android_gms_internal_zzbpc) {
        return (List) this.zzcfJ.zzf(new Callable<List<? extends zzbqy>>(this) {
            static final /* synthetic */ boolean $assertionsDisabled = (!zzbpr.class.desiredAssertionStatus());
            final /* synthetic */ zzbpr zzcfV;

            public /* synthetic */ Object call() throws Exception {
                return zzMP();
            }

            public List<? extends zzbqy> zzMP() {
                zzbpq com_google_android_gms_internal_zzbpq;
                zzbsc com_google_android_gms_internal_zzbsc;
                zzbpq com_google_android_gms_internal_zzbpq2;
                zzbqu com_google_android_gms_internal_zzbqu;
                zzbrc zzYp = com_google_android_gms_internal_zzbpc.zzYp();
                zzbph zzWO = zzYp.zzWO();
                zzbsc com_google_android_gms_internal_zzbsc2 = null;
                zzbph com_google_android_gms_internal_zzbph = zzWO;
                zzbqq zzd = this.zzcfV.zzcfK;
                boolean z = false;
                while (!zzd.isEmpty()) {
                    boolean z2;
                    zzbsc com_google_android_gms_internal_zzbsc3;
                    com_google_android_gms_internal_zzbpq = (zzbpq) zzd.getValue();
                    if (com_google_android_gms_internal_zzbpq != null) {
                        if (com_google_android_gms_internal_zzbsc2 == null) {
                            com_google_android_gms_internal_zzbsc2 = com_google_android_gms_internal_zzbpq.zzs(com_google_android_gms_internal_zzbph);
                        }
                        z2 = z || com_google_android_gms_internal_zzbpq.zzZj();
                        com_google_android_gms_internal_zzbsc3 = com_google_android_gms_internal_zzbsc2;
                    } else {
                        z2 = z;
                        com_google_android_gms_internal_zzbsc3 = com_google_android_gms_internal_zzbsc2;
                    }
                    zzd = zzd.zze(com_google_android_gms_internal_zzbph.isEmpty() ? zzbrq.zzja("") : com_google_android_gms_internal_zzbph.zzYU());
                    com_google_android_gms_internal_zzbph = com_google_android_gms_internal_zzbph.zzYV();
                    com_google_android_gms_internal_zzbsc2 = com_google_android_gms_internal_zzbsc3;
                    z = z2;
                }
                com_google_android_gms_internal_zzbpq = (zzbpq) this.zzcfV.zzcfK.zzK(zzWO);
                zzbpq com_google_android_gms_internal_zzbpq3;
                boolean z3;
                if (com_google_android_gms_internal_zzbpq == null) {
                    com_google_android_gms_internal_zzbpq = new zzbpq(this.zzcfV.zzcfJ);
                    this.zzcfV.zzcfK = this.zzcfV.zzcfK.zzb(zzWO, (Object) com_google_android_gms_internal_zzbpq);
                    com_google_android_gms_internal_zzbpq3 = com_google_android_gms_internal_zzbpq;
                    com_google_android_gms_internal_zzbsc = com_google_android_gms_internal_zzbsc2;
                    z3 = z;
                    com_google_android_gms_internal_zzbpq2 = com_google_android_gms_internal_zzbpq3;
                } else {
                    z = z || com_google_android_gms_internal_zzbpq.zzZj();
                    if (com_google_android_gms_internal_zzbsc2 == null) {
                        com_google_android_gms_internal_zzbsc2 = com_google_android_gms_internal_zzbpq.zzs(zzbph.zzYR());
                    }
                    com_google_android_gms_internal_zzbpq3 = com_google_android_gms_internal_zzbpq;
                    com_google_android_gms_internal_zzbsc = com_google_android_gms_internal_zzbsc2;
                    z3 = z;
                    com_google_android_gms_internal_zzbpq2 = com_google_android_gms_internal_zzbpq3;
                }
                this.zzcfV.zzcfJ.zzg(zzYp);
                if (com_google_android_gms_internal_zzbsc != null) {
                    com_google_android_gms_internal_zzbqu = new zzbqu(zzbrx.zza(com_google_android_gms_internal_zzbsc, zzYp.zzaal()), true, false);
                } else {
                    zzbqu zzf = this.zzcfV.zzcfJ.zzf(zzYp);
                    if (zzf.zzZS()) {
                        com_google_android_gms_internal_zzbqu = zzf;
                    } else {
                        zzbsc zzabb = zzbrv.zzabb();
                        Iterator it = this.zzcfV.zzcfK.zzI(zzWO).zzZQ().iterator();
                        while (it.hasNext()) {
                            Entry entry = (Entry) it.next();
                            zzbpq com_google_android_gms_internal_zzbpq4 = (zzbpq) ((zzbqq) entry.getValue()).getValue();
                            if (com_google_android_gms_internal_zzbpq4 != null) {
                                zzbsc zzs = com_google_android_gms_internal_zzbpq4.zzs(zzbph.zzYR());
                                if (zzs != null) {
                                    com_google_android_gms_internal_zzbsc = zzabb.zze((zzbrq) entry.getKey(), zzs);
                                    zzabb = com_google_android_gms_internal_zzbsc;
                                }
                            }
                            com_google_android_gms_internal_zzbsc = zzabb;
                            zzabb = com_google_android_gms_internal_zzbsc;
                        }
                        for (zzbsb com_google_android_gms_internal_zzbsb : zzf.zzWK()) {
                            if (!zzabb.zzk(com_google_android_gms_internal_zzbsb.zzabl())) {
                                zzabb = zzabb.zze(com_google_android_gms_internal_zzbsb.zzabl(), com_google_android_gms_internal_zzbsb.zzWK());
                            }
                        }
                        com_google_android_gms_internal_zzbqu = new zzbqu(zzbrx.zza(zzabb, zzYp.zzaal()), false, false);
                    }
                }
                boolean zzc = com_google_android_gms_internal_zzbpq2.zzc(zzYp);
                if (!(zzc || zzYp.zzaap())) {
                    if ($assertionsDisabled || !this.zzcfV.zzcfN.containsKey(zzYp)) {
                        zzbps zzf2 = this.zzcfV.zzZm();
                        this.zzcfV.zzcfN.put(zzYp, zzf2);
                        this.zzcfV.zzcfM.put(zzf2, zzYp);
                    } else {
                        throw new AssertionError("View does not exist but we have a tag");
                    }
                }
                List<? extends zzbqy> zza = com_google_android_gms_internal_zzbpq2.zza(com_google_android_gms_internal_zzbpc, this.zzcfV.zzcfL.zzu(zzWO), com_google_android_gms_internal_zzbqu);
                if (!(zzc || r4)) {
                    this.zzcfV.zza(zzYp, com_google_android_gms_internal_zzbpq2.zzb(zzYp));
                }
                return zza;
            }
        });
    }

    public List<zzbqy> zzh(zzbpc com_google_android_gms_internal_zzbpc) {
        return zzb(com_google_android_gms_internal_zzbpc.zzYp(), com_google_android_gms_internal_zzbpc, null);
    }

    public List<? extends zzbqy> zzi(final zzbph com_google_android_gms_internal_zzbph, final zzbsc com_google_android_gms_internal_zzbsc) {
        return (List) this.zzcfJ.zzf(new Callable<List<? extends zzbqy>>(this) {
            final /* synthetic */ zzbpr zzcfV;

            public /* synthetic */ Object call() throws Exception {
                return zzMP();
            }

            public List<? extends zzbqy> zzMP() {
                this.zzcfV.zzcfJ.zza(zzbrc.zzN(com_google_android_gms_internal_zzbph), com_google_android_gms_internal_zzbsc);
                return this.zzcfV.zza(new zzbqg(zzbqf.zzcgS, com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbsc));
            }
        });
    }

    public List<? extends zzbqy> zzt(final zzbph com_google_android_gms_internal_zzbph) {
        return (List) this.zzcfJ.zzf(new Callable<List<? extends zzbqy>>(this) {
            final /* synthetic */ zzbpr zzcfV;

            public /* synthetic */ Object call() throws Exception {
                return zzMP();
            }

            public List<? extends zzbqy> zzMP() {
                this.zzcfV.zzcfJ.zzi(zzbrc.zzN(com_google_android_gms_internal_zzbph));
                return this.zzcfV.zza(new zzbqc(zzbqf.zzcgS, com_google_android_gms_internal_zzbph));
            }
        });
    }
}
