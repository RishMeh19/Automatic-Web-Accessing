package com.google.android.gms.internal;

public interface zzbrj {

    public interface zza {
        zzbsb zza(zzbrw com_google_android_gms_internal_zzbrw, zzbsb com_google_android_gms_internal_zzbsb, boolean z);

        zzbsc zzh(zzbrq com_google_android_gms_internal_zzbrq);
    }

    zzbrx zza(zzbrx com_google_android_gms_internal_zzbrx, zzbrq com_google_android_gms_internal_zzbrq, zzbsc com_google_android_gms_internal_zzbsc, zzbph com_google_android_gms_internal_zzbph, zza com_google_android_gms_internal_zzbrj_zza, zzbrg com_google_android_gms_internal_zzbrg);

    zzbrx zza(zzbrx com_google_android_gms_internal_zzbrx, zzbrx com_google_android_gms_internal_zzbrx2, zzbrg com_google_android_gms_internal_zzbrg);

    zzbrx zza(zzbrx com_google_android_gms_internal_zzbrx, zzbsc com_google_android_gms_internal_zzbsc);

    zzbrj zzaaB();

    boolean zzaaC();

    zzbrw zzaal();
}
