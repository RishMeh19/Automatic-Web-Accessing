package com.google.android.gms.internal;

import java.util.Map.Entry;
import java.util.Set;

public final class zzbvj extends zzbvg {
    private final zzbwe<String, zzbvg> zzcro = new zzbwe();

    private zzbvg zzaN(Object obj) {
        return obj == null ? zzbvi.zzcrn : new zzbvm(obj);
    }

    public Set<Entry<String, zzbvg>> entrySet() {
        return this.zzcro.entrySet();
    }

    public boolean equals(Object obj) {
        return obj == this || ((obj instanceof zzbvj) && ((zzbvj) obj).zzcro.equals(this.zzcro));
    }

    public boolean has(String str) {
        return this.zzcro.containsKey(str);
    }

    public int hashCode() {
        return this.zzcro.hashCode();
    }

    public void zza(String str, zzbvg com_google_android_gms_internal_zzbvg) {
        Object obj;
        if (com_google_android_gms_internal_zzbvg == null) {
            obj = zzbvi.zzcrn;
        }
        this.zzcro.put(str, obj);
    }

    public void zza(String str, Boolean bool) {
        zza(str, zzaN(bool));
    }

    public void zzaG(String str, String str2) {
        zza(str, zzaN(str2));
    }

    public zzbvg zzkk(String str) {
        return (zzbvg) this.zzcro.get(str);
    }

    public zzbvd zzkl(String str) {
        return (zzbvd) this.zzcro.get(str);
    }
}
