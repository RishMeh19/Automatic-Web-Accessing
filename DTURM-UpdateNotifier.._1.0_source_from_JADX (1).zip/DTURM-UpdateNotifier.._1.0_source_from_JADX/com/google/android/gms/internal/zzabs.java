package com.google.android.gms.internal;

import com.google.android.gms.common.api.Status;

public interface zzabs {
    Exception zzA(Status status);
}
