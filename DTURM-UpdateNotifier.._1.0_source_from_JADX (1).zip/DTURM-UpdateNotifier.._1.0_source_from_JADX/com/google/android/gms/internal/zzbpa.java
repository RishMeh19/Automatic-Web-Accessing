package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbro.zza;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.FirebaseDatabase;
import java.util.concurrent.ScheduledExecutorService;

public class zzbpa {
    protected long cacheSize = 10485760;
    protected FirebaseApp zzcaw;
    protected zzbro zzcbG;
    protected boolean zzcbH;
    protected String zzcbJ;
    private boolean zzcdF = false;
    protected zzbpe zzcdS;
    protected zzbow zzcdT;
    protected zzbpm zzcdU;
    protected String zzcdV;
    protected zza zzcdW = zza.INFO;
    private boolean zzcdX = false;
    private zzbpi zzcdY;

    class C05011 implements zzbok {
        final /* synthetic */ zzbow zzcdZ;

        C05011(zzbow com_google_android_gms_internal_zzbow) {
            this.zzcdZ = com_google_android_gms_internal_zzbow;
        }

        public void zza(boolean z, final zzbok.zza com_google_android_gms_internal_zzbok_zza) {
            this.zzcdZ.zza(z, new zzbow.zza(this) {
                public void onError(String str) {
                    com_google_android_gms_internal_zzbok_zza.onError(str);
                }

                public void zziL(String str) {
                    com_google_android_gms_internal_zzbok_zza.zziL(str);
                }
            });
        }
    }

    private ScheduledExecutorService zzXv() {
        zzbpm zzYD = zzYD();
        if (zzYD instanceof zzbsy) {
            return ((zzbsy) zzYD).zzXv();
        }
        throw new RuntimeException("Custom run loops are not supported!");
    }

    private void zzYG() {
        if (this.zzcbG == null) {
            this.zzcbG = zzYu().zza(this, this.zzcdW, null);
        }
    }

    private void zzYH() {
        if (this.zzcdU == null) {
            this.zzcdU = this.zzcdY.zzb(this);
        }
    }

    private void zzYI() {
        if (this.zzcdS == null) {
            this.zzcdS = zzYu().zza(this);
        }
    }

    private void zzYJ() {
        if (this.zzcbJ == null) {
            this.zzcbJ = zziX(zzYu().zzc(this));
        }
    }

    private void zzYK() {
        if (this.zzcdT == null) {
            this.zzcdT = zzYu().zza(zzXv());
        }
    }

    private void zzYL() {
        if (this.zzcdV == null) {
            this.zzcdV = "default";
        }
    }

    private zzbpi zzYu() {
        if (this.zzcdY == null) {
            if (zzbst.zzabI()) {
                zzYv();
            } else if (zzbpf.isActive()) {
                zzbpi com_google_android_gms_internal_zzbpi = zzbpf.INSTANCE;
                com_google_android_gms_internal_zzbpi.initialize();
                this.zzcdY = com_google_android_gms_internal_zzbpi;
            } else {
                this.zzcdY = zzbpg.INSTANCE;
            }
        }
        return this.zzcdY;
    }

    private synchronized void zzYv() {
        this.zzcdY = new zzbnv(this.zzcaw);
    }

    private void zzYx() {
        zzYG();
        zzYu();
        zzYJ();
        zzYI();
        zzYH();
        zzYL();
        zzYK();
    }

    private void zzYy() {
        this.zzcdS.restart();
        this.zzcdU.restart();
    }

    private static zzbok zza(zzbow com_google_android_gms_internal_zzbow) {
        return new C05011(com_google_android_gms_internal_zzbow);
    }

    private String zziX(String str) {
        return "Firebase/" + "5" + "/" + FirebaseDatabase.getSdkVersion() + "/" + str;
    }

    public boolean isFrozen() {
        return this.zzcdF;
    }

    void stop() {
        this.zzcdX = true;
        this.zzcdS.shutdown();
        this.zzcdU.shutdown();
    }

    public zzbro zzXt() {
        return this.zzcbG;
    }

    public boolean zzXw() {
        return this.zzcbH;
    }

    public zzbol zzYA() {
        return new zzbol(zzXt(), zza(zzYF()), zzXv(), zzXw(), FirebaseDatabase.getSdkVersion(), zzkn());
    }

    public long zzYB() {
        return this.cacheSize;
    }

    public zzbpe zzYC() {
        return this.zzcdS;
    }

    public zzbpm zzYD() {
        return this.zzcdU;
    }

    public String zzYE() {
        return this.zzcdV;
    }

    public zzbow zzYF() {
        return this.zzcdT;
    }

    public zza zzYg() {
        return this.zzcdW;
    }

    synchronized void zzYl() {
        if (!this.zzcdF) {
            this.zzcdF = true;
            zzYx();
        }
    }

    public void zzYw() {
        if (this.zzcdX) {
            zzYy();
            this.zzcdX = false;
        }
    }

    protected void zzYz() {
        if (isFrozen()) {
            throw new DatabaseException("Modifications to DatabaseConfig objects must occur before they are in use");
        }
    }

    public zzbop zza(zzbon com_google_android_gms_internal_zzbon, zzbop.zza com_google_android_gms_internal_zzbop_zza) {
        return zzYu().zza(this, zzYA(), com_google_android_gms_internal_zzbon, com_google_android_gms_internal_zzbop_zza);
    }

    public zzbrn zziV(String str) {
        return new zzbrn(this.zzcbG, str);
    }

    zzbql zziW(String str) {
        if (!this.zzcbH) {
            return new zzbqk();
        }
        zzbql zza = this.zzcdY.zza(this, str);
        if (zza != null) {
            return zza;
        }
        throw new IllegalArgumentException("You have enabled persistence, but persistence is not supported on this platform.");
    }

    public String zzkn() {
        return this.zzcbJ;
    }
}
