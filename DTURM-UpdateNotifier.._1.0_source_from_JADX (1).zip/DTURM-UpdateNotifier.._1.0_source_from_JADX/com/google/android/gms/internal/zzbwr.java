package com.google.android.gms.internal;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public final class zzbwr implements zzbvt {
    private final zzbwa zzcqW;
    private final zzbwb zzcrf;
    private final zzbuz zzcrh;

    static abstract class zzb {
        final String name;
        final boolean zzcsX;
        final boolean zzcsY;

        protected zzb(String str, boolean z, boolean z2) {
            this.name = str;
            this.zzcsX = z;
            this.zzcsY = z2;
        }

        abstract void zza(zzbwx com_google_android_gms_internal_zzbwx, Object obj) throws IOException, IllegalAccessException;

        abstract void zza(zzbwz com_google_android_gms_internal_zzbwz, Object obj) throws IOException, IllegalAccessException;

        abstract boolean zzaU(Object obj) throws IOException, IllegalAccessException;
    }

    public static final class zza<T> extends zzbvs<T> {
        private final zzbwf<T> zzcsD;
        private final Map<String, zzb> zzcsW;

        private zza(zzbwf<T> com_google_android_gms_internal_zzbwf_T, Map<String, zzb> map) {
            this.zzcsD = com_google_android_gms_internal_zzbwf_T;
            this.zzcsW = map;
        }

        public void zza(zzbwz com_google_android_gms_internal_zzbwz, T t) throws IOException {
            if (t == null) {
                com_google_android_gms_internal_zzbwz.zzaex();
                return;
            }
            com_google_android_gms_internal_zzbwz.zzaev();
            try {
                for (zzb com_google_android_gms_internal_zzbwr_zzb : this.zzcsW.values()) {
                    if (com_google_android_gms_internal_zzbwr_zzb.zzaU(t)) {
                        com_google_android_gms_internal_zzbwz.zzko(com_google_android_gms_internal_zzbwr_zzb.name);
                        com_google_android_gms_internal_zzbwr_zzb.zza(com_google_android_gms_internal_zzbwz, (Object) t);
                    }
                }
                com_google_android_gms_internal_zzbwz.zzaew();
            } catch (IllegalAccessException e) {
                throw new AssertionError();
            }
        }

        public T zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
            if (com_google_android_gms_internal_zzbwx.zzaen() == zzbwy.NULL) {
                com_google_android_gms_internal_zzbwx.nextNull();
                return null;
            }
            T zzaeg = this.zzcsD.zzaeg();
            try {
                com_google_android_gms_internal_zzbwx.beginObject();
                while (com_google_android_gms_internal_zzbwx.hasNext()) {
                    zzb com_google_android_gms_internal_zzbwr_zzb = (zzb) this.zzcsW.get(com_google_android_gms_internal_zzbwx.nextName());
                    if (com_google_android_gms_internal_zzbwr_zzb == null || !com_google_android_gms_internal_zzbwr_zzb.zzcsY) {
                        com_google_android_gms_internal_zzbwx.skipValue();
                    } else {
                        com_google_android_gms_internal_zzbwr_zzb.zza(com_google_android_gms_internal_zzbwx, (Object) zzaeg);
                    }
                }
                com_google_android_gms_internal_zzbwx.endObject();
                return zzaeg;
            } catch (Throwable e) {
                throw new zzbvp(e);
            } catch (IllegalAccessException e2) {
                throw new AssertionError(e2);
            }
        }
    }

    public zzbwr(zzbwa com_google_android_gms_internal_zzbwa, zzbuz com_google_android_gms_internal_zzbuz, zzbwb com_google_android_gms_internal_zzbwb) {
        this.zzcqW = com_google_android_gms_internal_zzbwa;
        this.zzcrh = com_google_android_gms_internal_zzbuz;
        this.zzcrf = com_google_android_gms_internal_zzbwb;
    }

    private zzbvs<?> zza(zzbva com_google_android_gms_internal_zzbva, Field field, zzbww<?> com_google_android_gms_internal_zzbww_) {
        zzbvu com_google_android_gms_internal_zzbvu = (zzbvu) field.getAnnotation(zzbvu.class);
        if (com_google_android_gms_internal_zzbvu != null) {
            zzbvs<?> zza = zzbwm.zza(this.zzcqW, com_google_android_gms_internal_zzbva, com_google_android_gms_internal_zzbww_, com_google_android_gms_internal_zzbvu);
            if (zza != null) {
                return zza;
            }
        }
        return com_google_android_gms_internal_zzbva.zza((zzbww) com_google_android_gms_internal_zzbww_);
    }

    private zzb zza(zzbva com_google_android_gms_internal_zzbva, Field field, String str, zzbww<?> com_google_android_gms_internal_zzbww_, boolean z, boolean z2) {
        final boolean zzk = zzbwg.zzk(com_google_android_gms_internal_zzbww_.zzaey());
        final zzbva com_google_android_gms_internal_zzbva2 = com_google_android_gms_internal_zzbva;
        final Field field2 = field;
        final zzbww<?> com_google_android_gms_internal_zzbww_2 = com_google_android_gms_internal_zzbww_;
        return new zzb(this, str, z, z2) {
            final zzbvs<?> zzcsQ = this.zzcsV.zza(com_google_android_gms_internal_zzbva2, field2, com_google_android_gms_internal_zzbww_2);
            final /* synthetic */ zzbwr zzcsV;

            void zza(zzbwx com_google_android_gms_internal_zzbwx, Object obj) throws IOException, IllegalAccessException {
                Object zzb = this.zzcsQ.zzb(com_google_android_gms_internal_zzbwx);
                if (zzb != null || !zzk) {
                    field2.set(obj, zzb);
                }
            }

            void zza(zzbwz com_google_android_gms_internal_zzbwz, Object obj) throws IOException, IllegalAccessException {
                new zzbwu(com_google_android_gms_internal_zzbva2, this.zzcsQ, com_google_android_gms_internal_zzbww_2.zzaez()).zza(com_google_android_gms_internal_zzbwz, field2.get(obj));
            }

            public boolean zzaU(Object obj) throws IOException, IllegalAccessException {
                return this.zzcsX && field2.get(obj) != obj;
            }
        };
    }

    static List<String> zza(zzbuz com_google_android_gms_internal_zzbuz, Field field) {
        zzbvv com_google_android_gms_internal_zzbvv = (zzbvv) field.getAnnotation(zzbvv.class);
        List<String> linkedList = new LinkedList();
        if (com_google_android_gms_internal_zzbvv == null) {
            linkedList.add(com_google_android_gms_internal_zzbuz.zzc(field));
        } else {
            linkedList.add(com_google_android_gms_internal_zzbvv.value());
            for (Object add : com_google_android_gms_internal_zzbvv.zzaee()) {
                linkedList.add(add);
            }
        }
        return linkedList;
    }

    private Map<String, zzb> zza(zzbva com_google_android_gms_internal_zzbva, zzbww<?> com_google_android_gms_internal_zzbww_, Class<?> cls) {
        Map<String, zzb> linkedHashMap = new LinkedHashMap();
        if (cls.isInterface()) {
            return linkedHashMap;
        }
        Type zzaez = com_google_android_gms_internal_zzbww_.zzaez();
        Class zzaey;
        while (zzaey != Object.class) {
            for (Field field : zzaey.getDeclaredFields()) {
                boolean zza = zza(field, true);
                boolean zza2 = zza(field, false);
                if (zza || zza2) {
                    field.setAccessible(true);
                    Type zza3 = zzbvz.zza(r19.zzaez(), zzaey, field.getGenericType());
                    List zzd = zzd(field);
                    zzb com_google_android_gms_internal_zzbwr_zzb = null;
                    int i = 0;
                    while (i < zzd.size()) {
                        String str = (String) zzd.get(i);
                        if (i != 0) {
                            zza = false;
                        }
                        zzb com_google_android_gms_internal_zzbwr_zzb2 = (zzb) linkedHashMap.put(str, zza(com_google_android_gms_internal_zzbva, field, str, zzbww.zzl(zza3), zza, zza2));
                        if (com_google_android_gms_internal_zzbwr_zzb != null) {
                            com_google_android_gms_internal_zzbwr_zzb2 = com_google_android_gms_internal_zzbwr_zzb;
                        }
                        i++;
                        com_google_android_gms_internal_zzbwr_zzb = com_google_android_gms_internal_zzbwr_zzb2;
                    }
                    if (com_google_android_gms_internal_zzbwr_zzb != null) {
                        String valueOf = String.valueOf(zzaez);
                        String str2 = com_google_android_gms_internal_zzbwr_zzb.name;
                        throw new IllegalArgumentException(new StringBuilder((String.valueOf(valueOf).length() + 37) + String.valueOf(str2).length()).append(valueOf).append(" declares multiple JSON fields named ").append(str2).toString());
                    }
                }
            }
            zzbww zzl = zzbww.zzl(zzbvz.zza(zzl.zzaez(), zzaey, zzaey.getGenericSuperclass()));
            zzaey = zzl.zzaey();
        }
        return linkedHashMap;
    }

    static boolean zza(Field field, boolean z, zzbwb com_google_android_gms_internal_zzbwb) {
        return (com_google_android_gms_internal_zzbwb.zza(field.getType(), z) || com_google_android_gms_internal_zzbwb.zza(field, z)) ? false : true;
    }

    private List<String> zzd(Field field) {
        return zza(this.zzcrh, field);
    }

    public <T> zzbvs<T> zza(zzbva com_google_android_gms_internal_zzbva, zzbww<T> com_google_android_gms_internal_zzbww_T) {
        Class zzaey = com_google_android_gms_internal_zzbww_T.zzaey();
        return !Object.class.isAssignableFrom(zzaey) ? null : new zza(this.zzcqW.zzb(com_google_android_gms_internal_zzbww_T), zza(com_google_android_gms_internal_zzbva, (zzbww) com_google_android_gms_internal_zzbww_T, zzaey));
    }

    public boolean zza(Field field, boolean z) {
        return zza(field, z, this.zzcrf);
    }
}
