package com.google.android.gms.internal;

import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import com.google.android.gms.common.internal.zzac;
import com.google.firebase.auth.UserInfo;

public class zzbnd implements UserInfo {
    @Nullable
    @zzbvv("photoUrl")
    private String zzaQN;
    @zzbvv("userId")
    @NonNull
    private String zzadi;
    @Nullable
    @zzbvv("email")
    private String zzaka;
    @Nullable
    @zzbvv("displayName")
    private String zzakb;
    @Nullable
    @zzbmb
    private Uri zzbXX;
    @zzbvv("providerId")
    @NonNull
    private String zzbYA;
    @zzbvv("isEmailVerified")
    private boolean zzbYD;
    @Nullable
    @zzbvv("rawUserInfo")
    private String zzbYK;

    public zzbnd(@NonNull zzbmj com_google_android_gms_internal_zzbmj, @NonNull String str) {
        zzac.zzw(com_google_android_gms_internal_zzbmj);
        zzac.zzdr(str);
        this.zzadi = zzac.zzdr(com_google_android_gms_internal_zzbmj.getLocalId());
        this.zzbYA = str;
        this.zzaka = com_google_android_gms_internal_zzbmj.getEmail();
        this.zzakb = com_google_android_gms_internal_zzbmj.getDisplayName();
        Uri photoUri = com_google_android_gms_internal_zzbmj.getPhotoUri();
        if (photoUri != null) {
            this.zzaQN = photoUri.toString();
            this.zzbXX = photoUri;
        }
        this.zzbYD = com_google_android_gms_internal_zzbmj.isEmailVerified();
        this.zzbYK = null;
    }

    public zzbnd(@NonNull zzbmp com_google_android_gms_internal_zzbmp) {
        zzac.zzw(com_google_android_gms_internal_zzbmp);
        this.zzadi = zzac.zzdr(com_google_android_gms_internal_zzbmp.zzWi());
        this.zzbYA = zzac.zzdr(com_google_android_gms_internal_zzbmp.getProviderId());
        this.zzakb = com_google_android_gms_internal_zzbmp.getDisplayName();
        Uri photoUri = com_google_android_gms_internal_zzbmp.getPhotoUri();
        if (photoUri != null) {
            this.zzaQN = photoUri.toString();
            this.zzbXX = photoUri;
        }
        this.zzaka = null;
        this.zzbYD = false;
        this.zzbYK = com_google_android_gms_internal_zzbmp.getRawUserInfo();
    }

    @Nullable
    public String getDisplayName() {
        return this.zzakb;
    }

    @Nullable
    public String getEmail() {
        return this.zzaka;
    }

    @Nullable
    public Uri getPhotoUrl() {
        if (!TextUtils.isEmpty(this.zzaQN) && this.zzbXX == null) {
            this.zzbXX = Uri.parse(this.zzaQN);
        }
        return this.zzbXX;
    }

    @NonNull
    public String getProviderId() {
        return this.zzbYA;
    }

    @NonNull
    public String getUid() {
        return this.zzadi;
    }

    public boolean isEmailVerified() {
        return this.zzbYD;
    }
}
