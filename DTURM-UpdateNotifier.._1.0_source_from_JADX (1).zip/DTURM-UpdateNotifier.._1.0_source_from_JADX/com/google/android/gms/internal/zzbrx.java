package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class zzbrx implements Iterable<zzbsb> {
    private static final zzboa<zzbsb> zzcjp = new zzboa(Collections.emptyList(), null);
    private final zzbrw zzcia;
    private final zzbsc zzcjq;
    private zzboa<zzbsb> zzcjr;

    private zzbrx(zzbsc com_google_android_gms_internal_zzbsc, zzbrw com_google_android_gms_internal_zzbrw) {
        this.zzcia = com_google_android_gms_internal_zzbrw;
        this.zzcjq = com_google_android_gms_internal_zzbsc;
        this.zzcjr = null;
    }

    private zzbrx(zzbsc com_google_android_gms_internal_zzbsc, zzbrw com_google_android_gms_internal_zzbrw, zzboa<zzbsb> com_google_android_gms_internal_zzboa_com_google_android_gms_internal_zzbsb) {
        this.zzcia = com_google_android_gms_internal_zzbrw;
        this.zzcjq = com_google_android_gms_internal_zzbsc;
        this.zzcjr = com_google_android_gms_internal_zzboa_com_google_android_gms_internal_zzbsb;
    }

    public static zzbrx zza(zzbsc com_google_android_gms_internal_zzbsc, zzbrw com_google_android_gms_internal_zzbrw) {
        return new zzbrx(com_google_android_gms_internal_zzbsc, com_google_android_gms_internal_zzbrw);
    }

    private void zzabf() {
        if (this.zzcjr != null) {
            return;
        }
        if (this.zzcia.equals(zzbry.zzabi())) {
            this.zzcjr = zzcjp;
            return;
        }
        List arrayList = new ArrayList();
        Object obj = null;
        for (zzbsb com_google_android_gms_internal_zzbsb : this.zzcjq) {
            obj = (obj != null || this.zzcia.zzm(com_google_android_gms_internal_zzbsb.zzWK())) ? 1 : null;
            arrayList.add(new zzbsb(com_google_android_gms_internal_zzbsb.zzabl(), com_google_android_gms_internal_zzbsb.zzWK()));
        }
        if (obj != null) {
            this.zzcjr = new zzboa(arrayList, this.zzcia);
        } else {
            this.zzcjr = zzcjp;
        }
    }

    public static zzbrx zzn(zzbsc com_google_android_gms_internal_zzbsc) {
        return new zzbrx(com_google_android_gms_internal_zzbsc, zzbsf.zzabm());
    }

    public Iterator<zzbsb> iterator() {
        zzabf();
        return this.zzcjr == zzcjp ? this.zzcjq.iterator() : this.zzcjr.iterator();
    }

    public zzbsc zzWK() {
        return this.zzcjq;
    }

    public Iterator<zzbsb> zzWX() {
        zzabf();
        return this.zzcjr == zzcjp ? this.zzcjq.zzWX() : this.zzcjr.zzWX();
    }

    public zzbrq zza(zzbrq com_google_android_gms_internal_zzbrq, zzbsc com_google_android_gms_internal_zzbsc, zzbrw com_google_android_gms_internal_zzbrw) {
        if (this.zzcia.equals(zzbry.zzabi()) || this.zzcia.equals(com_google_android_gms_internal_zzbrw)) {
            zzabf();
            if (this.zzcjr == zzcjp) {
                return this.zzcjq.zzl(com_google_android_gms_internal_zzbrq);
            }
            zzbsb com_google_android_gms_internal_zzbsb = (zzbsb) this.zzcjr.zzao(new zzbsb(com_google_android_gms_internal_zzbrq, com_google_android_gms_internal_zzbsc));
            return com_google_android_gms_internal_zzbsb != null ? com_google_android_gms_internal_zzbsb.zzabl() : null;
        } else {
            throw new IllegalArgumentException("Index not available in IndexedNode!");
        }
    }

    public zzbsb zzabg() {
        if (!(this.zzcjq instanceof zzbrr)) {
            return null;
        }
        zzabf();
        if (this.zzcjr != zzcjp) {
            return (zzbsb) this.zzcjr.zzWZ();
        }
        zzbrq zzaaR = ((zzbrr) this.zzcjq).zzaaR();
        return new zzbsb(zzaaR, this.zzcjq.zzm(zzaaR));
    }

    public zzbsb zzabh() {
        if (!(this.zzcjq instanceof zzbrr)) {
            return null;
        }
        zzabf();
        if (this.zzcjr != zzcjp) {
            return (zzbsb) this.zzcjr.zzXa();
        }
        zzbrq zzaaS = ((zzbrr) this.zzcjq).zzaaS();
        return new zzbsb(zzaaS, this.zzcjq.zzm(zzaaS));
    }

    public boolean zzb(zzbrw com_google_android_gms_internal_zzbrw) {
        return this.zzcia.equals(com_google_android_gms_internal_zzbrw);
    }

    public zzbrx zzh(zzbrq com_google_android_gms_internal_zzbrq, zzbsc com_google_android_gms_internal_zzbsc) {
        zzbsc zze = this.zzcjq.zze(com_google_android_gms_internal_zzbrq, com_google_android_gms_internal_zzbsc);
        if (this.zzcjr == zzcjp && !this.zzcia.zzm(com_google_android_gms_internal_zzbsc)) {
            return new zzbrx(zze, this.zzcia, zzcjp);
        }
        if (this.zzcjr == null || this.zzcjr == zzcjp) {
            return new zzbrx(zze, this.zzcia, null);
        }
        zzboa zzam = this.zzcjr.zzam(new zzbsb(com_google_android_gms_internal_zzbrq, this.zzcjq.zzm(com_google_android_gms_internal_zzbrq)));
        if (!com_google_android_gms_internal_zzbsc.isEmpty()) {
            zzam = zzam.zzan(new zzbsb(com_google_android_gms_internal_zzbrq, com_google_android_gms_internal_zzbsc));
        }
        return new zzbrx(zze, this.zzcia, zzam);
    }

    public zzbrx zzo(zzbsc com_google_android_gms_internal_zzbsc) {
        return new zzbrx(this.zzcjq.zzg(com_google_android_gms_internal_zzbsc), this.zzcia, this.zzcjr);
    }
}
