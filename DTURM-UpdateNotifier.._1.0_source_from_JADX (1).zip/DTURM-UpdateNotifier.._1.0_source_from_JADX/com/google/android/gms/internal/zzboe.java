package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbod.zza;

public class zzboe<K, V> extends zzbof<K, V> {
    zzboe(K k, V v) {
        super(k, v, zzboc.zzXd(), zzboc.zzXd());
    }

    zzboe(K k, V v, zzbod<K, V> com_google_android_gms_internal_zzbod_K__V, zzbod<K, V> com_google_android_gms_internal_zzbod_K__V2) {
        super(k, v, com_google_android_gms_internal_zzbod_K__V, com_google_android_gms_internal_zzbod_K__V2);
    }

    protected zza zzXb() {
        return zza.RED;
    }

    public boolean zzXc() {
        return true;
    }

    protected zzbof<K, V> zza(K k, V v, zzbod<K, V> com_google_android_gms_internal_zzbod_K__V, zzbod<K, V> com_google_android_gms_internal_zzbod_K__V2) {
        Object key;
        Object value;
        zzbod zzXe;
        zzbod zzXf;
        if (k == null) {
            key = getKey();
        }
        if (v == null) {
            value = getValue();
        }
        if (com_google_android_gms_internal_zzbod_K__V == null) {
            zzXe = zzXe();
        }
        if (com_google_android_gms_internal_zzbod_K__V2 == null) {
            zzXf = zzXf();
        }
        return new zzboe(key, value, zzXe, zzXf);
    }
}
