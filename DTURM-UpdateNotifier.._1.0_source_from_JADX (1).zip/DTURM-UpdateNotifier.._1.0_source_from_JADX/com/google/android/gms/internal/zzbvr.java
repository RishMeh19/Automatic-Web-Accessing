package com.google.android.gms.internal;

import java.io.IOException;

final class zzbvr<T> extends zzbvs<T> {
    private zzbvs<T> zzcre;
    private final zzbvo<T> zzcrt;
    private final zzbvf<T> zzcru;
    private final zzbva zzcrv;
    private final zzbww<T> zzcrw;
    private final zzbvt zzcrx;

    private static class zza implements zzbvt {
        private final Class<?> zzcrA;
        private final zzbvo<?> zzcrt;
        private final zzbvf<?> zzcru;
        private final zzbww<?> zzcry;
        private final boolean zzcrz;

        private zza(Object obj, zzbww<?> com_google_android_gms_internal_zzbww_, boolean z, Class<?> cls) {
            this.zzcrt = obj instanceof zzbvo ? (zzbvo) obj : null;
            this.zzcru = obj instanceof zzbvf ? (zzbvf) obj : null;
            boolean z2 = (this.zzcrt == null && this.zzcru == null) ? false : true;
            zzbvy.zzaw(z2);
            this.zzcry = com_google_android_gms_internal_zzbww_;
            this.zzcrz = z;
            this.zzcrA = cls;
        }

        public <T> zzbvs<T> zza(zzbva com_google_android_gms_internal_zzbva, zzbww<T> com_google_android_gms_internal_zzbww_T) {
            boolean isAssignableFrom = this.zzcry != null ? this.zzcry.equals(com_google_android_gms_internal_zzbww_T) || (this.zzcrz && this.zzcry.zzaez() == com_google_android_gms_internal_zzbww_T.zzaey()) : this.zzcrA.isAssignableFrom(com_google_android_gms_internal_zzbww_T.zzaey());
            return isAssignableFrom ? new zzbvr(this.zzcrt, this.zzcru, com_google_android_gms_internal_zzbva, com_google_android_gms_internal_zzbww_T, this) : null;
        }
    }

    private zzbvr(zzbvo<T> com_google_android_gms_internal_zzbvo_T, zzbvf<T> com_google_android_gms_internal_zzbvf_T, zzbva com_google_android_gms_internal_zzbva, zzbww<T> com_google_android_gms_internal_zzbww_T, zzbvt com_google_android_gms_internal_zzbvt) {
        this.zzcrt = com_google_android_gms_internal_zzbvo_T;
        this.zzcru = com_google_android_gms_internal_zzbvf_T;
        this.zzcrv = com_google_android_gms_internal_zzbva;
        this.zzcrw = com_google_android_gms_internal_zzbww_T;
        this.zzcrx = com_google_android_gms_internal_zzbvt;
    }

    public static zzbvt zza(zzbww<?> com_google_android_gms_internal_zzbww_, Object obj) {
        return new zza(obj, com_google_android_gms_internal_zzbww_, false, null);
    }

    private zzbvs<T> zzaed() {
        zzbvs<T> com_google_android_gms_internal_zzbvs_T = this.zzcre;
        if (com_google_android_gms_internal_zzbvs_T != null) {
            return com_google_android_gms_internal_zzbvs_T;
        }
        com_google_android_gms_internal_zzbvs_T = this.zzcrv.zza(this.zzcrx, this.zzcrw);
        this.zzcre = com_google_android_gms_internal_zzbvs_T;
        return com_google_android_gms_internal_zzbvs_T;
    }

    public static zzbvt zzb(zzbww<?> com_google_android_gms_internal_zzbww_, Object obj) {
        return new zza(obj, com_google_android_gms_internal_zzbww_, com_google_android_gms_internal_zzbww_.zzaez() == com_google_android_gms_internal_zzbww_.zzaey(), null);
    }

    public void zza(zzbwz com_google_android_gms_internal_zzbwz, T t) throws IOException {
        if (this.zzcrt == null) {
            zzaed().zza(com_google_android_gms_internal_zzbwz, t);
        } else if (t == null) {
            com_google_android_gms_internal_zzbwz.zzaex();
        } else {
            zzbwh.zzb(this.zzcrt.zza(t, this.zzcrw.zzaez(), this.zzcrv.zzcrc), com_google_android_gms_internal_zzbwz);
        }
    }

    public T zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
        if (this.zzcru == null) {
            return zzaed().zzb(com_google_android_gms_internal_zzbwx);
        }
        zzbvg zzh = zzbwh.zzh(com_google_android_gms_internal_zzbwx);
        if (zzh.zzadV()) {
            return null;
        }
        try {
            return this.zzcru.zzb(zzh, this.zzcrw.zzaez(), this.zzcrv.zzcrb);
        } catch (zzbvk e) {
            throw e;
        } catch (Throwable e2) {
            throw new zzbvk(e2);
        }
    }
}
