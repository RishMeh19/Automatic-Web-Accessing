package com.google.android.gms.internal;

import java.io.Closeable;
import java.io.IOException;

public interface zzbzb extends Closeable {
    void close() throws IOException;

    long read(zzbyr com_google_android_gms_internal_zzbyr, long j) throws IOException;
}
