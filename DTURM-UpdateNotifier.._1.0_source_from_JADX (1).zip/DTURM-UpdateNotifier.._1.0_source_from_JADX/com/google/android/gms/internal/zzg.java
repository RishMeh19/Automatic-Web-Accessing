package com.google.android.gms.internal;

public interface zzg {
    zzj zza(zzl<?> com_google_android_gms_internal_zzl_) throws zzs;
}
