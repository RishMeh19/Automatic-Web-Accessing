package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbod.zza;
import com.google.android.gms.internal.zzbod.zzb;
import java.util.Comparator;

public abstract class zzbof<K, V> implements zzbod<K, V> {
    private final V value;
    private final K zzcbe;
    private zzbod<K, V> zzcbf;
    private final zzbod<K, V> zzcbg;

    zzbof(K k, V v, zzbod<K, V> com_google_android_gms_internal_zzbod_K__V, zzbod<K, V> com_google_android_gms_internal_zzbod_K__V2) {
        zzbod zzXd;
        zzbod zzXd2;
        this.zzcbe = k;
        this.value = v;
        if (com_google_android_gms_internal_zzbod_K__V == null) {
            zzXd = zzboc.zzXd();
        }
        this.zzcbf = zzXd;
        if (com_google_android_gms_internal_zzbod_K__V2 == null) {
            zzXd2 = zzboc.zzXd();
        }
        this.zzcbg = zzXd2;
    }

    private zzbod<K, V> zzXj() {
        if (this.zzcbf.isEmpty()) {
            return zzboc.zzXd();
        }
        if (!(zzXe().zzXc() || zzXe().zzXe().zzXc())) {
            this = zzXk();
        }
        return zza(null, null, ((zzbof) this.zzcbf).zzXj(), null).zzXm();
    }

    private zzbof<K, V> zzXk() {
        zzbof<K, V> zzXp = zzXp();
        return zzXp.zzXf().zzXe().zzXc() ? zzXp.zza(null, null, null, ((zzbof) zzXp.zzXf()).zzXo()).zzXn().zzXp() : zzXp;
    }

    private zzbof<K, V> zzXl() {
        zzbof<K, V> zzXp = zzXp();
        return zzXp.zzXe().zzXe().zzXc() ? zzXp.zzXo().zzXp() : zzXp;
    }

    private zzbof<K, V> zzXm() {
        zzbof<K, V> zzXn;
        if (this.zzcbg.zzXc() && !this.zzcbf.zzXc()) {
            zzXn = zzXn();
        }
        if (zzXn.zzcbf.zzXc() && ((zzbof) zzXn.zzcbf).zzcbf.zzXc()) {
            zzXn = zzXn.zzXo();
        }
        return (zzXn.zzcbf.zzXc() && zzXn.zzcbg.zzXc()) ? zzXn.zzXp() : zzXn;
    }

    private zzbof<K, V> zzXn() {
        return (zzbof) this.zzcbg.zza(null, null, zzXb(), (zzbof) zza(null, null, zza.RED, null, ((zzbof) this.zzcbg).zzcbf), null);
    }

    private zzbof<K, V> zzXo() {
        return (zzbof) this.zzcbf.zza(null, null, zzXb(), null, (zzbof) zza(null, null, zza.RED, ((zzbof) this.zzcbf).zzcbg, null));
    }

    private zzbof<K, V> zzXp() {
        return (zzbof) zza(null, null, zza((zzbod) this), this.zzcbf.zza(null, null, zza(this.zzcbf), null, null), this.zzcbg.zza(null, null, zza(this.zzcbg), null, null));
    }

    private static zza zza(zzbod com_google_android_gms_internal_zzbod) {
        return com_google_android_gms_internal_zzbod.zzXc() ? zza.BLACK : zza.RED;
    }

    public K getKey() {
        return this.zzcbe;
    }

    public V getValue() {
        return this.value;
    }

    public boolean isEmpty() {
        return false;
    }

    protected abstract zza zzXb();

    public zzbod<K, V> zzXe() {
        return this.zzcbf;
    }

    public zzbod<K, V> zzXf() {
        return this.zzcbg;
    }

    public zzbod<K, V> zzXg() {
        return this.zzcbf.isEmpty() ? this : this.zzcbf.zzXg();
    }

    public zzbod<K, V> zzXh() {
        return this.zzcbg.isEmpty() ? this : this.zzcbg.zzXh();
    }

    public int zzXi() {
        return (this.zzcbf.zzXi() + 1) + this.zzcbg.zzXi();
    }

    public /* synthetic */ zzbod zza(Object obj, Object obj2, zza com_google_android_gms_internal_zzbod_zza, zzbod com_google_android_gms_internal_zzbod, zzbod com_google_android_gms_internal_zzbod2) {
        return zzb(obj, obj2, com_google_android_gms_internal_zzbod_zza, com_google_android_gms_internal_zzbod, com_google_android_gms_internal_zzbod2);
    }

    public zzbod<K, V> zza(K k, V v, Comparator<K> comparator) {
        int compare = comparator.compare(k, this.zzcbe);
        zzbof zza = compare < 0 ? zza(null, null, this.zzcbf.zza(k, v, comparator), null) : compare == 0 ? zza(k, v, null, null) : zza(null, null, null, this.zzcbg.zza(k, v, comparator));
        return zza.zzXm();
    }

    public zzbod<K, V> zza(K k, Comparator<K> comparator) {
        zzbof zza;
        if (comparator.compare(k, this.zzcbe) < 0) {
            if (!(this.zzcbf.isEmpty() || this.zzcbf.zzXc() || ((zzbof) this.zzcbf).zzcbf.zzXc())) {
                this = zzXk();
            }
            zza = zza(null, null, this.zzcbf.zza(k, comparator), null);
        } else {
            if (this.zzcbf.zzXc()) {
                this = zzXo();
            }
            if (!(this.zzcbg.isEmpty() || this.zzcbg.zzXc() || ((zzbof) this.zzcbg).zzcbf.zzXc())) {
                this = zzXl();
            }
            if (comparator.compare(k, this.zzcbe) == 0) {
                if (this.zzcbg.isEmpty()) {
                    return zzboc.zzXd();
                }
                zzbod zzXg = this.zzcbg.zzXg();
                this = zza(zzXg.getKey(), zzXg.getValue(), null, ((zzbof) this.zzcbg).zzXj());
            }
            zza = zza(null, null, null, this.zzcbg.zza(k, comparator));
        }
        return zza.zzXm();
    }

    protected abstract zzbof<K, V> zza(K k, V v, zzbod<K, V> com_google_android_gms_internal_zzbod_K__V, zzbod<K, V> com_google_android_gms_internal_zzbod_K__V2);

    public void zza(zzb<K, V> com_google_android_gms_internal_zzbod_zzb_K__V) {
        this.zzcbf.zza(com_google_android_gms_internal_zzbod_zzb_K__V);
        com_google_android_gms_internal_zzbod_zzb_K__V.zzj(this.zzcbe, this.value);
        this.zzcbg.zza(com_google_android_gms_internal_zzbod_zzb_K__V);
    }

    public zzbof<K, V> zzb(K k, V v, zza com_google_android_gms_internal_zzbod_zza, zzbod<K, V> com_google_android_gms_internal_zzbod_K__V, zzbod<K, V> com_google_android_gms_internal_zzbod_K__V2) {
        Object obj;
        Object obj2;
        zzbod com_google_android_gms_internal_zzbod;
        zzbod com_google_android_gms_internal_zzbod2;
        if (k == null) {
            obj = this.zzcbe;
        }
        if (v == null) {
            obj2 = this.value;
        }
        if (com_google_android_gms_internal_zzbod_K__V == null) {
            com_google_android_gms_internal_zzbod = this.zzcbf;
        }
        if (com_google_android_gms_internal_zzbod_K__V2 == null) {
            com_google_android_gms_internal_zzbod2 = this.zzcbg;
        }
        return com_google_android_gms_internal_zzbod_zza == zza.RED ? new zzboe(obj, obj2, com_google_android_gms_internal_zzbod, com_google_android_gms_internal_zzbod2) : new zzbob(obj, obj2, com_google_android_gms_internal_zzbod, com_google_android_gms_internal_zzbod2);
    }

    void zzb(zzbod<K, V> com_google_android_gms_internal_zzbod_K__V) {
        this.zzcbf = com_google_android_gms_internal_zzbod_K__V;
    }
}
