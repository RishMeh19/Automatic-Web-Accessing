package com.google.android.gms.internal;

import android.app.Activity;
import android.support.annotation.MainThread;
import android.support.annotation.NonNull;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class zzbuj {
    private static final zzbuj zzcqr = new zzbuj();
    private final Map<Object, zza> zzcqs = new HashMap();
    private final Object zzcqt = new Object();

    private static class zza {
        @NonNull
        private final Activity mActivity;
        @NonNull
        private final Object zzcqu;
        @NonNull
        private final Runnable zzw;

        public zza(@NonNull Activity activity, @NonNull Runnable runnable, @NonNull Object obj) {
            this.mActivity = activity;
            this.zzw = runnable;
            this.zzcqu = obj;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof zza)) {
                return false;
            }
            zza com_google_android_gms_internal_zzbuj_zza = (zza) obj;
            return com_google_android_gms_internal_zzbuj_zza.zzcqu.equals(this.zzcqu) && com_google_android_gms_internal_zzbuj_zza.zzw == this.zzw && com_google_android_gms_internal_zzbuj_zza.mActivity == this.mActivity;
        }

        @NonNull
        public Activity getActivity() {
            return this.mActivity;
        }

        public int hashCode() {
            return this.zzcqu.hashCode();
        }

        @NonNull
        public Runnable zzUN() {
            return this.zzw;
        }

        @NonNull
        public Object zzadC() {
            return this.zzcqu;
        }
    }

    private static class zzb extends zzabe {
        private final List<zza> mListeners = new ArrayList();

        private zzb(zzabf com_google_android_gms_internal_zzabf) {
            super(com_google_android_gms_internal_zzabf);
            this.zzaCR.zza("StorageOnStopCallback", (zzabe) this);
        }

        public static zzb zzx(Activity activity) {
            zzabf zzc = zzabe.zzc(new zzabd(activity));
            zzb com_google_android_gms_internal_zzbuj_zzb = (zzb) zzc.zza("StorageOnStopCallback", zzb.class);
            return com_google_android_gms_internal_zzbuj_zzb == null ? new zzb(zzc) : com_google_android_gms_internal_zzbuj_zzb;
        }

        @MainThread
        public void onStop() {
            ArrayList arrayList;
            synchronized (this.mListeners) {
                arrayList = new ArrayList(this.mListeners);
                this.mListeners.clear();
            }
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                zza com_google_android_gms_internal_zzbuj_zza = (zza) it.next();
                if (com_google_android_gms_internal_zzbuj_zza != null) {
                    Log.d("StorageOnStopCallback", "removing subscription from activity.");
                    com_google_android_gms_internal_zzbuj_zza.zzUN().run();
                    zzbuj.zzadB().zzaL(com_google_android_gms_internal_zzbuj_zza.zzadC());
                }
            }
        }

        public void zza(zza com_google_android_gms_internal_zzbuj_zza) {
            synchronized (this.mListeners) {
                this.mListeners.add(com_google_android_gms_internal_zzbuj_zza);
            }
        }

        public void zzb(zza com_google_android_gms_internal_zzbuj_zza) {
            synchronized (this.mListeners) {
                this.mListeners.remove(com_google_android_gms_internal_zzbuj_zza);
            }
        }
    }

    private zzbuj() {
    }

    @NonNull
    public static zzbuj zzadB() {
        return zzcqr;
    }

    public void zza(@NonNull Activity activity, @NonNull Object obj, @NonNull Runnable runnable) {
        synchronized (this.zzcqt) {
            zza com_google_android_gms_internal_zzbuj_zza = new zza(activity, runnable, obj);
            zzb.zzx(activity).zza(com_google_android_gms_internal_zzbuj_zza);
            this.zzcqs.put(obj, com_google_android_gms_internal_zzbuj_zza);
        }
    }

    public void zzaL(@NonNull Object obj) {
        synchronized (this.zzcqt) {
            zza com_google_android_gms_internal_zzbuj_zza = (zza) this.zzcqs.get(obj);
            if (com_google_android_gms_internal_zzbuj_zza != null) {
                zzb.zzx(com_google_android_gms_internal_zzbuj_zza.getActivity()).zzb(com_google_android_gms_internal_zzbuj_zza);
            }
        }
    }
}
