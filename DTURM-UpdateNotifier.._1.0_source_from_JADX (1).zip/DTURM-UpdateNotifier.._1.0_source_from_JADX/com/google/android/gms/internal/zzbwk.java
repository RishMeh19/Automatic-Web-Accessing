package com.google.android.gms.internal;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Collection;

public final class zzbwk implements zzbvt {
    private final zzbwa zzcqW;

    private static final class zza<E> extends zzbvs<Collection<E>> {
        private final zzbvs<E> zzcsC;
        private final zzbwf<? extends Collection<E>> zzcsD;

        public zza(zzbva com_google_android_gms_internal_zzbva, Type type, zzbvs<E> com_google_android_gms_internal_zzbvs_E, zzbwf<? extends Collection<E>> com_google_android_gms_internal_zzbwf__extends_java_util_Collection_E) {
            this.zzcsC = new zzbwu(com_google_android_gms_internal_zzbva, com_google_android_gms_internal_zzbvs_E, type);
            this.zzcsD = com_google_android_gms_internal_zzbwf__extends_java_util_Collection_E;
        }

        public void zza(zzbwz com_google_android_gms_internal_zzbwz, Collection<E> collection) throws IOException {
            if (collection == null) {
                com_google_android_gms_internal_zzbwz.zzaex();
                return;
            }
            com_google_android_gms_internal_zzbwz.zzaet();
            for (E zza : collection) {
                this.zzcsC.zza(com_google_android_gms_internal_zzbwz, zza);
            }
            com_google_android_gms_internal_zzbwz.zzaeu();
        }

        public /* synthetic */ Object zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
            return zzj(com_google_android_gms_internal_zzbwx);
        }

        public Collection<E> zzj(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
            if (com_google_android_gms_internal_zzbwx.zzaen() == zzbwy.NULL) {
                com_google_android_gms_internal_zzbwx.nextNull();
                return null;
            }
            Collection<E> collection = (Collection) this.zzcsD.zzaeg();
            com_google_android_gms_internal_zzbwx.beginArray();
            while (com_google_android_gms_internal_zzbwx.hasNext()) {
                collection.add(this.zzcsC.zzb(com_google_android_gms_internal_zzbwx));
            }
            com_google_android_gms_internal_zzbwx.endArray();
            return collection;
        }
    }

    public zzbwk(zzbwa com_google_android_gms_internal_zzbwa) {
        this.zzcqW = com_google_android_gms_internal_zzbwa;
    }

    public <T> zzbvs<T> zza(zzbva com_google_android_gms_internal_zzbva, zzbww<T> com_google_android_gms_internal_zzbww_T) {
        Type zzaez = com_google_android_gms_internal_zzbww_T.zzaez();
        Class zzaey = com_google_android_gms_internal_zzbww_T.zzaey();
        if (!Collection.class.isAssignableFrom(zzaey)) {
            return null;
        }
        Type zza = zzbvz.zza(zzaez, zzaey);
        return new zza(com_google_android_gms_internal_zzbva, zza, com_google_android_gms_internal_zzbva.zza(zzbww.zzl(zza)), this.zzcqW.zzb(com_google_android_gms_internal_zzbww_T));
    }
}
