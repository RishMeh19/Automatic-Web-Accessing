package com.google.android.gms.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.zzaa;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;

public class zztp extends com.google.android.gms.common.internal.safeparcel.zza {
    public static final Creator<zztp> CREATOR = new zztq();
    public final Account account;
    final zztt[] zzahb;
    public final String zzahc;
    public final boolean zzahd;

    public static class zza {
        private List<zztt> zzahe;
        private String zzahf;
        private boolean zzahg;
        private Account zzahh;

        public zza zzX(boolean z) {
            this.zzahg = z;
            return this;
        }

        public zza zza(zztt com_google_android_gms_internal_zztt) {
            if (this.zzahe == null && com_google_android_gms_internal_zztt != null) {
                this.zzahe = new ArrayList();
            }
            if (com_google_android_gms_internal_zztt != null) {
                this.zzahe.add(com_google_android_gms_internal_zztt);
            }
            return this;
        }

        public zza zzb(Account account) {
            this.zzahh = account;
            return this;
        }

        public zza zzcl(String str) {
            this.zzahf = str;
            return this;
        }

        public zztp zzqE() {
            return new zztp(this.zzahf, this.zzahg, this.zzahh, this.zzahe != null ? (zztt[]) this.zzahe.toArray(new zztt[this.zzahe.size()]) : null);
        }
    }

    zztp(String str, boolean z, Account account, zztt... com_google_android_gms_internal_zzttArr) {
        this(com_google_android_gms_internal_zzttArr, str, z, account);
        if (com_google_android_gms_internal_zzttArr != null) {
            BitSet bitSet = new BitSet(zzua.zzqG());
            for (zztt com_google_android_gms_internal_zztt : com_google_android_gms_internal_zzttArr) {
                int i = com_google_android_gms_internal_zztt.zzaho;
                if (i != -1) {
                    if (bitSet.get(i)) {
                        String str2 = "Duplicate global search section type ";
                        String valueOf = String.valueOf(zzua.zzaP(i));
                        throw new IllegalArgumentException(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
                    }
                    bitSet.set(i);
                }
            }
        }
    }

    zztp(zztt[] com_google_android_gms_internal_zzttArr, String str, boolean z, Account account) {
        this.zzahb = com_google_android_gms_internal_zzttArr;
        this.zzahc = str;
        this.zzahd = z;
        this.account = account;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof zztp)) {
            return false;
        }
        zztp com_google_android_gms_internal_zztp = (zztp) obj;
        return zzaa.equal(this.zzahc, com_google_android_gms_internal_zztp.zzahc) && zzaa.equal(Boolean.valueOf(this.zzahd), Boolean.valueOf(com_google_android_gms_internal_zztp.zzahd)) && zzaa.equal(this.account, com_google_android_gms_internal_zztp.account) && Arrays.equals(zzqD(), com_google_android_gms_internal_zztp.zzqD());
    }

    public int hashCode() {
        return zzaa.hashCode(this.zzahc, Boolean.valueOf(this.zzahd), this.account, Integer.valueOf(Arrays.hashCode(this.zzahb)));
    }

    public void writeToParcel(Parcel parcel, int i) {
        zztq.zza(this, parcel, i);
    }

    public zztt[] zzqD() {
        return this.zzahb;
    }
}
