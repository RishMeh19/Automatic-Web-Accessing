package com.google.android.gms.internal;

import java.util.AbstractMap.SimpleEntry;
import java.util.Comparator;
import java.util.EmptyStackException;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Stack;

public class zzbnz<K, V> implements Iterator<Entry<K, V>> {
    private final Stack<zzbof<K, V>> zzcaW = new Stack();
    private final boolean zzcaX;

    zzbnz(zzbod<K, V> com_google_android_gms_internal_zzbod_K__V, K k, Comparator<K> comparator, boolean z) {
        this.zzcaX = z;
        zzbod com_google_android_gms_internal_zzbod = com_google_android_gms_internal_zzbod_K__V;
        while (!com_google_android_gms_internal_zzbod.isEmpty()) {
            int compare = k != null ? z ? comparator.compare(k, com_google_android_gms_internal_zzbod.getKey()) : comparator.compare(com_google_android_gms_internal_zzbod.getKey(), k) : 1;
            if (compare < 0) {
                com_google_android_gms_internal_zzbod = z ? com_google_android_gms_internal_zzbod.zzXe() : com_google_android_gms_internal_zzbod.zzXf();
            } else if (compare == 0) {
                this.zzcaW.push((zzbof) com_google_android_gms_internal_zzbod);
                return;
            } else {
                this.zzcaW.push((zzbof) com_google_android_gms_internal_zzbod);
                com_google_android_gms_internal_zzbod = z ? com_google_android_gms_internal_zzbod.zzXf() : com_google_android_gms_internal_zzbod.zzXe();
            }
        }
    }

    public boolean hasNext() {
        return this.zzcaW.size() > 0;
    }

    public Entry<K, V> next() {
        try {
            zzbof com_google_android_gms_internal_zzbof = (zzbof) this.zzcaW.pop();
            Entry simpleEntry = new SimpleEntry(com_google_android_gms_internal_zzbof.getKey(), com_google_android_gms_internal_zzbof.getValue());
            zzbod zzXe;
            if (this.zzcaX) {
                for (zzXe = com_google_android_gms_internal_zzbof.zzXe(); !zzXe.isEmpty(); zzXe = zzXe.zzXf()) {
                    this.zzcaW.push((zzbof) zzXe);
                }
            } else {
                for (zzXe = com_google_android_gms_internal_zzbof.zzXf(); !zzXe.isEmpty(); zzXe = zzXe.zzXe()) {
                    this.zzcaW.push((zzbof) zzXe);
                }
            }
            return simpleEntry;
        } catch (EmptyStackException e) {
            throw new NoSuchElementException();
        }
    }

    public void remove() {
        throw new UnsupportedOperationException("remove called on immutable collection");
    }
}
