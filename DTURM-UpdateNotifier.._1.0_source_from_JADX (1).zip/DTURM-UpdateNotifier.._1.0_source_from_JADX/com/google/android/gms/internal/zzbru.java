package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbsc.zza;

public class zzbru extends zzbrz<zzbru> {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbru.class.desiredAssertionStatus());
    private final Double zzcjn;

    public zzbru(Double d, zzbsc com_google_android_gms_internal_zzbsc) {
        super(com_google_android_gms_internal_zzbsc);
        this.zzcjn = d;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof zzbru)) {
            return false;
        }
        zzbru com_google_android_gms_internal_zzbru = (zzbru) obj;
        return this.zzcjn.equals(com_google_android_gms_internal_zzbru.zzcjn) && this.zzciX.equals(com_google_android_gms_internal_zzbru.zzciX);
    }

    public Object getValue() {
        return this.zzcjn;
    }

    public int hashCode() {
        return this.zzcjn.hashCode() + this.zzciX.hashCode();
    }

    protected int zza(zzbru com_google_android_gms_internal_zzbru) {
        return this.zzcjn.compareTo(com_google_android_gms_internal_zzbru.zzcjn);
    }

    public String zza(zza com_google_android_gms_internal_zzbsc_zza) {
        String valueOf = String.valueOf(String.valueOf(zzb(com_google_android_gms_internal_zzbsc_zza)).concat("number:"));
        String valueOf2 = String.valueOf(zzbte.zzl(this.zzcjn.doubleValue()));
        return valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf);
    }

    protected zza zzaaH() {
        return zza.Number;
    }

    public /* synthetic */ zzbsc zzg(zzbsc com_google_android_gms_internal_zzbsc) {
        return zzk(com_google_android_gms_internal_zzbsc);
    }

    public zzbru zzk(zzbsc com_google_android_gms_internal_zzbsc) {
        if ($assertionsDisabled || zzbsg.zzq(com_google_android_gms_internal_zzbsc)) {
            return new zzbru(this.zzcjn, com_google_android_gms_internal_zzbsc);
        }
        throw new AssertionError();
    }
}
