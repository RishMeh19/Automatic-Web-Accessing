package com.google.android.gms.internal;

import java.io.IOException;
import java.sql.Time;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public final class zzbwt extends zzbvs<Time> {
    public static final zzbvt zzcsz = new C05641();
    private final DateFormat zzcsZ = new SimpleDateFormat("hh:mm:ss a");

    static class C05641 implements zzbvt {
        C05641() {
        }

        public <T> zzbvs<T> zza(zzbva com_google_android_gms_internal_zzbva, zzbww<T> com_google_android_gms_internal_zzbww_T) {
            return com_google_android_gms_internal_zzbww_T.zzaey() == Time.class ? new zzbwt() : null;
        }
    }

    public synchronized void zza(zzbwz com_google_android_gms_internal_zzbwz, Time time) throws IOException {
        com_google_android_gms_internal_zzbwz.zzkp(time == null ? null : this.zzcsZ.format(time));
    }

    public /* synthetic */ Object zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
        return zzn(com_google_android_gms_internal_zzbwx);
    }

    public synchronized Time zzn(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
        Time time;
        if (com_google_android_gms_internal_zzbwx.zzaen() == zzbwy.NULL) {
            com_google_android_gms_internal_zzbwx.nextNull();
            time = null;
        } else {
            try {
                time = new Time(this.zzcsZ.parse(com_google_android_gms_internal_zzbwx.nextString()).getTime());
            } catch (Throwable e) {
                throw new zzbvp(e);
            }
        }
        return time;
    }
}
