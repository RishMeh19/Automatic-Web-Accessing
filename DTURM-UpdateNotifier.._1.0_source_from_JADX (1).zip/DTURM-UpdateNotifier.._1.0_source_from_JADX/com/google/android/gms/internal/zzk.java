package com.google.android.gms.internal;

public class zzk extends zzi {
    public zzk(Throwable th) {
        super(th);
    }
}
