package com.google.android.gms.internal;

public class zzd extends zzq {
    public zzd(zzj com_google_android_gms_internal_zzj) {
        super(com_google_android_gms_internal_zzj);
    }
}
