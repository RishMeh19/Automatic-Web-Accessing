package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class zzbml extends zza {
    public static final Creator<zzbml> CREATOR = new zzbmm();
    @zzbmb
    public final int zzaiI;
    private List<zzbmj> zzbYF;

    public zzbml() {
        this.zzaiI = 1;
        this.zzbYF = new ArrayList();
    }

    zzbml(int i, List<zzbmj> list) {
        this.zzaiI = i;
        this.zzbYF = list == null ? Collections.emptyList() : Collections.unmodifiableList(list);
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzbmm.zza(this, parcel, i);
    }

    public List<zzbmj> zzWd() {
        return this.zzbYF;
    }
}
