package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

public class zzbpy {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbpy.class.desiredAssertionStatus());
    private static final zzbqr<zzbpv> zzcgz = new C05182();
    private zzboy zzcgw = zzboy.zzYq();
    private List<zzbpv> zzcgx = new ArrayList();
    private Long zzcgy = Long.valueOf(-1);

    class C05182 implements zzbqr<zzbpv> {
        C05182() {
        }

        public boolean zza(zzbpv com_google_android_gms_internal_zzbpv) {
            return com_google_android_gms_internal_zzbpv.isVisible();
        }

        public /* synthetic */ boolean zzat(Object obj) {
            return zza((zzbpv) obj);
        }
    }

    private void zzZv() {
        this.zzcgw = zza(this.zzcgx, zzcgz, zzbph.zzYR());
        if (this.zzcgx.size() > 0) {
            this.zzcgy = Long.valueOf(((zzbpv) this.zzcgx.get(this.zzcgx.size() - 1)).zzZo());
        } else {
            this.zzcgy = Long.valueOf(-1);
        }
    }

    private static zzboy zza(List<zzbpv> list, zzbqr<zzbpv> com_google_android_gms_internal_zzbqr_com_google_android_gms_internal_zzbpv, zzbph com_google_android_gms_internal_zzbph) {
        zzboy zzYq = zzboy.zzYq();
        zzboy com_google_android_gms_internal_zzboy = zzYq;
        for (zzbpv com_google_android_gms_internal_zzbpv : list) {
            if (com_google_android_gms_internal_zzbqr_com_google_android_gms_internal_zzbpv.zzat(com_google_android_gms_internal_zzbpv)) {
                zzbph zzWO = com_google_android_gms_internal_zzbpv.zzWO();
                if (com_google_android_gms_internal_zzbpv.zzZr()) {
                    if (com_google_android_gms_internal_zzbph.zzi(zzWO)) {
                        zzYq = com_google_android_gms_internal_zzboy.zze(zzbph.zza(com_google_android_gms_internal_zzbph, zzWO), com_google_android_gms_internal_zzbpv.zzZp());
                    } else if (zzWO.zzi(com_google_android_gms_internal_zzbph)) {
                        zzYq = com_google_android_gms_internal_zzboy.zze(zzbph.zzYR(), com_google_android_gms_internal_zzbpv.zzZp().zzO(zzbph.zza(zzWO, com_google_android_gms_internal_zzbph)));
                    }
                    com_google_android_gms_internal_zzboy = zzYq;
                } else {
                    if (com_google_android_gms_internal_zzbph.zzi(zzWO)) {
                        zzYq = com_google_android_gms_internal_zzboy.zzb(zzbph.zza(com_google_android_gms_internal_zzbph, zzWO), com_google_android_gms_internal_zzbpv.zzZq());
                    } else if (zzWO.zzi(com_google_android_gms_internal_zzbph)) {
                        zzWO = zzbph.zza(zzWO, com_google_android_gms_internal_zzbph);
                        if (zzWO.isEmpty()) {
                            zzYq = com_google_android_gms_internal_zzboy.zzb(zzbph.zzYR(), com_google_android_gms_internal_zzbpv.zzZq());
                        } else {
                            zzbsc zzf = com_google_android_gms_internal_zzbpv.zzZq().zzf(zzWO);
                            if (zzf != null) {
                                zzYq = com_google_android_gms_internal_zzboy.zze(zzbph.zzYR(), zzf);
                            }
                        }
                    }
                    com_google_android_gms_internal_zzboy = zzYq;
                }
            }
            zzYq = com_google_android_gms_internal_zzboy;
            com_google_android_gms_internal_zzboy = zzYq;
        }
        return com_google_android_gms_internal_zzboy;
    }

    private boolean zza(zzbpv com_google_android_gms_internal_zzbpv, zzbph com_google_android_gms_internal_zzbph) {
        if (com_google_android_gms_internal_zzbpv.zzZr()) {
            return com_google_android_gms_internal_zzbpv.zzWO().zzi(com_google_android_gms_internal_zzbph);
        }
        Iterator it = com_google_android_gms_internal_zzbpv.zzZq().iterator();
        while (it.hasNext()) {
            if (com_google_android_gms_internal_zzbpv.zzWO().zzh((zzbph) ((Entry) it.next()).getKey()).zzi(com_google_android_gms_internal_zzbph)) {
                return true;
            }
        }
        return false;
    }

    public List<zzbpv> zzZu() {
        List arrayList = new ArrayList(this.zzcgx);
        this.zzcgw = zzboy.zzYq();
        this.zzcgx = new ArrayList();
        return arrayList;
    }

    public zzbsb zza(zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc, zzbsb com_google_android_gms_internal_zzbsb, boolean z, zzbrw com_google_android_gms_internal_zzbrw) {
        zzbsb com_google_android_gms_internal_zzbsb2 = null;
        zzboy zzg = this.zzcgw.zzg(com_google_android_gms_internal_zzbph);
        zzbsc zzf = zzg.zzf(zzbph.zzYR());
        if (zzf == null) {
            if (com_google_android_gms_internal_zzbsc != null) {
                zzf = zzg.zzb(com_google_android_gms_internal_zzbsc);
            }
            return com_google_android_gms_internal_zzbsb2;
        }
        for (zzbsb com_google_android_gms_internal_zzbsb3 : r0) {
            zzbsb com_google_android_gms_internal_zzbsb32;
            if (com_google_android_gms_internal_zzbrw.zza(com_google_android_gms_internal_zzbsb32, com_google_android_gms_internal_zzbsb, z) <= 0 || (com_google_android_gms_internal_zzbsb2 != null && com_google_android_gms_internal_zzbrw.zza(com_google_android_gms_internal_zzbsb32, com_google_android_gms_internal_zzbsb2, z) >= 0)) {
                com_google_android_gms_internal_zzbsb32 = com_google_android_gms_internal_zzbsb2;
            }
            com_google_android_gms_internal_zzbsb2 = com_google_android_gms_internal_zzbsb32;
        }
        return com_google_android_gms_internal_zzbsb2;
    }

    public zzbsc zza(zzbph com_google_android_gms_internal_zzbph, zzbph com_google_android_gms_internal_zzbph2, zzbsc com_google_android_gms_internal_zzbsc, zzbsc com_google_android_gms_internal_zzbsc2) {
        if (!$assertionsDisabled && com_google_android_gms_internal_zzbsc == null && com_google_android_gms_internal_zzbsc2 == null) {
            throw new AssertionError("Either existingEventSnap or existingServerSnap must exist");
        }
        zzbph zzh = com_google_android_gms_internal_zzbph.zzh(com_google_android_gms_internal_zzbph2);
        if (this.zzcgw.zze(zzh)) {
            return null;
        }
        zzboy zzg = this.zzcgw.zzg(zzh);
        return zzg.isEmpty() ? com_google_android_gms_internal_zzbsc2.zzO(com_google_android_gms_internal_zzbph2) : zzg.zzb(com_google_android_gms_internal_zzbsc2.zzO(com_google_android_gms_internal_zzbph2));
    }

    public zzbsc zza(zzbph com_google_android_gms_internal_zzbph, zzbrq com_google_android_gms_internal_zzbrq, zzbqu com_google_android_gms_internal_zzbqu) {
        zzbph zza = com_google_android_gms_internal_zzbph.zza(com_google_android_gms_internal_zzbrq);
        zzbsc zzf = this.zzcgw.zzf(zza);
        return zzf != null ? zzf : com_google_android_gms_internal_zzbqu.zzf(com_google_android_gms_internal_zzbrq) ? this.zzcgw.zzg(zza).zzb(com_google_android_gms_internal_zzbqu.zzWK().zzm(com_google_android_gms_internal_zzbrq)) : null;
    }

    public zzbsc zza(final zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc, final List<Long> list, final boolean z) {
        zzboy zzg;
        if (!list.isEmpty() || z) {
            zzg = this.zzcgw.zzg(com_google_android_gms_internal_zzbph);
            if (!z && zzg.isEmpty()) {
                return com_google_android_gms_internal_zzbsc;
            }
            if (!z && com_google_android_gms_internal_zzbsc == null && !zzg.zze(zzbph.zzYR())) {
                return null;
            }
            zzg = zza(this.zzcgx, new zzbqr<zzbpv>(this) {
                public boolean zza(zzbpv com_google_android_gms_internal_zzbpv) {
                    return (com_google_android_gms_internal_zzbpv.isVisible() || z) && !list.contains(Long.valueOf(com_google_android_gms_internal_zzbpv.zzZo())) && (com_google_android_gms_internal_zzbpv.zzWO().zzi(com_google_android_gms_internal_zzbph) || com_google_android_gms_internal_zzbph.zzi(com_google_android_gms_internal_zzbpv.zzWO()));
                }

                public /* synthetic */ boolean zzat(Object obj) {
                    return zza((zzbpv) obj);
                }
            }, com_google_android_gms_internal_zzbph);
            if (com_google_android_gms_internal_zzbsc == null) {
                com_google_android_gms_internal_zzbsc = zzbrv.zzabb();
            }
            return zzg.zzb(com_google_android_gms_internal_zzbsc);
        }
        zzbsc zzf = this.zzcgw.zzf(com_google_android_gms_internal_zzbph);
        if (zzf != null) {
            return zzf;
        }
        zzg = this.zzcgw.zzg(com_google_android_gms_internal_zzbph);
        if (zzg.isEmpty()) {
            return com_google_android_gms_internal_zzbsc;
        }
        if (com_google_android_gms_internal_zzbsc == null && !zzg.zze(zzbph.zzYR())) {
            return null;
        }
        if (com_google_android_gms_internal_zzbsc == null) {
            com_google_android_gms_internal_zzbsc = zzbrv.zzabb();
        }
        return zzg.zzb(com_google_android_gms_internal_zzbsc);
    }

    public void zza(zzbph com_google_android_gms_internal_zzbph, zzboy com_google_android_gms_internal_zzboy, Long l) {
        if ($assertionsDisabled || l.longValue() > this.zzcgy.longValue()) {
            this.zzcgx.add(new zzbpv(l.longValue(), com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzboy));
            this.zzcgw = this.zzcgw.zzb(com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzboy);
            this.zzcgy = l;
            return;
        }
        throw new AssertionError();
    }

    public void zza(zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc, Long l, boolean z) {
        if ($assertionsDisabled || l.longValue() > this.zzcgy.longValue()) {
            this.zzcgx.add(new zzbpv(l.longValue(), com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbsc, z));
            if (z) {
                this.zzcgw = this.zzcgw.zze(com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbsc);
            }
            this.zzcgy = l;
            return;
        }
        throw new AssertionError();
    }

    public zzbpv zzaP(long j) {
        for (zzbpv com_google_android_gms_internal_zzbpv : this.zzcgx) {
            if (com_google_android_gms_internal_zzbpv.zzZo() == j) {
                return com_google_android_gms_internal_zzbpv;
            }
        }
        return null;
    }

    public boolean zzaQ(long j) {
        zzbpv com_google_android_gms_internal_zzbpv = null;
        int i = 0;
        for (zzbpv com_google_android_gms_internal_zzbpv2 : this.zzcgx) {
            zzbpv com_google_android_gms_internal_zzbpv22;
            if (com_google_android_gms_internal_zzbpv22.zzZo() == j) {
                com_google_android_gms_internal_zzbpv = com_google_android_gms_internal_zzbpv22;
                break;
            }
            i++;
        }
        if ($assertionsDisabled || com_google_android_gms_internal_zzbpv != null) {
            this.zzcgx.remove(com_google_android_gms_internal_zzbpv);
            boolean isVisible = com_google_android_gms_internal_zzbpv.isVisible();
            int size = this.zzcgx.size() - 1;
            boolean z = false;
            while (isVisible && size >= 0) {
                boolean z2;
                com_google_android_gms_internal_zzbpv22 = (zzbpv) this.zzcgx.get(size);
                if (com_google_android_gms_internal_zzbpv22.isVisible()) {
                    if (size >= i && zza(com_google_android_gms_internal_zzbpv22, com_google_android_gms_internal_zzbpv.zzWO())) {
                        z2 = z;
                        z = false;
                        size--;
                        isVisible = z;
                        z = z2;
                    } else if (com_google_android_gms_internal_zzbpv.zzWO().zzi(com_google_android_gms_internal_zzbpv22.zzWO())) {
                        z2 = true;
                        z = isVisible;
                        size--;
                        isVisible = z;
                        z = z2;
                    }
                }
                z2 = z;
                z = isVisible;
                size--;
                isVisible = z;
                z = z2;
            }
            if (!isVisible) {
                return false;
            }
            if (z) {
                zzZv();
                return true;
            } else if (com_google_android_gms_internal_zzbpv.zzZr()) {
                this.zzcgw = this.zzcgw.zzd(com_google_android_gms_internal_zzbpv.zzWO());
                return true;
            } else {
                Iterator it = com_google_android_gms_internal_zzbpv.zzZq().iterator();
                while (it.hasNext()) {
                    this.zzcgw = this.zzcgw.zzd(com_google_android_gms_internal_zzbpv.zzWO().zzh((zzbph) ((Entry) it.next()).getKey()));
                }
                return true;
            }
        }
        throw new AssertionError("removeWrite called with nonexistent writeId");
    }

    public zzbsc zzj(zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc) {
        zzbrv zzabb = zzbrv.zzabb();
        zzbsc<zzbsb> zzf = this.zzcgw.zzf(com_google_android_gms_internal_zzbph);
        zzbsc com_google_android_gms_internal_zzbsc2;
        if (zzf == null) {
            zzboy zzg = this.zzcgw.zzg(com_google_android_gms_internal_zzbph);
            com_google_android_gms_internal_zzbsc2 = zzabb;
            for (zzbsb com_google_android_gms_internal_zzbsb : com_google_android_gms_internal_zzbsc) {
                com_google_android_gms_internal_zzbsc2 = com_google_android_gms_internal_zzbsc2.zze(com_google_android_gms_internal_zzbsb.zzabl(), zzg.zzg(new zzbph(com_google_android_gms_internal_zzbsb.zzabl())).zzb(com_google_android_gms_internal_zzbsb.zzWK()));
            }
            for (zzbsb com_google_android_gms_internal_zzbsb2 : zzg.zzYs()) {
                com_google_android_gms_internal_zzbsc2 = com_google_android_gms_internal_zzbsc2.zze(com_google_android_gms_internal_zzbsb2.zzabl(), com_google_android_gms_internal_zzbsb2.zzWK());
            }
            return com_google_android_gms_internal_zzbsc2;
        } else if (zzf.zzaaP()) {
            return zzabb;
        } else {
            com_google_android_gms_internal_zzbsc2 = zzabb;
            for (zzbsb com_google_android_gms_internal_zzbsb22 : zzf) {
                com_google_android_gms_internal_zzbsc2 = com_google_android_gms_internal_zzbsc2.zze(com_google_android_gms_internal_zzbsb22.zzabl(), com_google_android_gms_internal_zzbsb22.zzWK());
            }
            return com_google_android_gms_internal_zzbsc2;
        }
    }

    public zzbpz zzu(zzbph com_google_android_gms_internal_zzbph) {
        return new zzbpz(com_google_android_gms_internal_zzbph, this);
    }

    public zzbsc zzv(zzbph com_google_android_gms_internal_zzbph) {
        return this.zzcgw.zzf(com_google_android_gms_internal_zzbph);
    }
}
