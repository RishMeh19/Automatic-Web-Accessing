package com.google.android.gms.internal;

public interface zzo {
    void zza(zzl<?> com_google_android_gms_internal_zzl_, zzn<?> com_google_android_gms_internal_zzn_);

    void zza(zzl<?> com_google_android_gms_internal_zzl_, zzn<?> com_google_android_gms_internal_zzn_, Runnable runnable);

    void zza(zzl<?> com_google_android_gms_internal_zzl_, zzs com_google_android_gms_internal_zzs);
}
