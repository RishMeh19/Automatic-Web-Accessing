package com.google.android.gms.internal;

import java.lang.reflect.Type;

public interface zzbvo<T> {
    zzbvg zza(T t, Type type, zzbvn com_google_android_gms_internal_zzbvn);
}
