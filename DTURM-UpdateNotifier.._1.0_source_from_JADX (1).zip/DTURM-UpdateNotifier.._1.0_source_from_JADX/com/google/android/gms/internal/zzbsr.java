package com.google.android.gms.internal;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.SocketTimeoutException;

class zzbsr {
    private zzbsn zzcjT = null;
    private DataInputStream zzcko = null;
    private zzbsm zzckp = null;
    private byte[] zzckq = new byte[112];
    private zzb zzckr;
    private volatile boolean zzcks = false;

    zzbsr(zzbsm com_google_android_gms_internal_zzbsm) {
        this.zzckp = com_google_android_gms_internal_zzbsm;
    }

    private int read(byte[] bArr, int i, int i2) throws IOException {
        this.zzcko.readFully(bArr, i, i2);
        return i2;
    }

    private void zzZ(byte[] bArr) {
        if (bArr.length <= 125) {
            this.zzckp.zzY(bArr);
            return;
        }
        throw new zzbso("PING frame too long");
    }

    private void zza(boolean z, byte b, byte[] bArr) {
        if (b == (byte) 9) {
            if (z) {
                zzZ(bArr);
                return;
            }
            throw new zzbso("PING must not fragment across frames");
        } else if (this.zzckr != null && b != (byte) 0) {
            throw new zzbso("Failed to continue outstanding frame");
        } else if (this.zzckr == null && b == (byte) 0) {
            throw new zzbso("Received continuing frame, but there's nothing to continue");
        } else {
            if (this.zzckr == null) {
                this.zzckr = zzbsk.zzb(b);
            }
            if (!this.zzckr.zzW(bArr)) {
                throw new zzbso("Failed to decode frame");
            } else if (z) {
                zzbsq zzabp = this.zzckr.zzabp();
                this.zzckr = null;
                this.zzcjT.zza(zzabp);
            }
        }
    }

    private void zzc(zzbso com_google_android_gms_internal_zzbso) {
        zzabC();
        this.zzckp.zzb(com_google_android_gms_internal_zzbso);
    }

    private long zze(byte[] bArr, int i) {
        return (((((((((long) bArr[i + 0]) << 56) + (((long) (bArr[i + 1] & 255)) << 48)) + (((long) (bArr[i + 2] & 255)) << 40)) + (((long) (bArr[i + 3] & 255)) << 32)) + (((long) (bArr[i + 4] & 255)) << 24)) + ((long) ((bArr[i + 5] & 255) << 16))) + ((long) ((bArr[i + 6] & 255) << 8))) + ((long) ((bArr[i + 7] & 255) << 0));
    }

    void run() {
        this.zzcjT = this.zzckp.zzabt();
        while (!this.zzcks) {
            try {
                int read = read(this.zzckq, 0, 1) + 0;
                boolean z = (this.zzckq[0] & 128) != 0;
                if (((this.zzckq[0] & 112) != 0 ? 1 : null) != null) {
                    throw new zzbso("Invalid frame received");
                }
                byte b = (byte) (this.zzckq[0] & 15);
                int read2 = read + read(this.zzckq, read, 1);
                byte b2 = this.zzckq[1];
                long j = 0;
                if (b2 < (byte) 126) {
                    j = (long) b2;
                } else if (b2 == (byte) 126) {
                    read(this.zzckq, read2, 2);
                    j = (long) (((this.zzckq[2] & 255) << 8) | (this.zzckq[3] & 255));
                } else if (b2 == Byte.MAX_VALUE) {
                    j = zze(this.zzckq, (read(this.zzckq, read2, 8) + read2) - 8);
                }
                byte[] bArr = new byte[((int) j)];
                read(bArr, 0, (int) j);
                if (b == (byte) 8) {
                    this.zzckp.zzabu();
                } else if (b == (byte) 10) {
                    continue;
                } else if (b == (byte) 1 || b == (byte) 2 || b == (byte) 9 || b == (byte) 0) {
                    zza(z, b, bArr);
                } else {
                    throw new zzbso("Unsupported opcode: " + b);
                }
            } catch (SocketTimeoutException e) {
            } catch (Throwable e2) {
                zzc(new zzbso("IO Error", e2));
            } catch (zzbso e3) {
                zzc(e3);
            }
        }
    }

    void zza(DataInputStream dataInputStream) {
        this.zzcko = dataInputStream;
    }

    void zzabC() {
        this.zzcks = true;
    }
}
