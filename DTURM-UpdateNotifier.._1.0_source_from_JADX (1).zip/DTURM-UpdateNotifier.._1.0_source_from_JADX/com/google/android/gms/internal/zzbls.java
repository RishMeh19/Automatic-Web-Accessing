package com.google.android.gms.internal;

import android.content.Context;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import com.google.android.gms.common.api.Api.ApiOptions;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.ActionCodeResult;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.EmailAuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuthProvider;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GetTokenResult;
import com.google.firebase.auth.ProviderQueryResult;
import com.google.firebase.auth.UserProfileChangeRequest;
import java.util.ArrayList;
import java.util.List;

public class zzbls extends com.google.android.gms.common.api.zzc<com.google.android.gms.internal.zzbma.zza> {

    static final class zza extends zzbmd<Void, zzbmz> {
        @NonNull
        private final String zzaZU;

        public zza(@NonNull String str) {
            super(7);
            this.zzaZU = zzac.zzh(str, "code cannot be null or empty");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zzj(this.zzaZU, this.zzbYl);
        }

        public void zzVQ() {
            zzVW();
        }
    }

    static final class zzb extends zzbmd<ActionCodeResult, zzbmz> {
        @NonNull
        private final String zzaZU;

        public zzb(@NonNull String str) {
            super(4);
            this.zzaZU = zzac.zzh(str, "code cannot be null or empty");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zzi(this.zzaZU, this.zzbYl);
        }

        public void zzVQ() {
            zzaf(new zzbnb(this.zzbYt));
        }
    }

    static final class zzc extends zzbmd<Void, zzbmz> {
        @NonNull
        private final String zzaZU;
        @NonNull
        private final String zzbXY;

        public zzc(@NonNull String str, @NonNull String str2) {
            super(4);
            this.zzaZU = zzac.zzh(str, "code cannot be null or empty");
            this.zzbXY = zzac.zzh(str2, "new password cannot be null or empty");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zzf(this.zzaZU, this.zzbXY, this.zzbYl);
        }

        public void zzVQ() {
            zzVW();
        }
    }

    static final class zzd extends zzbmd<AuthResult, zzbmz> {
        @NonNull
        private String zzajh;
        @NonNull
        private String zzaka;

        public zzd(@NonNull String str, @NonNull String str2) {
            super(2);
            this.zzaka = zzac.zzh(str, "email cannot be null or empty");
            this.zzajh = zzac.zzh(str2, "password cannot be null or empty");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zzc(this.zzaka, this.zzajh, this.zzbYl);
        }

        public void zzVQ() {
            FirebaseUser zzb = zzbls.zza(this.zzbXI, this.zzbYr);
            ((zzbmz) this.zzbYo).zza(this.zzbYq, zzb);
            zzaf(new zzbnc(zzb));
        }
    }

    static final class zze extends zzbmd<Void, zzbni> {
        public zze() {
            super(5);
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zzg(this.zzbYm.zzVJ(), this.zzbYl);
        }

        public void zzVQ() {
            ((zzbni) this.zzbYo).zzVG();
            zzaf(null);
        }
    }

    static final class zzf extends zzbmd<ProviderQueryResult, zzbmz> {
        @NonNull
        private final String zzaka;

        public zzf(@NonNull String str) {
            super(3);
            this.zzaka = zzac.zzh(str, "email cannot be null or empty");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zzc(this.zzaka, this.zzbYl);
        }

        public void zzVQ() {
            zzaf(new zzbng(this.zzbYs));
        }
    }

    static final class zzg extends zzbmd<GetTokenResult, zzbmz> {
        @NonNull
        private final String zzbXZ;

        public zzg(@NonNull String str) {
            super(1);
            this.zzbXZ = zzac.zzh(str, "refresh token cannot be null");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zza(this.zzbXZ, this.zzbYl);
        }

        public void zzVQ() {
            this.zzbYq.zziy(this.zzbXZ);
            ((zzbmz) this.zzbYo).zza(this.zzbYq, this.zzbYm);
            zzaf(new GetTokenResult(this.zzbYq.getAccessToken()));
        }
    }

    static final class zzh extends zzbmd<AuthResult, zzbmz> {
        @NonNull
        private final EmailAuthCredential zzbYa;

        public zzh(@NonNull EmailAuthCredential emailAuthCredential) {
            super(2);
            this.zzbYa = (EmailAuthCredential) zzac.zzb((Object) emailAuthCredential, (Object) "credential cannot be null");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zza(this.zzbYa.getEmail(), this.zzbYa.getPassword(), this.zzbYm.zzVJ(), this.zzbYl);
        }

        public void zzVQ() {
            FirebaseUser zzb = zzbls.zza(this.zzbXI, this.zzbYr);
            ((zzbmz) this.zzbYo).zza(this.zzbYq, zzb);
            zzaf(new zzbnc(zzb));
        }
    }

    static final class zzi extends zzbmd<AuthResult, zzbmz> {
        @NonNull
        private final zzbmx zzbYb;

        public zzi(@NonNull AuthCredential authCredential) {
            super(2);
            zzac.zzb((Object) authCredential, (Object) "credential cannot be null");
            this.zzbYb = zzbna.zza(authCredential);
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zza(this.zzbYm.zzVJ(), this.zzbYb, this.zzbYl);
        }

        public void zzVQ() {
            FirebaseUser zzb = zzbls.zza(this.zzbXI, this.zzbYr);
            ((zzbmz) this.zzbYo).zza(this.zzbYq, zzb);
            zzaf(new zzbnc(zzb));
        }
    }

    private static class zzj<ResultT, CallbackT> extends zzabv<zzblt, ResultT> implements zzbmc<ResultT> {
        private TaskCompletionSource<ResultT> zzazE;
        private zzbmd<ResultT, CallbackT> zzbYc;

        public zzj(zzbmd<ResultT, CallbackT> com_google_android_gms_internal_zzbmd_ResultT__CallbackT) {
            this.zzbYc = com_google_android_gms_internal_zzbmd_ResultT__CallbackT;
            this.zzbYc.zza((zzbmc) this);
        }

        protected void zza(zzblt com_google_android_gms_internal_zzblt, TaskCompletionSource<ResultT> taskCompletionSource) throws RemoteException {
            this.zzazE = taskCompletionSource;
            this.zzbYc.zza(com_google_android_gms_internal_zzblt.zzVR());
        }

        public final void zza(ResultT resultT, Status status) {
            zzac.zzb(this.zzazE, (Object) "doExecute must be called before onComplete");
            if (status != null) {
                this.zzazE.setException(zzblv.zzce(status));
            } else {
                this.zzazE.setResult(resultT);
            }
        }
    }

    static final class zzk extends zzbmd<Void, zzbmz> {
        @NonNull
        private final zzbmx zzbYb;

        public zzk(@NonNull AuthCredential authCredential) {
            super(2);
            zzac.zzb((Object) authCredential, (Object) "credential cannot be null");
            this.zzbYb = zzbna.zza(authCredential);
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zza(this.zzbYb, this.zzbYl);
        }

        public void zzVQ() {
            FirebaseUser zzb = zzbls.zza(this.zzbXI, this.zzbYr);
            if (this.zzbYm.getUid().equalsIgnoreCase(zzb.getUid())) {
                ((zzbmz) this.zzbYo).zza(this.zzbYq, zzb);
                zzVW();
                return;
            }
            zzcf(zzbnh.zzWt());
        }
    }

    static final class zzl extends zzbmd<Void, zzbmz> {
        @NonNull
        private final String zzajh;
        @NonNull
        private final String zzaka;

        public zzl(@NonNull String str, @NonNull String str2) {
            super(2);
            this.zzaka = zzac.zzh(str, "email cannot be null or empty");
            this.zzajh = zzac.zzh(str2, "password cannot be null or empty");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zzd(this.zzaka, this.zzajh, this.zzbYl);
        }

        public void zzVQ() {
            FirebaseUser zzb = zzbls.zza(this.zzbXI, this.zzbYr);
            if (this.zzbYm.getUid().equalsIgnoreCase(zzb.getUid())) {
                ((zzbmz) this.zzbYo).zza(this.zzbYq, zzb);
                zzVW();
                return;
            }
            zzcf(zzbnh.zzWt());
        }
    }

    static final class zzm extends zzbmd<Void, zzbmz> {
        public zzm() {
            super(2);
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zzf(this.zzbYm.zzVJ(), this.zzbYl);
        }

        public void zzVQ() {
            ((zzbmz) this.zzbYo).zza(this.zzbYq, zzbls.zza(this.zzbXI, this.zzbYr, this.zzbYm.isAnonymous()));
            zzaf(null);
        }
    }

    static final class zzn extends zzbmd<Void, zzbmz> {
        @NonNull
        private String zzaiJ;

        public zzn(@NonNull String str) {
            super(6);
            this.zzaiJ = zzac.zzh(str, "token cannot be null or empty");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zzh(this.zzaiJ, this.zzbYl);
        }

        public void zzVQ() {
            zzVW();
        }
    }

    static final class zzo extends zzbmd<Void, zzbmz> {
        @NonNull
        private String zzaka;

        public zzo(@NonNull String str) {
            super(4);
            this.zzaka = zzac.zzh(str, "email cannot be null or empty");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zzd(this.zzaka, this.zzbYl);
        }

        public void zzVQ() {
            zzVW();
        }
    }

    static final class zzp extends zzbmd<AuthResult, zzbmz> {
        public zzp() {
            super(2);
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zza(this.zzbYl);
        }

        public void zzVQ() {
            FirebaseUser zzb = zzbls.zza(this.zzbXI, this.zzbYr, true);
            ((zzbmz) this.zzbYo).zza(this.zzbYq, zzb);
            zzaf(new zzbnc(zzb));
        }
    }

    static final class zzq extends zzbmd<AuthResult, zzbmz> {
        @NonNull
        private final zzbmx zzbYb;

        public zzq(@NonNull AuthCredential authCredential) {
            super(2);
            zzac.zzb((Object) authCredential, (Object) "credential cannot be null");
            this.zzbYb = zzbna.zza(authCredential);
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zza(this.zzbYb, this.zzbYl);
        }

        public void zzVQ() {
            FirebaseUser zzb = zzbls.zza(this.zzbXI, this.zzbYr);
            ((zzbmz) this.zzbYo).zza(this.zzbYq, zzb);
            zzaf(new zzbnc(zzb));
        }
    }

    static final class zzr extends zzbmd<AuthResult, zzbmz> {
        @NonNull
        private final String zzaiJ;

        public zzr(@NonNull String str) {
            super(2);
            this.zzaiJ = zzac.zzh(str, "token cannot be null or empty");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zzb(this.zzaiJ, this.zzbYl);
        }

        public void zzVQ() {
            FirebaseUser zzb = zzbls.zza(this.zzbXI, this.zzbYr);
            ((zzbmz) this.zzbYo).zza(this.zzbYq, zzb);
            zzaf(new zzbnc(zzb));
        }
    }

    static final class zzs extends zzbmd<AuthResult, zzbmz> {
        @NonNull
        private String zzajh;
        @NonNull
        private String zzaka;

        public zzs(String str, String str2) {
            super(2);
            this.zzaka = zzac.zzh(str, "email cannot be null or empty");
            this.zzajh = zzac.zzh(str2, "password cannot be null or empty");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zzd(this.zzaka, this.zzajh, this.zzbYl);
        }

        public void zzVQ() {
            FirebaseUser zzb = zzbls.zza(this.zzbXI, this.zzbYr);
            ((zzbmz) this.zzbYo).zza(this.zzbYq, zzb);
            zzaf(new zzbnc(zzb));
        }
    }

    static final class zzt extends zzbmd<AuthResult, zzbmz> {
        public zzt() {
            super(2);
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zze(this.zzbYm.zzVJ(), this.zzbYl);
        }

        public void zzVQ() {
            FirebaseUser zzb = zzbls.zza(this.zzbXI, this.zzbYr);
            ((zzbmz) this.zzbYo).zza(this.zzbYq, zzb);
            zzaf(new zzbnc(zzb));
        }
    }

    static final class zzu extends zzbmd<AuthResult, zzbmz> {
        @NonNull
        private String zzbYd;

        public zzu(@NonNull String str) {
            super(2);
            this.zzbYd = zzac.zzh(str, "provider cannot be null or empty");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zze(this.zzbYd, this.zzbYm.zzVJ(), this.zzbYl);
        }

        public void zzVQ() {
            FirebaseUser zzb = zzbls.zza(this.zzbXI, this.zzbYr);
            ((zzbmz) this.zzbYo).zza(this.zzbYq, zzb);
            zzaf(new zzbnc(zzb));
        }
    }

    static final class zzv extends zzbmd<Void, zzbmz> {
        @NonNull
        private final String zzaka;

        public zzv(String str) {
            super(2);
            this.zzaka = zzac.zzh(str, "email cannot be null or empty");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zza(this.zzbYm.zzVJ(), this.zzaka, this.zzbYl);
        }

        public void zzVQ() {
            ((zzbmz) this.zzbYo).zza(this.zzbYq, zzbls.zza(this.zzbXI, this.zzbYr));
            zzVW();
        }
    }

    static final class zzw extends zzbmd<Void, zzbmz> {
        @NonNull
        private final String zzajh;

        public zzw(@NonNull String str) {
            super(2);
            this.zzajh = zzac.zzh(str, "password cannot be null or empty");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zzb(this.zzbYm.zzVJ(), this.zzajh, this.zzbYl);
        }

        public void zzVQ() {
            ((zzbmz) this.zzbYo).zza(this.zzbYq, zzbls.zza(this.zzbXI, this.zzbYr));
            zzVW();
        }
    }

    static final class zzx extends zzbmd<Void, zzbmz> {
        @NonNull
        private final UserProfileChangeRequest zzbYe;

        public zzx(UserProfileChangeRequest userProfileChangeRequest) {
            super(2);
            this.zzbYe = (UserProfileChangeRequest) zzac.zzb((Object) userProfileChangeRequest, (Object) "request cannot be null");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zza(this.zzbYm.zzVJ(), this.zzbYe, this.zzbYl);
        }

        public void zzVQ() {
            ((zzbmz) this.zzbYo).zza(this.zzbYq, zzbls.zza(this.zzbXI, this.zzbYr));
            zzVW();
        }
    }

    static final class zzy extends zzbmd<String, zzbmz> {
        @NonNull
        private final String zzaZU;

        public zzy(@NonNull String str) {
            super(4);
            this.zzaZU = zzac.zzh(str, "code cannot be null or empty");
        }

        public void dispatch() throws RemoteException {
            this.zzbYn.zzi(this.zzaZU, this.zzbYl);
        }

        public void zzVQ() {
            if (new zzbnb(this.zzbYt).getOperation() != 0) {
                zzcf(new Status(17499));
            } else {
                zzaf(this.zzbYt.getEmail());
            }
        }
    }

    zzbls(@NonNull Context context, @NonNull com.google.android.gms.internal.zzbma.zza com_google_android_gms_internal_zzbma_zza) {
        super(context, zzbma.zzbYj, (ApiOptions) com_google_android_gms_internal_zzbma_zza, new com.google.firebase.zza());
    }

    private <ResultT, CallbackT> zzj<ResultT, CallbackT> zza(zzbmd<ResultT, CallbackT> com_google_android_gms_internal_zzbmd_ResultT__CallbackT) {
        return new zzj(com_google_android_gms_internal_zzbmd_ResultT__CallbackT);
    }

    @NonNull
    private static zzbnf zza(@NonNull FirebaseApp firebaseApp, @NonNull zzbmj com_google_android_gms_internal_zzbmj) {
        return zza(firebaseApp, com_google_android_gms_internal_zzbmj, false);
    }

    @NonNull
    private static zzbnf zza(@NonNull FirebaseApp firebaseApp, @NonNull zzbmj com_google_android_gms_internal_zzbmj, boolean z) {
        zzac.zzw(firebaseApp);
        zzac.zzw(com_google_android_gms_internal_zzbmj);
        List arrayList = new ArrayList();
        arrayList.add(new zzbnd(com_google_android_gms_internal_zzbmj, FirebaseAuthProvider.PROVIDER_ID));
        List zzWb = com_google_android_gms_internal_zzbmj.zzWb();
        if (!(zzWb == null || zzWb.isEmpty())) {
            for (int i = 0; i < zzWb.size(); i++) {
                arrayList.add(new zzbnd((zzbmp) zzWb.get(i)));
            }
        }
        zzbnf com_google_android_gms_internal_zzbnf = new zzbnf(firebaseApp, arrayList);
        com_google_android_gms_internal_zzbnf.zzaX(z);
        return com_google_android_gms_internal_zzbnf;
    }

    @NonNull
    private Task<AuthResult> zza(@NonNull FirebaseApp firebaseApp, @NonNull AuthCredential authCredential, @NonNull FirebaseUser firebaseUser, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        zzac.zzw(firebaseApp);
        zzac.zzw(authCredential);
        zzac.zzw(firebaseUser);
        zzac.zzw(com_google_android_gms_internal_zzbmz);
        List providers = firebaseUser.getProviders();
        return (providers == null || !providers.contains(authCredential.getProvider())) ? doWrite(zza(new zzi(authCredential).zze(firebaseApp).zze(firebaseUser).zzae(com_google_android_gms_internal_zzbmz))) : Tasks.forException(zzblv.zzce(new Status(17015)));
    }

    @NonNull
    private Task<AuthResult> zza(@NonNull FirebaseApp firebaseApp, @NonNull EmailAuthCredential emailAuthCredential, @NonNull FirebaseUser firebaseUser, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        return doWrite(zza(new zzh(emailAuthCredential).zze(firebaseApp).zze(firebaseUser).zzae(com_google_android_gms_internal_zzbmz)));
    }

    @NonNull
    private Task<AuthResult> zza(@NonNull FirebaseApp firebaseApp, @NonNull FirebaseUser firebaseUser, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        return doWrite(zza(new zzt().zze(firebaseApp).zze(firebaseUser).zzae(com_google_android_gms_internal_zzbmz)));
    }

    @NonNull
    private Task<AuthResult> zza(@NonNull FirebaseApp firebaseApp, @NonNull String str, @NonNull FirebaseUser firebaseUser, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        return doWrite(zza(new zzu(str).zze(firebaseApp).zze(firebaseUser).zzae(com_google_android_gms_internal_zzbmz)));
    }

    public Task<AuthResult> zza(@NonNull FirebaseApp firebaseApp, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        return doWrite(zza(new zzp().zze(firebaseApp).zzae(com_google_android_gms_internal_zzbmz)));
    }

    public Task<AuthResult> zza(@NonNull FirebaseApp firebaseApp, @NonNull AuthCredential authCredential, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        return doWrite(zza(new zzq(authCredential).zze(firebaseApp).zzae(com_google_android_gms_internal_zzbmz)));
    }

    public Task<Void> zza(@NonNull FirebaseApp firebaseApp, @NonNull FirebaseUser firebaseUser, @NonNull AuthCredential authCredential, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        return doWrite(zza(new zzk(authCredential).zze(firebaseApp).zze(firebaseUser).zzae(com_google_android_gms_internal_zzbmz)));
    }

    public Task<Void> zza(@NonNull FirebaseApp firebaseApp, @NonNull FirebaseUser firebaseUser, @NonNull UserProfileChangeRequest userProfileChangeRequest, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        return doWrite(zza(new zzx(userProfileChangeRequest).zze(firebaseApp).zze(firebaseUser).zzae(com_google_android_gms_internal_zzbmz)));
    }

    public Task<GetTokenResult> zza(@NonNull FirebaseApp firebaseApp, @NonNull FirebaseUser firebaseUser, @NonNull String str, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        return doRead(zza(new zzg(str).zze(firebaseApp).zze(firebaseUser).zzae(com_google_android_gms_internal_zzbmz)));
    }

    public Task<Void> zza(@NonNull FirebaseApp firebaseApp, @NonNull FirebaseUser firebaseUser, @NonNull String str, @NonNull String str2, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        return doWrite(zza(new zzl(str, str2).zze(firebaseApp).zze(firebaseUser).zzae(com_google_android_gms_internal_zzbmz)));
    }

    public Task<ProviderQueryResult> zza(@NonNull FirebaseApp firebaseApp, @NonNull String str) {
        return doRead(zza(new zzf(str).zze(firebaseApp)));
    }

    public Task<AuthResult> zza(@NonNull FirebaseApp firebaseApp, @NonNull String str, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        return doWrite(zza(new zzr(str).zze(firebaseApp).zzae(com_google_android_gms_internal_zzbmz)));
    }

    public Task<Void> zza(@NonNull FirebaseApp firebaseApp, @NonNull String str, @NonNull String str2) {
        return doWrite(zza(new zzc(str, str2).zze(firebaseApp)));
    }

    public Task<AuthResult> zza(@NonNull FirebaseApp firebaseApp, @NonNull String str, @NonNull String str2, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        return doWrite(zza(new zzd(str, str2).zze(firebaseApp).zzae(com_google_android_gms_internal_zzbmz)));
    }

    @NonNull
    public Task<Void> zza(@NonNull FirebaseUser firebaseUser, @NonNull zzbni com_google_android_gms_internal_zzbni) {
        return doWrite(zza(new zze().zze(firebaseUser).zzae(com_google_android_gms_internal_zzbni)));
    }

    @NonNull
    public Task<Void> zzb(@NonNull FirebaseApp firebaseApp, @NonNull FirebaseUser firebaseUser, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        return doRead(zza(new zzm().zze(firebaseApp).zze(firebaseUser).zzae(com_google_android_gms_internal_zzbmz)));
    }

    public Task<AuthResult> zzb(@NonNull FirebaseApp firebaseApp, @NonNull FirebaseUser firebaseUser, @NonNull AuthCredential authCredential, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        zzac.zzw(firebaseApp);
        zzac.zzw(authCredential);
        zzac.zzw(firebaseUser);
        zzac.zzw(com_google_android_gms_internal_zzbmz);
        return EmailAuthCredential.class.isAssignableFrom(authCredential.getClass()) ? zza(firebaseApp, (EmailAuthCredential) authCredential, firebaseUser, com_google_android_gms_internal_zzbmz) : zza(firebaseApp, authCredential, firebaseUser, com_google_android_gms_internal_zzbmz);
    }

    public Task<Void> zzb(@NonNull FirebaseApp firebaseApp, @NonNull FirebaseUser firebaseUser, @NonNull String str, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        return doWrite(zza(new zzv(str).zze(firebaseApp).zze(firebaseUser).zzae(com_google_android_gms_internal_zzbmz)));
    }

    public Task<Void> zzb(@NonNull FirebaseApp firebaseApp, @NonNull String str) {
        return doWrite(zza(new zzo(str).zze(firebaseApp)));
    }

    public Task<AuthResult> zzb(@NonNull FirebaseApp firebaseApp, @NonNull String str, @NonNull String str2, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        return doWrite(zza(new zzs(str, str2).zze(firebaseApp).zzae(com_google_android_gms_internal_zzbmz)));
    }

    public Task<Void> zzc(@NonNull FirebaseApp firebaseApp, @NonNull FirebaseUser firebaseUser, @NonNull String str, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        return doWrite(zza(new zzw(str).zze(firebaseApp).zze(firebaseUser).zzae(com_google_android_gms_internal_zzbmz)));
    }

    public Task<Void> zzc(@NonNull FirebaseApp firebaseApp, @NonNull String str) {
        return doWrite(zza(new zzn(str).zze(firebaseApp)));
    }

    public Task<AuthResult> zzd(@NonNull FirebaseApp firebaseApp, @NonNull FirebaseUser firebaseUser, @NonNull String str, @NonNull zzbmz com_google_android_gms_internal_zzbmz) {
        zzac.zzw(firebaseApp);
        zzac.zzdr(str);
        zzac.zzw(firebaseUser);
        zzac.zzw(com_google_android_gms_internal_zzbmz);
        List providers = firebaseUser.getProviders();
        if ((providers != null && !providers.contains(str)) || firebaseUser.isAnonymous()) {
            return Tasks.forException(zzblv.zzce(new Status(17016, str)));
        }
        Object obj = -1;
        switch (str.hashCode()) {
            case 1216985755:
                if (str.equals(EmailAuthProvider.PROVIDER_ID)) {
                    obj = null;
                    break;
                }
                break;
        }
        switch (obj) {
            case null:
                return zza(firebaseApp, firebaseUser, com_google_android_gms_internal_zzbmz);
            default:
                return zza(firebaseApp, str, firebaseUser, com_google_android_gms_internal_zzbmz);
        }
    }

    public Task<ActionCodeResult> zzd(@NonNull FirebaseApp firebaseApp, @NonNull String str) {
        return doWrite(zza(new zzb(str).zze(firebaseApp)));
    }

    public Task<Void> zze(@NonNull FirebaseApp firebaseApp, @NonNull String str) {
        return doWrite(zza(new zza(str).zze(firebaseApp)));
    }

    public Task<String> zzf(@NonNull FirebaseApp firebaseApp, @NonNull String str) {
        return doWrite(zza(new zzy(str).zze(firebaseApp)));
    }
}
