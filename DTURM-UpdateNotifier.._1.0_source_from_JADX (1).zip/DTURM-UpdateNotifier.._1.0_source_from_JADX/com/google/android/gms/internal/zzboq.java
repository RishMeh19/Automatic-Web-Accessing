package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class zzboq implements com.google.android.gms.internal.zzboj.zza, zzbop {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzboq.class.desiredAssertionStatus());
    private static long zzcbt = 0;
    private final zzbrn zzcaH;
    private final ScheduledExecutorService zzcav;
    private final zzbok zzcbF;
    private final com.google.android.gms.internal.zzbop.zza zzcbK;
    private String zzcbL;
    private HashSet<String> zzcbM = new HashSet();
    private boolean zzcbN = true;
    private long zzcbO;
    private zzboj zzcbP;
    private zzb zzcbQ = zzb.Disconnected;
    private long zzcbR = 0;
    private long zzcbS = 0;
    private Map<Long, zza> zzcbT;
    private List<zzd> zzcbU;
    private Map<Long, zzf> zzcbV;
    private Map<zzc, zze> zzcbW;
    private String zzcbX;
    private boolean zzcbY;
    private final zzbol zzcbZ;
    private final zzbon zzcbu;
    private final zzbou zzcca;
    private String zzccb;
    private long zzccc = 0;
    private int zzccd = 0;
    private ScheduledFuture<?> zzcce = null;
    private long zzccf;
    private boolean zzccg;

    class C02817 implements Runnable {
        final /* synthetic */ zzboq zzcci;

        C02817(zzboq com_google_android_gms_internal_zzboq) {
            this.zzcci = com_google_android_gms_internal_zzboq;
        }

        public void run() {
            this.zzcci.zzcce = null;
            if (this.zzcci.zzXP()) {
                this.zzcci.interrupt("connection_idle");
            } else {
                this.zzcci.zzXO();
            }
        }
    }

    private interface zza {
        void zzaA(Map<String, Object> map);
    }

    private enum zzb {
        Disconnected,
        GettingToken,
        Connecting,
        Authenticating,
        Connected
    }

    private static class zzc {
        private final List<String> zzccw;
        private final Map<String, Object> zzccx;

        public zzc(List<String> list, Map<String, Object> map) {
            this.zzccw = list;
            this.zzccx = map;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof zzc)) {
                return false;
            }
            zzc com_google_android_gms_internal_zzboq_zzc = (zzc) obj;
            return this.zzccw.equals(com_google_android_gms_internal_zzboq_zzc.zzccw) ? this.zzccx.equals(com_google_android_gms_internal_zzboq_zzc.zzccx) : false;
        }

        public int hashCode() {
            return (this.zzccw.hashCode() * 31) + this.zzccx.hashCode();
        }

        public String toString() {
            String valueOf = String.valueOf(zzbom.zzW(this.zzccw));
            String valueOf2 = String.valueOf(this.zzccx);
            return new StringBuilder((String.valueOf(valueOf).length() + 11) + String.valueOf(valueOf2).length()).append(valueOf).append(" (params: ").append(valueOf2).append(")").toString();
        }
    }

    private static class zzd {
        private final Object data;
        private final List<String> zzccw;
        private final String zzccy;
        private final zzbos zzccz;

        private zzd(String str, List<String> list, Object obj, zzbos com_google_android_gms_internal_zzbos) {
            this.zzccy = str;
            this.zzccw = list;
            this.data = obj;
            this.zzccz = com_google_android_gms_internal_zzbos;
        }

        public String getAction() {
            return this.zzccy;
        }

        public Object getData() {
            return this.data;
        }

        public List<String> zzXQ() {
            return this.zzccw;
        }

        public zzbos zzXR() {
            return this.zzccz;
        }
    }

    private static class zze {
        private final zzbos zzccA;
        private final zzc zzccB;
        private final zzboo zzccC;
        private final Long zzccD;

        private zze(zzbos com_google_android_gms_internal_zzbos, zzc com_google_android_gms_internal_zzboq_zzc, Long l, zzboo com_google_android_gms_internal_zzboo) {
            this.zzccA = com_google_android_gms_internal_zzbos;
            this.zzccB = com_google_android_gms_internal_zzboq_zzc;
            this.zzccC = com_google_android_gms_internal_zzboo;
            this.zzccD = l;
        }

        public String toString() {
            String valueOf = String.valueOf(this.zzccB.toString());
            String valueOf2 = String.valueOf(this.zzccD);
            return new StringBuilder((String.valueOf(valueOf).length() + 8) + String.valueOf(valueOf2).length()).append(valueOf).append(" (Tag: ").append(valueOf2).append(")").toString();
        }

        public zzc zzXS() {
            return this.zzccB;
        }

        public Long zzXT() {
            return this.zzccD;
        }

        public zzboo zzXU() {
            return this.zzccC;
        }
    }

    private static class zzf {
        private Map<String, Object> zzccE;
        private boolean zzccF;
        private String zzccy;
        private zzbos zzccz;

        private zzf(String str, Map<String, Object> map, zzbos com_google_android_gms_internal_zzbos) {
            this.zzccy = str;
            this.zzccE = map;
            this.zzccz = com_google_android_gms_internal_zzbos;
        }

        public String getAction() {
            return this.zzccy;
        }

        public zzbos zzXR() {
            return this.zzccz;
        }

        public Map<String, Object> zzXV() {
            return this.zzccE;
        }

        public void zzXW() {
            this.zzccF = true;
        }

        public boolean zzXX() {
            return this.zzccF;
        }
    }

    class C04976 implements zza {
        final /* synthetic */ zzboq zzcci;

        C04976(zzboq com_google_android_gms_internal_zzboq) {
            this.zzcci = com_google_android_gms_internal_zzboq;
        }

        public void zzaA(Map<String, Object> map) {
            String str = (String) map.get("s");
            if (!str.equals("ok")) {
                String str2 = (String) map.get("d");
                if (this.zzcci.zzcaH.zzaaF()) {
                    this.zzcci.zzcaH.zzi(new StringBuilder((String.valueOf(str).length() + 34) + String.valueOf(str2).length()).append("Failed to send stats: ").append(str).append(" (message: ").append(str2).append(")").toString(), new Object[0]);
                }
            }
        }
    }

    public zzboq(zzbol com_google_android_gms_internal_zzbol, zzbon com_google_android_gms_internal_zzbon, com.google.android.gms.internal.zzbop.zza com_google_android_gms_internal_zzbop_zza) {
        this.zzcbK = com_google_android_gms_internal_zzbop_zza;
        this.zzcbZ = com_google_android_gms_internal_zzbol;
        this.zzcav = com_google_android_gms_internal_zzbol.zzXv();
        this.zzcbF = com_google_android_gms_internal_zzbol.zzXu();
        this.zzcbu = com_google_android_gms_internal_zzbon;
        this.zzcbW = new HashMap();
        this.zzcbT = new HashMap();
        this.zzcbV = new HashMap();
        this.zzcbU = new ArrayList();
        this.zzcca = new com.google.android.gms.internal.zzbou.zza(this.zzcav, com_google_android_gms_internal_zzbol.zzXt(), "ConnectionRetryHelper").zzaM(1000).zzj(1.3d).zzaN(30000).zzk(0.7d).zzYk();
        long j = zzcbt;
        zzcbt = 1 + j;
        this.zzcaH = new zzbrn(com_google_android_gms_internal_zzbol.zzXt(), "PersistentConnection", "pc_" + j);
        this.zzccb = null;
        zzXO();
    }

    private boolean isIdle() {
        return this.zzcbW.isEmpty() && this.zzcbT.isEmpty() && !this.zzccg && this.zzcbV.isEmpty();
    }

    private Collection<zze> zzX(List<String> list) {
        if (this.zzcaH.zzaaF()) {
            zzbrn com_google_android_gms_internal_zzbrn = this.zzcaH;
            String valueOf = String.valueOf(list);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder(String.valueOf(valueOf).length() + 29).append("removing all listens at path ").append(valueOf).toString(), new Object[0]);
        }
        Collection<zze> arrayList = new ArrayList();
        for (Entry entry : this.zzcbW.entrySet()) {
            zzc com_google_android_gms_internal_zzboq_zzc = (zzc) entry.getKey();
            zze com_google_android_gms_internal_zzboq_zze = (zze) entry.getValue();
            if (com_google_android_gms_internal_zzboq_zzc.zzccw.equals(list)) {
                arrayList.add(com_google_android_gms_internal_zzboq_zze);
            }
        }
        for (zze com_google_android_gms_internal_zzboq_zze2 : arrayList) {
            this.zzcbW.remove(com_google_android_gms_internal_zzboq_zze2.zzXS());
        }
        zzXO();
        return arrayList;
    }

    private boolean zzXC() {
        return this.zzcbQ == zzb.Authenticating || this.zzcbQ == zzb.Connected;
    }

    private boolean zzXD() {
        return this.zzcbQ == zzb.Connected;
    }

    private void zzXF() {
        if (zzXE()) {
            zzbom.zzc(this.zzcbQ == zzb.Disconnected, "Not in disconnected state: %s", this.zzcbQ);
            final boolean z = this.zzcbY;
            this.zzcaH.zzi("Scheduling connection attempt", new Object[0]);
            this.zzcbY = false;
            this.zzcca.zzr(new Runnable(this) {
                final /* synthetic */ zzboq zzcci;

                public void run() {
                    this.zzcci.zzcaH.zzi("Trying to fetch auth token", new Object[0]);
                    zzbom.zzc(this.zzcci.zzcbQ == zzb.Disconnected, "Not in disconnected state: %s", this.zzcci.zzcbQ);
                    this.zzcci.zzcbQ = zzb.GettingToken;
                    this.zzcci.zzccc = 1 + this.zzcci.zzccc;
                    final long zzd = this.zzcci.zzccc;
                    this.zzcci.zzcbF.zza(z, new com.google.android.gms.internal.zzbok.zza(this) {
                        final /* synthetic */ C02801 zzcck;

                        public void onError(String str) {
                            if (zzd == this.zzcck.zzcci.zzccc) {
                                this.zzcck.zzcci.zzcbQ = zzb.Disconnected;
                                zzbrn zza = this.zzcck.zzcci.zzcaH;
                                String str2 = "Error fetching token: ";
                                String valueOf = String.valueOf(str);
                                zza.zzi(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2), new Object[0]);
                                this.zzcck.zzcci.zzXF();
                                return;
                            }
                            this.zzcck.zzcci.zzcaH.zzi("Ignoring getToken error, because this was not the latest attempt.", new Object[0]);
                        }

                        public void zziL(String str) {
                            if (zzd != this.zzcck.zzcci.zzccc) {
                                this.zzcck.zzcci.zzcaH.zzi("Ignoring getToken result, because this was not the latest attempt.", new Object[0]);
                            } else if (this.zzcck.zzcci.zzcbQ == zzb.GettingToken) {
                                this.zzcck.zzcci.zzcaH.zzi("Successfully fetched token, opening connection", new Object[0]);
                                this.zzcck.zzcci.zziO(str);
                            } else {
                                zzbom.zzc(this.zzcck.zzcci.zzcbQ == zzb.Disconnected, "Expected connection state disconnected, but was %s", this.zzcck.zzcci.zzcbQ);
                                this.zzcck.zzcci.zzcaH.zzi("Not opening connection after token refresh, because connection was set to disconnected", new Object[0]);
                            }
                        }
                    });
                }
            });
        }
    }

    private void zzXG() {
        Iterator it = this.zzcbV.entrySet().iterator();
        while (it.hasNext()) {
            zzf com_google_android_gms_internal_zzboq_zzf = (zzf) ((Entry) it.next()).getValue();
            if (com_google_android_gms_internal_zzboq_zzf.zzXV().containsKey("h") && com_google_android_gms_internal_zzboq_zzf.zzXX()) {
                com_google_android_gms_internal_zzboq_zzf.zzXR().zzar("disconnected", null);
                it.remove();
            }
        }
    }

    private void zzXH() {
        zzbc(false);
    }

    private void zzXI() {
        zzbc(true);
    }

    private void zzXJ() {
        zzbom.zzc(zzXC(), "Must be connected to send unauth.", new Object[0]);
        zzbom.zzc(this.zzcbX == null, "Auth token must not be set.", new Object[0]);
        zza("unauth", Collections.emptyMap(), null);
    }

    private void zzXK() {
        if (this.zzcaH.zzaaF()) {
            this.zzcaH.zzi("calling restore state", new Object[0]);
        }
        zzbom.zzc(this.zzcbQ == zzb.Connecting, "Wanted to restore auth, but was in wrong state: %s", this.zzcbQ);
        if (this.zzcbX == null) {
            if (this.zzcaH.zzaaF()) {
                this.zzcaH.zzi("Not restoring auth because token is null.", new Object[0]);
            }
            this.zzcbQ = zzb.Connected;
            zzXL();
            return;
        }
        if (this.zzcaH.zzaaF()) {
            this.zzcaH.zzi("Restoring auth.", new Object[0]);
        }
        this.zzcbQ = zzb.Authenticating;
        zzXI();
    }

    private void zzXL() {
        zzbom.zzc(this.zzcbQ == zzb.Connected, "Should be connected if we're restoring state, but we are: %s", this.zzcbQ);
        if (this.zzcaH.zzaaF()) {
            this.zzcaH.zzi("Restoring outstanding listens", new Object[0]);
        }
        for (zze com_google_android_gms_internal_zzboq_zze : this.zzcbW.values()) {
            if (this.zzcaH.zzaaF()) {
                zzbrn com_google_android_gms_internal_zzbrn = this.zzcaH;
                String valueOf = String.valueOf(com_google_android_gms_internal_zzboq_zze.zzXS());
                com_google_android_gms_internal_zzbrn.zzi(new StringBuilder(String.valueOf(valueOf).length() + 17).append("Restoring listen ").append(valueOf).toString(), new Object[0]);
            }
            zzb(com_google_android_gms_internal_zzboq_zze);
        }
        if (this.zzcaH.zzaaF()) {
            this.zzcaH.zzi("Restoring writes.", new Object[0]);
        }
        Object arrayList = new ArrayList(this.zzcbV.keySet());
        Collections.sort(arrayList);
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            zzaJ(((Long) it.next()).longValue());
        }
        for (zzd com_google_android_gms_internal_zzboq_zzd : this.zzcbU) {
            zza(com_google_android_gms_internal_zzboq_zzd.getAction(), com_google_android_gms_internal_zzboq_zzd.zzXQ(), com_google_android_gms_internal_zzboq_zzd.getData(), com_google_android_gms_internal_zzboq_zzd.zzXR());
        }
        this.zzcbU.clear();
    }

    private void zzXM() {
        Map hashMap = new HashMap();
        String str;
        String valueOf;
        if (zzbst.zzabI()) {
            if (this.zzcbZ.zzXw()) {
                hashMap.put("persistence.android.enabled", Integer.valueOf(1));
            }
            str = "sdk.android.";
            valueOf = String.valueOf(this.zzcbZ.zzXx().replace('.', '-'));
            hashMap.put(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), Integer.valueOf(1));
        } else if ($assertionsDisabled || !this.zzcbZ.zzXw()) {
            str = "sdk.java.";
            valueOf = String.valueOf(this.zzcbZ.zzXx().replace('.', '-'));
            hashMap.put(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), Integer.valueOf(1));
        } else {
            throw new AssertionError("Stats for persistence on JVM missing (persistence not yet supported)");
        }
        if (this.zzcaH.zzaaF()) {
            this.zzcaH.zzi("Sending first connection stats", new Object[0]);
        }
        zzaz(hashMap);
    }

    private long zzXN() {
        long j = this.zzcbS;
        this.zzcbS = 1 + j;
        return j;
    }

    private void zzXO() {
        boolean z = false;
        if (isIdle()) {
            if (this.zzcce != null) {
                this.zzcce.cancel(false);
            }
            this.zzcce = this.zzcav.schedule(new C02817(this), 60000, TimeUnit.MILLISECONDS);
        } else if (isInterrupted("connection_idle")) {
            if (!isIdle()) {
                z = true;
            }
            zzbom.zzba(z);
            resume("connection_idle");
        }
    }

    private boolean zzXP() {
        return isIdle() && System.currentTimeMillis() > this.zzccf + 60000;
    }

    private void zzY(List<String> list) {
        for (zze zzd : zzX(list)) {
            zzd.zzccA.zzar("permission_denied", null);
        }
    }

    private zze zza(zzc com_google_android_gms_internal_zzboq_zzc) {
        if (this.zzcaH.zzaaF()) {
            zzbrn com_google_android_gms_internal_zzbrn = this.zzcaH;
            String valueOf = String.valueOf(com_google_android_gms_internal_zzboq_zzc);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder(String.valueOf(valueOf).length() + 15).append("removing query ").append(valueOf).toString(), new Object[0]);
        }
        if (this.zzcbW.containsKey(com_google_android_gms_internal_zzboq_zzc)) {
            zze com_google_android_gms_internal_zzboq_zze = (zze) this.zzcbW.get(com_google_android_gms_internal_zzboq_zzc);
            this.zzcbW.remove(com_google_android_gms_internal_zzboq_zzc);
            zzXO();
            return com_google_android_gms_internal_zzboq_zze;
        }
        if (this.zzcaH.zzaaF()) {
            com_google_android_gms_internal_zzbrn = this.zzcaH;
            valueOf = String.valueOf(com_google_android_gms_internal_zzboq_zzc);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder(String.valueOf(valueOf).length() + 64).append("Trying to remove listener for QuerySpec ").append(valueOf).append(" but no listener exists.").toString(), new Object[0]);
        }
        return null;
    }

    private Map<String, Object> zza(List<String> list, Object obj, String str) {
        Map<String, Object> hashMap = new HashMap();
        hashMap.put("p", zzbom.zzW(list));
        hashMap.put("d", obj);
        if (str != null) {
            hashMap.put("h", str);
        }
        return hashMap;
    }

    private void zza(zze com_google_android_gms_internal_zzboq_zze) {
        Map hashMap = new HashMap();
        hashMap.put("p", zzbom.zzW(com_google_android_gms_internal_zzboq_zze.zzccB.zzccw));
        Long zzXT = com_google_android_gms_internal_zzboq_zze.zzXT();
        if (zzXT != null) {
            hashMap.put("q", com_google_android_gms_internal_zzboq_zze.zzXS().zzccx);
            hashMap.put("t", zzXT);
        }
        zza("n", hashMap, null);
    }

    private void zza(String str, List<String> list, Object obj, final zzbos com_google_android_gms_internal_zzbos) {
        Map hashMap = new HashMap();
        hashMap.put("p", zzbom.zzW(list));
        hashMap.put("d", obj);
        zza(str, hashMap, new zza(this) {
            public void zzaA(Map<String, Object> map) {
                String str = null;
                String str2 = (String) map.get("s");
                if (str2.equals("ok")) {
                    str2 = null;
                } else {
                    str = (String) map.get("d");
                }
                if (com_google_android_gms_internal_zzbos != null) {
                    com_google_android_gms_internal_zzbos.zzar(str2, str);
                }
            }
        });
    }

    private void zza(String str, List<String> list, Object obj, String str2, zzbos com_google_android_gms_internal_zzbos) {
        Map zza = zza((List) list, obj, str2);
        long j = this.zzcbR;
        this.zzcbR = 1 + j;
        this.zzcbV.put(Long.valueOf(j), new zzf(str, zza, com_google_android_gms_internal_zzbos));
        if (zzXD()) {
            zzaJ(j);
        }
        this.zzccf = System.currentTimeMillis();
        zzXO();
    }

    private void zza(String str, Map<String, Object> map, zza com_google_android_gms_internal_zzboq_zza) {
        zza(str, false, (Map) map, com_google_android_gms_internal_zzboq_zza);
    }

    private void zza(String str, boolean z, Map<String, Object> map, zza com_google_android_gms_internal_zzboq_zza) {
        long zzXN = zzXN();
        Map hashMap = new HashMap();
        hashMap.put("r", Long.valueOf(zzXN));
        hashMap.put("a", str);
        hashMap.put("b", map);
        this.zzcbP.zza(hashMap, z);
        this.zzcbT.put(Long.valueOf(zzXN), com_google_android_gms_internal_zzboq_zza);
    }

    private void zza(List<String> list, zzc com_google_android_gms_internal_zzboq_zzc) {
        if (list.contains("no_index")) {
            String valueOf = String.valueOf(com_google_android_gms_internal_zzboq_zzc.zzccx.get("i"));
            valueOf = new StringBuilder(String.valueOf(valueOf).length() + 14).append("\".indexOn\": \"").append(valueOf).append("\"").toString();
            zzbrn com_google_android_gms_internal_zzbrn = this.zzcaH;
            String valueOf2 = String.valueOf(zzbom.zzW(com_google_android_gms_internal_zzboq_zzc.zzccw));
            com_google_android_gms_internal_zzbrn.warn(new StringBuilder((String.valueOf(valueOf).length() + 118) + String.valueOf(valueOf2).length()).append("Using an unspecified index. Consider adding '").append(valueOf).append("' at ").append(valueOf2).append(" to your security and Firebase Database rules for better performance").toString());
        }
    }

    private void zzaI(long j) {
        if (this.zzcaH.zzaaF()) {
            this.zzcaH.zzi("handling timestamp", new Object[0]);
        }
        long currentTimeMillis = j - System.currentTimeMillis();
        Map hashMap = new HashMap();
        hashMap.put("serverTimeOffset", Long.valueOf(currentTimeMillis));
        this.zzcbK.zzax(hashMap);
    }

    private void zzaJ(long j) {
        if ($assertionsDisabled || zzXD()) {
            final zzf com_google_android_gms_internal_zzboq_zzf = (zzf) this.zzcbV.get(Long.valueOf(j));
            final zzbos zzXR = com_google_android_gms_internal_zzboq_zzf.zzXR();
            final String action = com_google_android_gms_internal_zzboq_zzf.getAction();
            com_google_android_gms_internal_zzboq_zzf.zzXW();
            final long j2 = j;
            zza(action, com_google_android_gms_internal_zzboq_zzf.zzXV(), new zza(this) {
                final /* synthetic */ zzboq zzcci;

                public void zzaA(Map<String, Object> map) {
                    if (this.zzcci.zzcaH.zzaaF()) {
                        zzbrn zza = this.zzcci.zzcaH;
                        String str = action;
                        String valueOf = String.valueOf(map);
                        zza.zzi(new StringBuilder((String.valueOf(str).length() + 11) + String.valueOf(valueOf).length()).append(str).append(" response: ").append(valueOf).toString(), new Object[0]);
                    }
                    if (((zzf) this.zzcci.zzcbV.get(Long.valueOf(j2))) == com_google_android_gms_internal_zzboq_zzf) {
                        this.zzcci.zzcbV.remove(Long.valueOf(j2));
                        if (zzXR != null) {
                            String str2 = (String) map.get("s");
                            if (str2.equals("ok")) {
                                zzXR.zzar(null, null);
                            } else {
                                zzXR.zzar(str2, (String) map.get("d"));
                            }
                        }
                    } else if (this.zzcci.zzcaH.zzaaF()) {
                        this.zzcci.zzcaH.zzi("Ignoring on complete for put " + j2 + " because it was removed already.", new Object[0]);
                    }
                    this.zzcci.zzXO();
                }
            });
            return;
        }
        throw new AssertionError("sendPut called when we can't send writes (we're disconnected or writes are paused).");
    }

    private void zzaq(String str, String str2) {
        this.zzcaH.zzi(new StringBuilder((String.valueOf(str).length() + 23) + String.valueOf(str2).length()).append("Auth token revoked: ").append(str).append(" (").append(str2).append(")").toString(), new Object[0]);
        this.zzcbX = null;
        this.zzcbY = true;
        this.zzcbK.zzbb(false);
        this.zzcbP.close();
    }

    private void zzay(Map<String, Object> map) {
        this.zzcaH.info((String) map.get("msg"));
    }

    private void zzaz(Map<String, Integer> map) {
        if (!map.isEmpty()) {
            Map hashMap = new HashMap();
            hashMap.put("c", map);
            zza("s", hashMap, new C04976(this));
        } else if (this.zzcaH.zzaaF()) {
            this.zzcaH.zzi("Not sending stats because stats are empty", new Object[0]);
        }
    }

    private void zzb(final zze com_google_android_gms_internal_zzboq_zze) {
        Map hashMap = new HashMap();
        hashMap.put("p", zzbom.zzW(com_google_android_gms_internal_zzboq_zze.zzXS().zzccw));
        Long zzXT = com_google_android_gms_internal_zzboq_zze.zzXT();
        if (zzXT != null) {
            hashMap.put("q", com_google_android_gms_internal_zzboq_zze.zzccB.zzccx);
            hashMap.put("t", zzXT);
        }
        zzboo zzXU = com_google_android_gms_internal_zzboq_zze.zzXU();
        hashMap.put("h", zzXU.zzXy());
        if (zzXU.zzXz()) {
            zzboi zzXA = zzXU.zzXA();
            List arrayList = new ArrayList();
            for (List zzW : zzXA.zzXr()) {
                arrayList.add(zzbom.zzW(zzW));
            }
            Map hashMap2 = new HashMap();
            hashMap2.put("hs", zzXA.zzXs());
            hashMap2.put("ps", arrayList);
            hashMap.put("ch", hashMap2);
        }
        zza("q", hashMap, new zza(this) {
            final /* synthetic */ zzboq zzcci;

            public void zzaA(Map<String, Object> map) {
                String str = (String) map.get("s");
                if (str.equals("ok")) {
                    Map map2 = (Map) map.get("d");
                    if (map2.containsKey("w")) {
                        this.zzcci.zza((List) map2.get("w"), com_google_android_gms_internal_zzboq_zze.zzccB);
                    }
                }
                if (((zze) this.zzcci.zzcbW.get(com_google_android_gms_internal_zzboq_zze.zzXS())) != com_google_android_gms_internal_zzboq_zze) {
                    return;
                }
                if (str.equals("ok")) {
                    com_google_android_gms_internal_zzboq_zze.zzccA.zzar(null, null);
                    return;
                }
                this.zzcci.zza(com_google_android_gms_internal_zzboq_zze.zzXS());
                com_google_android_gms_internal_zzboq_zze.zzccA.zzar(str, (String) map.get("d"));
            }
        });
    }

    private void zzbc(final boolean z) {
        zzbom.zzc(zzXC(), "Must be connected to send auth, but was: %s", this.zzcbQ);
        zzbom.zzc(this.zzcbX != null, "Auth token must be set to authenticate!", new Object[0]);
        zza c04943 = new zza(this) {
            final /* synthetic */ zzboq zzcci;

            public void zzaA(Map<String, Object> map) {
                this.zzcci.zzcbQ = zzb.Connected;
                String str = (String) map.get("s");
                if (str.equals("ok")) {
                    this.zzcci.zzccd = 0;
                    this.zzcci.zzcbK.zzbb(true);
                    if (z) {
                        this.zzcci.zzXL();
                        return;
                    }
                    return;
                }
                this.zzcci.zzcbX = null;
                this.zzcci.zzcbY = true;
                this.zzcci.zzcbK.zzbb(false);
                String str2 = (String) map.get("d");
                this.zzcci.zzcaH.zzi(new StringBuilder((String.valueOf(str).length() + 26) + String.valueOf(str2).length()).append("Authentication failed: ").append(str).append(" (").append(str2).append(")").toString(), new Object[0]);
                this.zzcci.zzcbP.close();
                if (str.equals("invalid_token")) {
                    this.zzcci.zzccd = this.zzcci.zzccd + 1;
                    if (((long) this.zzcci.zzccd) >= 3) {
                        this.zzcci.zzcca.zzYj();
                        this.zzcci.zzcaH.warn("Provided authentication credentials are invalid. This usually indicates your FirebaseApp instance was not initialized correctly. Make sure your google-services.json file has the correct firebase_url and api_key. You can re-download google-services.json from https://console.firebase.google.com/.");
                    }
                }
            }
        };
        Map hashMap = new HashMap();
        zzbsu zzjd = zzbsu.zzjd(this.zzcbX);
        if (zzjd != null) {
            hashMap.put("cred", zzjd.getToken());
            if (zzjd.zzabJ() != null) {
                hashMap.put("authvar", zzjd.zzabJ());
            }
            zza("gauth", true, hashMap, c04943);
            return;
        }
        hashMap.put("cred", this.zzcbX);
        zza("auth", true, hashMap, c04943);
    }

    private void zzk(String str, Map<String, Object> map) {
        if (this.zzcaH.zzaaF()) {
            zzbrn com_google_android_gms_internal_zzbrn = this.zzcaH;
            String valueOf = String.valueOf(map);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder((String.valueOf(str).length() + 22) + String.valueOf(valueOf).length()).append("handleServerMessage: ").append(str).append(" ").append(valueOf).toString(), new Object[0]);
        }
        String str2;
        zzbrn com_google_android_gms_internal_zzbrn2;
        String str3;
        if (str.equals("d") || str.equals("m")) {
            boolean equals = str.equals("m");
            str2 = (String) map.get("p");
            Object obj = map.get("d");
            Long zzar = zzbom.zzar(map.get("t"));
            if (!equals || !(obj instanceof Map) || ((Map) obj).size() != 0) {
                this.zzcbK.zza(zzbom.zziM(str2), obj, equals, zzar);
            } else if (this.zzcaH.zzaaF()) {
                com_google_android_gms_internal_zzbrn2 = this.zzcaH;
                str3 = "ignoring empty merge for path ";
                str2 = String.valueOf(str2);
                com_google_android_gms_internal_zzbrn2.zzi(str2.length() != 0 ? str3.concat(str2) : new String(str3), new Object[0]);
            }
        } else if (str.equals("rm")) {
            str2 = (String) map.get("p");
            List zziM = zzbom.zziM(str2);
            Object obj2 = map.get("d");
            Long zzar2 = zzbom.zzar(map.get("t"));
            List<Map> list = (List) obj2;
            List arrayList = new ArrayList();
            for (Map map2 : list) {
                str3 = (String) map2.get("s");
                String str4 = (String) map2.get("e");
                arrayList.add(new zzbor(str3 != null ? zzbom.zziM(str3) : null, str4 != null ? zzbom.zziM(str4) : null, map2.get("m")));
            }
            if (!arrayList.isEmpty()) {
                this.zzcbK.zza(zziM, arrayList, zzar2);
            } else if (this.zzcaH.zzaaF()) {
                com_google_android_gms_internal_zzbrn2 = this.zzcaH;
                str3 = "Ignoring empty range merge for path ";
                str2 = String.valueOf(str2);
                com_google_android_gms_internal_zzbrn2.zzi(str2.length() != 0 ? str3.concat(str2) : new String(str3), new Object[0]);
            }
        } else if (str.equals("c")) {
            zzY(zzbom.zziM((String) map.get("p")));
        } else if (str.equals("ac")) {
            zzaq((String) map.get("s"), (String) map.get("d"));
        } else if (str.equals("sd")) {
            zzay(map);
        } else if (this.zzcaH.zzaaF()) {
            com_google_android_gms_internal_zzbrn2 = this.zzcaH;
            str3 = "Unrecognized action from server: ";
            str2 = String.valueOf(str);
            com_google_android_gms_internal_zzbrn2.zzi(str2.length() != 0 ? str3.concat(str2) : new String(str3), new Object[0]);
        }
    }

    public void initialize() {
        zzXF();
    }

    public void interrupt(String str) {
        if (this.zzcaH.zzaaF()) {
            zzbrn com_google_android_gms_internal_zzbrn = this.zzcaH;
            String str2 = "Connection interrupted for: ";
            String valueOf = String.valueOf(str);
            com_google_android_gms_internal_zzbrn.zzi(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2), new Object[0]);
        }
        this.zzcbM.add(str);
        if (this.zzcbP != null) {
            this.zzcbP.close();
            this.zzcbP = null;
        } else {
            this.zzcca.cancel();
            this.zzcbQ = zzb.Disconnected;
        }
        this.zzcca.zzVW();
    }

    public boolean isInterrupted(String str) {
        return this.zzcbM.contains(str);
    }

    public void purgeOutstandingWrites() {
        for (zzf com_google_android_gms_internal_zzboq_zzf : this.zzcbV.values()) {
            if (com_google_android_gms_internal_zzboq_zzf.zzccz != null) {
                com_google_android_gms_internal_zzboq_zzf.zzccz.zzar("write_canceled", null);
            }
        }
        for (zzd com_google_android_gms_internal_zzboq_zzd : this.zzcbU) {
            if (com_google_android_gms_internal_zzboq_zzd.zzccz != null) {
                com_google_android_gms_internal_zzboq_zzd.zzccz.zzar("write_canceled", null);
            }
        }
        this.zzcbV.clear();
        this.zzcbU.clear();
        if (!zzXC()) {
            this.zzccg = false;
        }
        zzXO();
    }

    public void refreshAuthToken() {
        this.zzcaH.zzi("Auth token refresh requested", new Object[0]);
        interrupt("token_refresh");
        resume("token_refresh");
    }

    public void resume(String str) {
        if (this.zzcaH.zzaaF()) {
            zzbrn com_google_android_gms_internal_zzbrn = this.zzcaH;
            String str2 = "Connection no longer interrupted for: ";
            String valueOf = String.valueOf(str);
            com_google_android_gms_internal_zzbrn.zzi(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2), new Object[0]);
        }
        this.zzcbM.remove(str);
        if (zzXE() && this.zzcbQ == zzb.Disconnected) {
            zzXF();
        }
    }

    public void shutdown() {
        interrupt("shutdown");
    }

    boolean zzXE() {
        return this.zzcbM.size() == 0;
    }

    public void zza(List<String> list, zzbos com_google_android_gms_internal_zzbos) {
        if (zzXD()) {
            zza("oc", (List) list, null, com_google_android_gms_internal_zzbos);
        } else {
            this.zzcbU.add(new zzd("oc", list, null, com_google_android_gms_internal_zzbos));
        }
        zzXO();
    }

    public void zza(List<String> list, Object obj, zzbos com_google_android_gms_internal_zzbos) {
        zza("p", (List) list, obj, null, com_google_android_gms_internal_zzbos);
    }

    public void zza(List<String> list, Object obj, String str, zzbos com_google_android_gms_internal_zzbos) {
        zza("p", (List) list, obj, str, com_google_android_gms_internal_zzbos);
    }

    public void zza(List<String> list, Map<String, Object> map) {
        zzc com_google_android_gms_internal_zzboq_zzc = new zzc(list, map);
        if (this.zzcaH.zzaaF()) {
            zzbrn com_google_android_gms_internal_zzbrn = this.zzcaH;
            String valueOf = String.valueOf(com_google_android_gms_internal_zzboq_zzc);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder(String.valueOf(valueOf).length() + 15).append("unlistening on ").append(valueOf).toString(), new Object[0]);
        }
        zze zza = zza(com_google_android_gms_internal_zzboq_zzc);
        if (zza != null && zzXC()) {
            zza(zza);
        }
        zzXO();
    }

    public void zza(List<String> list, Map<String, Object> map, zzboo com_google_android_gms_internal_zzboo, Long l, zzbos com_google_android_gms_internal_zzbos) {
        zzc com_google_android_gms_internal_zzboq_zzc = new zzc(list, map);
        if (this.zzcaH.zzaaF()) {
            zzbrn com_google_android_gms_internal_zzbrn = this.zzcaH;
            String valueOf = String.valueOf(com_google_android_gms_internal_zzboq_zzc);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder(String.valueOf(valueOf).length() + 13).append("Listening on ").append(valueOf).toString(), new Object[0]);
        }
        zzbom.zzc(!this.zzcbW.containsKey(com_google_android_gms_internal_zzboq_zzc), "listen() called twice for same QuerySpec.", new Object[0]);
        if (this.zzcaH.zzaaF()) {
            com_google_android_gms_internal_zzbrn = this.zzcaH;
            valueOf = String.valueOf(com_google_android_gms_internal_zzboq_zzc);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder(String.valueOf(valueOf).length() + 21).append("Adding listen query: ").append(valueOf).toString(), new Object[0]);
        }
        zze com_google_android_gms_internal_zzboq_zze = new zze(com_google_android_gms_internal_zzbos, com_google_android_gms_internal_zzboq_zzc, l, com_google_android_gms_internal_zzboo);
        this.zzcbW.put(com_google_android_gms_internal_zzboq_zzc, com_google_android_gms_internal_zzboq_zze);
        if (zzXC()) {
            zzb(com_google_android_gms_internal_zzboq_zze);
        }
        zzXO();
    }

    public void zza(List<String> list, Map<String, Object> map, zzbos com_google_android_gms_internal_zzbos) {
        zza("m", (List) list, (Object) map, null, com_google_android_gms_internal_zzbos);
    }

    public void zzau(Map<String, Object> map) {
        if (map.containsKey("r")) {
            zza com_google_android_gms_internal_zzboq_zza = (zza) this.zzcbT.remove(Long.valueOf((long) ((Integer) map.get("r")).intValue()));
            if (com_google_android_gms_internal_zzboq_zza != null) {
                com_google_android_gms_internal_zzboq_zza.zzaA((Map) map.get("b"));
            }
        } else if (!map.containsKey("error")) {
            if (map.containsKey("a")) {
                zzk((String) map.get("a"), (Map) map.get("b"));
            } else if (this.zzcaH.zzaaF()) {
                zzbrn com_google_android_gms_internal_zzbrn = this.zzcaH;
                String valueOf = String.valueOf(map);
                com_google_android_gms_internal_zzbrn.zzi(new StringBuilder(String.valueOf(valueOf).length() + 26).append("Ignoring unknown message: ").append(valueOf).toString(), new Object[0]);
            }
        }
    }

    public void zzb(com.google.android.gms.internal.zzboj.zzb com_google_android_gms_internal_zzboj_zzb) {
        if (this.zzcaH.zzaaF()) {
            zzbrn com_google_android_gms_internal_zzbrn = this.zzcaH;
            String str = "Got on disconnect due to ";
            String valueOf = String.valueOf(com_google_android_gms_internal_zzboj_zzb.name());
            com_google_android_gms_internal_zzbrn.zzi(valueOf.length() != 0 ? str.concat(valueOf) : new String(str), new Object[0]);
        }
        this.zzcbQ = zzb.Disconnected;
        this.zzcbP = null;
        this.zzccg = false;
        this.zzcbT.clear();
        zzXG();
        if (zzXE()) {
            boolean z = this.zzcbO > 0 ? System.currentTimeMillis() - this.zzcbO > 30000 : false;
            if (com_google_android_gms_internal_zzboj_zzb == com.google.android.gms.internal.zzboj.zzb.SERVER_RESET || r0) {
                this.zzcca.zzVW();
            }
            zzXF();
        }
        this.zzcbO = 0;
        this.zzcbK.onDisconnect();
    }

    public void zzb(List<String> list, Object obj, zzbos com_google_android_gms_internal_zzbos) {
        this.zzccg = true;
        if (zzXD()) {
            zza("o", (List) list, obj, com_google_android_gms_internal_zzbos);
        } else {
            this.zzcbU.add(new zzd("o", list, obj, com_google_android_gms_internal_zzbos));
        }
        zzXO();
    }

    public void zzb(List<String> list, Map<String, Object> map, zzbos com_google_android_gms_internal_zzbos) {
        this.zzccg = true;
        if (zzXD()) {
            zza("om", (List) list, (Object) map, com_google_android_gms_internal_zzbos);
        } else {
            this.zzcbU.add(new zzd("om", list, map, com_google_android_gms_internal_zzbos));
        }
        zzXO();
    }

    public void zziJ(String str) {
        this.zzcbL = str;
    }

    public void zziK(String str) {
        if (this.zzcaH.zzaaF()) {
            zzbrn com_google_android_gms_internal_zzbrn = this.zzcaH;
            String str2 = "Firebase Database connection was forcefully killed by the server. Will not attempt reconnect. Reason: ";
            String valueOf = String.valueOf(str);
            com_google_android_gms_internal_zzbrn.zzi(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2), new Object[0]);
        }
        interrupt("server_kill");
    }

    public void zziN(String str) {
        this.zzcaH.zzi("Auth token refreshed.", new Object[0]);
        this.zzcbX = str;
        if (!zzXC()) {
            return;
        }
        if (str != null) {
            zzXH();
        } else {
            zzXJ();
        }
    }

    public void zziO(String str) {
        zzbom.zzc(this.zzcbQ == zzb.GettingToken, "Trying to open network connection while in the wrong state: %s", this.zzcbQ);
        if (str == null) {
            this.zzcbK.zzbb(false);
        }
        this.zzcbX = str;
        this.zzcbQ = zzb.Connecting;
        this.zzcbP = new zzboj(this.zzcbZ, this.zzcbu, this.zzcbL, this, this.zzccb);
        this.zzcbP.open();
    }

    public void zzj(long j, String str) {
        if (this.zzcaH.zzaaF()) {
            this.zzcaH.zzi("onReady", new Object[0]);
        }
        this.zzcbO = System.currentTimeMillis();
        zzaI(j);
        if (this.zzcbN) {
            zzXM();
        }
        zzXK();
        this.zzcbN = false;
        this.zzccb = str;
        this.zzcbK.zzXB();
    }
}
