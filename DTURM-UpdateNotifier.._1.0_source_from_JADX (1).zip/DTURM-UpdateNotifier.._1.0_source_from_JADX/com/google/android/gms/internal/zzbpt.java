package com.google.android.gms.internal;

import java.lang.Thread.UncaughtExceptionHandler;

public interface zzbpt {
    public static final zzbpt zzcgl = new C05161();

    class C05161 implements zzbpt {
        C05161() {
        }

        public void zza(Thread thread, String str) {
            thread.setName(str);
        }

        public void zza(Thread thread, UncaughtExceptionHandler uncaughtExceptionHandler) {
            thread.setUncaughtExceptionHandler(uncaughtExceptionHandler);
        }

        public void zza(Thread thread, boolean z) {
            thread.setDaemon(z);
        }
    }

    void zza(Thread thread, String str);

    void zza(Thread thread, UncaughtExceptionHandler uncaughtExceptionHandler);

    void zza(Thread thread, boolean z);
}
