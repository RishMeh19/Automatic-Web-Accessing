package com.google.android.gms.internal;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class zzbva {
    private final ThreadLocal<Map<zzbww<?>, zza<?>>> zzcqT;
    private final Map<zzbww<?>, zzbvs<?>> zzcqU;
    private final List<zzbvt> zzcqV;
    private final zzbwa zzcqW;
    private final boolean zzcqX;
    private final boolean zzcqY;
    private final boolean zzcqZ;
    private final boolean zzcra;
    final zzbve zzcrb;
    final zzbvn zzcrc;

    class C05361 implements zzbve {
        final /* synthetic */ zzbva zzcrd;

        C05361(zzbva com_google_android_gms_internal_zzbva) {
            this.zzcrd = com_google_android_gms_internal_zzbva;
        }
    }

    class C05372 implements zzbvn {
        final /* synthetic */ zzbva zzcrd;

        C05372(zzbva com_google_android_gms_internal_zzbva) {
            this.zzcrd = com_google_android_gms_internal_zzbva;
        }
    }

    class C05383 extends zzbvs<Number> {
        final /* synthetic */ zzbva zzcrd;

        C05383(zzbva com_google_android_gms_internal_zzbva) {
            this.zzcrd = com_google_android_gms_internal_zzbva;
        }

        public void zza(zzbwz com_google_android_gms_internal_zzbwz, Number number) throws IOException {
            if (number == null) {
                com_google_android_gms_internal_zzbwz.zzaex();
                return;
            }
            this.zzcrd.zzm(number.doubleValue());
            com_google_android_gms_internal_zzbwz.zza(number);
        }

        public /* synthetic */ Object zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
            return zze(com_google_android_gms_internal_zzbwx);
        }

        public Double zze(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
            if (com_google_android_gms_internal_zzbwx.zzaen() != zzbwy.NULL) {
                return Double.valueOf(com_google_android_gms_internal_zzbwx.nextDouble());
            }
            com_google_android_gms_internal_zzbwx.nextNull();
            return null;
        }
    }

    class C05394 extends zzbvs<Number> {
        final /* synthetic */ zzbva zzcrd;

        C05394(zzbva com_google_android_gms_internal_zzbva) {
            this.zzcrd = com_google_android_gms_internal_zzbva;
        }

        public void zza(zzbwz com_google_android_gms_internal_zzbwz, Number number) throws IOException {
            if (number == null) {
                com_google_android_gms_internal_zzbwz.zzaex();
                return;
            }
            this.zzcrd.zzm((double) number.floatValue());
            com_google_android_gms_internal_zzbwz.zza(number);
        }

        public /* synthetic */ Object zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
            return zzf(com_google_android_gms_internal_zzbwx);
        }

        public Float zzf(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
            if (com_google_android_gms_internal_zzbwx.zzaen() != zzbwy.NULL) {
                return Float.valueOf((float) com_google_android_gms_internal_zzbwx.nextDouble());
            }
            com_google_android_gms_internal_zzbwx.nextNull();
            return null;
        }
    }

    class C05405 extends zzbvs<Number> {
        final /* synthetic */ zzbva zzcrd;

        C05405(zzbva com_google_android_gms_internal_zzbva) {
            this.zzcrd = com_google_android_gms_internal_zzbva;
        }

        public void zza(zzbwz com_google_android_gms_internal_zzbwz, Number number) throws IOException {
            if (number == null) {
                com_google_android_gms_internal_zzbwz.zzaex();
            } else {
                com_google_android_gms_internal_zzbwz.zzkp(number.toString());
            }
        }

        public /* synthetic */ Object zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
            return zzg(com_google_android_gms_internal_zzbwx);
        }

        public Number zzg(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
            if (com_google_android_gms_internal_zzbwx.zzaen() != zzbwy.NULL) {
                return Long.valueOf(com_google_android_gms_internal_zzbwx.nextLong());
            }
            com_google_android_gms_internal_zzbwx.nextNull();
            return null;
        }
    }

    static class zza<T> extends zzbvs<T> {
        private zzbvs<T> zzcre;

        zza() {
        }

        public void zza(zzbvs<T> com_google_android_gms_internal_zzbvs_T) {
            if (this.zzcre != null) {
                throw new AssertionError();
            }
            this.zzcre = com_google_android_gms_internal_zzbvs_T;
        }

        public void zza(zzbwz com_google_android_gms_internal_zzbwz, T t) throws IOException {
            if (this.zzcre == null) {
                throw new IllegalStateException();
            }
            this.zzcre.zza(com_google_android_gms_internal_zzbwz, t);
        }

        public T zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
            if (this.zzcre != null) {
                return this.zzcre.zzb(com_google_android_gms_internal_zzbwx);
            }
            throw new IllegalStateException();
        }
    }

    public zzbva() {
        this(zzbwb.zzcrP, zzbuy.IDENTITY, Collections.emptyMap(), false, false, false, true, false, false, zzbvq.DEFAULT, Collections.emptyList());
    }

    zzbva(zzbwb com_google_android_gms_internal_zzbwb, zzbuz com_google_android_gms_internal_zzbuz, Map<Type, zzbvc<?>> map, boolean z, boolean z2, boolean z3, boolean z4, boolean z5, boolean z6, zzbvq com_google_android_gms_internal_zzbvq, List<zzbvt> list) {
        this.zzcqT = new ThreadLocal();
        this.zzcqU = Collections.synchronizedMap(new HashMap());
        this.zzcrb = new C05361(this);
        this.zzcrc = new C05372(this);
        this.zzcqW = new zzbwa(map);
        this.zzcqX = z;
        this.zzcqZ = z3;
        this.zzcqY = z4;
        this.zzcra = z5;
        List arrayList = new ArrayList();
        arrayList.add(zzbwv.zzctS);
        arrayList.add(zzbwq.zzcsz);
        arrayList.add(com_google_android_gms_internal_zzbwb);
        arrayList.addAll(list);
        arrayList.add(zzbwv.zzctz);
        arrayList.add(zzbwv.zzcto);
        arrayList.add(zzbwv.zzcti);
        arrayList.add(zzbwv.zzctk);
        arrayList.add(zzbwv.zzctm);
        arrayList.add(zzbwv.zza(Long.TYPE, Long.class, zza(com_google_android_gms_internal_zzbvq)));
        arrayList.add(zzbwv.zza(Double.TYPE, Double.class, zzbk(z6)));
        arrayList.add(zzbwv.zza(Float.TYPE, Float.class, zzbl(z6)));
        arrayList.add(zzbwv.zzctt);
        arrayList.add(zzbwv.zzctv);
        arrayList.add(zzbwv.zzctB);
        arrayList.add(zzbwv.zzctD);
        arrayList.add(zzbwv.zza(BigDecimal.class, zzbwv.zzctx));
        arrayList.add(zzbwv.zza(BigInteger.class, zzbwv.zzcty));
        arrayList.add(zzbwv.zzctF);
        arrayList.add(zzbwv.zzctH);
        arrayList.add(zzbwv.zzctL);
        arrayList.add(zzbwv.zzctQ);
        arrayList.add(zzbwv.zzctJ);
        arrayList.add(zzbwv.zzctf);
        arrayList.add(zzbwl.zzcsz);
        arrayList.add(zzbwv.zzctO);
        arrayList.add(zzbwt.zzcsz);
        arrayList.add(zzbws.zzcsz);
        arrayList.add(zzbwv.zzctM);
        arrayList.add(zzbwj.zzcsz);
        arrayList.add(zzbwv.zzctd);
        arrayList.add(new zzbwk(this.zzcqW));
        arrayList.add(new zzbwp(this.zzcqW, z2));
        arrayList.add(new zzbwm(this.zzcqW));
        arrayList.add(zzbwv.zzctT);
        arrayList.add(new zzbwr(this.zzcqW, com_google_android_gms_internal_zzbuz, com_google_android_gms_internal_zzbwb));
        this.zzcqV = Collections.unmodifiableList(arrayList);
    }

    private zzbvs<Number> zza(zzbvq com_google_android_gms_internal_zzbvq) {
        return com_google_android_gms_internal_zzbvq == zzbvq.DEFAULT ? zzbwv.zzctp : new C05405(this);
    }

    private static void zza(Object obj, zzbwx com_google_android_gms_internal_zzbwx) {
        if (obj != null) {
            try {
                if (com_google_android_gms_internal_zzbwx.zzaen() != zzbwy.END_DOCUMENT) {
                    throw new zzbvh("JSON document was not fully consumed.");
                }
            } catch (Throwable e) {
                throw new zzbvp(e);
            } catch (Throwable e2) {
                throw new zzbvh(e2);
            }
        }
    }

    private zzbvs<Number> zzbk(boolean z) {
        return z ? zzbwv.zzctr : new C05383(this);
    }

    private zzbvs<Number> zzbl(boolean z) {
        return z ? zzbwv.zzctq : new C05394(this);
    }

    private void zzm(double d) {
        if (Double.isNaN(d) || Double.isInfinite(d)) {
            throw new IllegalArgumentException(d + " is not a valid double value as per JSON specification. To override this" + " behavior, use GsonBuilder.serializeSpecialFloatingPointValues() method.");
        }
    }

    public String toString() {
        return "{serializeNulls:" + this.zzcqX + "factories:" + this.zzcqV + ",instanceCreators:" + this.zzcqW + "}";
    }

    public <T> zzbvs<T> zza(zzbvt com_google_android_gms_internal_zzbvt, zzbww<T> com_google_android_gms_internal_zzbww_T) {
        Object obj = null;
        if (!this.zzcqV.contains(com_google_android_gms_internal_zzbvt)) {
            obj = 1;
        }
        Object obj2 = obj;
        for (zzbvt com_google_android_gms_internal_zzbvt2 : this.zzcqV) {
            if (obj2 != null) {
                zzbvs<T> zza = com_google_android_gms_internal_zzbvt2.zza(this, com_google_android_gms_internal_zzbww_T);
                if (zza != null) {
                    return zza;
                }
            } else if (com_google_android_gms_internal_zzbvt2 == com_google_android_gms_internal_zzbvt) {
                obj2 = 1;
            }
        }
        String valueOf = String.valueOf(com_google_android_gms_internal_zzbww_T);
        throw new IllegalArgumentException(new StringBuilder(String.valueOf(valueOf).length() + 22).append("GSON cannot serialize ").append(valueOf).toString());
    }

    public <T> zzbvs<T> zza(zzbww<T> com_google_android_gms_internal_zzbww_T) {
        zzbvs<T> com_google_android_gms_internal_zzbvs_T = (zzbvs) this.zzcqU.get(com_google_android_gms_internal_zzbww_T);
        if (com_google_android_gms_internal_zzbvs_T == null) {
            Map map;
            Map map2 = (Map) this.zzcqT.get();
            Object obj = null;
            if (map2 == null) {
                HashMap hashMap = new HashMap();
                this.zzcqT.set(hashMap);
                map = hashMap;
                obj = 1;
            } else {
                map = map2;
            }
            zza com_google_android_gms_internal_zzbva_zza = (zza) map.get(com_google_android_gms_internal_zzbww_T);
            if (com_google_android_gms_internal_zzbva_zza == null) {
                try {
                    zza com_google_android_gms_internal_zzbva_zza2 = new zza();
                    map.put(com_google_android_gms_internal_zzbww_T, com_google_android_gms_internal_zzbva_zza2);
                    for (zzbvt zza : this.zzcqV) {
                        com_google_android_gms_internal_zzbvs_T = zza.zza(this, com_google_android_gms_internal_zzbww_T);
                        if (com_google_android_gms_internal_zzbvs_T != null) {
                            com_google_android_gms_internal_zzbva_zza2.zza(com_google_android_gms_internal_zzbvs_T);
                            this.zzcqU.put(com_google_android_gms_internal_zzbww_T, com_google_android_gms_internal_zzbvs_T);
                            map.remove(com_google_android_gms_internal_zzbww_T);
                            if (obj != null) {
                                this.zzcqT.remove();
                            }
                        }
                    }
                    String valueOf = String.valueOf(com_google_android_gms_internal_zzbww_T);
                    throw new IllegalArgumentException(new StringBuilder(String.valueOf(valueOf).length() + 19).append("GSON cannot handle ").append(valueOf).toString());
                } catch (Throwable th) {
                    map.remove(com_google_android_gms_internal_zzbww_T);
                    if (obj != null) {
                        this.zzcqT.remove();
                    }
                }
            }
        }
        return com_google_android_gms_internal_zzbvs_T;
    }

    public zzbwz zza(Writer writer) throws IOException {
        if (this.zzcqZ) {
            writer.write(")]}'\n");
        }
        zzbwz com_google_android_gms_internal_zzbwz = new zzbwz(writer);
        if (this.zzcra) {
            com_google_android_gms_internal_zzbwz.setIndent("  ");
        }
        com_google_android_gms_internal_zzbwz.zzbp(this.zzcqX);
        return com_google_android_gms_internal_zzbwz;
    }

    public <T> T zza(zzbvg com_google_android_gms_internal_zzbvg, Class<T> cls) throws zzbvp {
        return zzbwg.zzo(cls).cast(zza(com_google_android_gms_internal_zzbvg, (Type) cls));
    }

    public <T> T zza(zzbvg com_google_android_gms_internal_zzbvg, Type type) throws zzbvp {
        return com_google_android_gms_internal_zzbvg == null ? null : zza(new zzbwn(com_google_android_gms_internal_zzbvg), type);
    }

    public <T> T zza(zzbwx com_google_android_gms_internal_zzbwx, Type type) throws zzbvh, zzbvp {
        boolean z = true;
        boolean isLenient = com_google_android_gms_internal_zzbwx.isLenient();
        com_google_android_gms_internal_zzbwx.setLenient(true);
        try {
            com_google_android_gms_internal_zzbwx.zzaen();
            z = false;
            T zzb = zza(zzbww.zzl(type)).zzb(com_google_android_gms_internal_zzbwx);
            com_google_android_gms_internal_zzbwx.setLenient(isLenient);
            return zzb;
        } catch (Throwable e) {
            if (z) {
                com_google_android_gms_internal_zzbwx.setLenient(isLenient);
                return null;
            }
            throw new zzbvp(e);
        } catch (Throwable e2) {
            throw new zzbvp(e2);
        } catch (Throwable e22) {
            throw new zzbvp(e22);
        } catch (Throwable th) {
            com_google_android_gms_internal_zzbwx.setLenient(isLenient);
        }
    }

    public <T> T zza(Reader reader, Type type) throws zzbvh, zzbvp {
        zzbwx com_google_android_gms_internal_zzbwx = new zzbwx(reader);
        Object zza = zza(com_google_android_gms_internal_zzbwx, type);
        zza(zza, com_google_android_gms_internal_zzbwx);
        return zza;
    }

    public <T> T zza(String str, Type type) throws zzbvp {
        return str == null ? null : zza(new StringReader(str), type);
    }

    public void zza(zzbvg com_google_android_gms_internal_zzbvg, zzbwz com_google_android_gms_internal_zzbwz) throws zzbvh {
        boolean isLenient = com_google_android_gms_internal_zzbwz.isLenient();
        com_google_android_gms_internal_zzbwz.setLenient(true);
        boolean zzaeJ = com_google_android_gms_internal_zzbwz.zzaeJ();
        com_google_android_gms_internal_zzbwz.zzbo(this.zzcqY);
        boolean zzaeK = com_google_android_gms_internal_zzbwz.zzaeK();
        com_google_android_gms_internal_zzbwz.zzbp(this.zzcqX);
        try {
            zzbwh.zzb(com_google_android_gms_internal_zzbvg, com_google_android_gms_internal_zzbwz);
            com_google_android_gms_internal_zzbwz.setLenient(isLenient);
            com_google_android_gms_internal_zzbwz.zzbo(zzaeJ);
            com_google_android_gms_internal_zzbwz.zzbp(zzaeK);
        } catch (Throwable e) {
            throw new zzbvh(e);
        } catch (Throwable th) {
            com_google_android_gms_internal_zzbwz.setLenient(isLenient);
            com_google_android_gms_internal_zzbwz.zzbo(zzaeJ);
            com_google_android_gms_internal_zzbwz.zzbp(zzaeK);
        }
    }

    public void zza(zzbvg com_google_android_gms_internal_zzbvg, Appendable appendable) throws zzbvh {
        try {
            zza(com_google_android_gms_internal_zzbvg, zza(zzbwh.zza(appendable)));
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    public void zza(Object obj, Type type, zzbwz com_google_android_gms_internal_zzbwz) throws zzbvh {
        zzbvs zza = zza(zzbww.zzl(type));
        boolean isLenient = com_google_android_gms_internal_zzbwz.isLenient();
        com_google_android_gms_internal_zzbwz.setLenient(true);
        boolean zzaeJ = com_google_android_gms_internal_zzbwz.zzaeJ();
        com_google_android_gms_internal_zzbwz.zzbo(this.zzcqY);
        boolean zzaeK = com_google_android_gms_internal_zzbwz.zzaeK();
        com_google_android_gms_internal_zzbwz.zzbp(this.zzcqX);
        try {
            zza.zza(com_google_android_gms_internal_zzbwz, obj);
            com_google_android_gms_internal_zzbwz.setLenient(isLenient);
            com_google_android_gms_internal_zzbwz.zzbo(zzaeJ);
            com_google_android_gms_internal_zzbwz.zzbp(zzaeK);
        } catch (Throwable e) {
            throw new zzbvh(e);
        } catch (Throwable th) {
            com_google_android_gms_internal_zzbwz.setLenient(isLenient);
            com_google_android_gms_internal_zzbwz.zzbo(zzaeJ);
            com_google_android_gms_internal_zzbwz.zzbp(zzaeK);
        }
    }

    public void zza(Object obj, Type type, Appendable appendable) throws zzbvh {
        try {
            zza(obj, type, zza(zzbwh.zza(appendable)));
        } catch (Throwable e) {
            throw new zzbvh(e);
        }
    }

    public String zzaM(Object obj) {
        return obj == null ? zzb(zzbvi.zzcrn) : zzc(obj, obj.getClass());
    }

    public String zzb(zzbvg com_google_android_gms_internal_zzbvg) {
        Appendable stringWriter = new StringWriter();
        zza(com_google_android_gms_internal_zzbvg, stringWriter);
        return stringWriter.toString();
    }

    public String zzc(Object obj, Type type) {
        Appendable stringWriter = new StringWriter();
        zza(obj, type, stringWriter);
        return stringWriter.toString();
    }

    public <T> T zzf(String str, Class<T> cls) throws zzbvp {
        return zzbwg.zzo(cls).cast(zza(str, (Type) cls));
    }

    public <T> zzbvs<T> zzj(Class<T> cls) {
        return zza(zzbww.zzq(cls));
    }
}
