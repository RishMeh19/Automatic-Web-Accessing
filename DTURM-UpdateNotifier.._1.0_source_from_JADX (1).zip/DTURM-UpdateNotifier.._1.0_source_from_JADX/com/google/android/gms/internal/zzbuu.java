package com.google.android.gms.internal;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.firebase.storage.StorageException;
import java.io.InputStream;
import java.net.SocketException;
import org.json.JSONObject;

public class zzbuu {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbuu.class.desiredAssertionStatus());
    private Exception zzbNK;
    private zzbur zzcqG;
    private int zzcqH;
    private Exception zzcqI;

    public zzbuu(@NonNull zzbur com_google_android_gms_internal_zzbur) {
        this.zzcqG = com_google_android_gms_internal_zzbur;
    }

    private boolean zzcH(Context context) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
            return true;
        }
        this.zzcqH = -2;
        this.zzcqI = new SocketException("Network subsystem is unavailable");
        return false;
    }

    @Nullable
    public Exception getException() {
        try {
            return this.zzcqI != null ? this.zzcqI : this.zzbNK != null ? this.zzbNK : (Exception) zzd.zzF(this.zzcqG.zzadJ());
        } catch (Throwable e) {
            this.zzbNK = e;
            Log.e("NetworkRequestProxy", "getException failed with a RemoteException:", e);
            return null;
        }
    }

    public int getResultCode() {
        try {
            return this.zzcqH != 0 ? this.zzcqH : this.zzcqG.getResultCode();
        } catch (Throwable e) {
            this.zzbNK = e;
            Log.e("NetworkRequestProxy", "getResultCode failed with a RemoteException:", e);
            return 0;
        }
    }

    @Nullable
    public InputStream getStream() {
        try {
            return (InputStream) zzd.zzF(this.zzcqG.zzadF());
        } catch (Throwable e) {
            this.zzbNK = e;
            Log.e("NetworkRequestProxy", "getStream failed with a RemoteException:", e);
            return null;
        }
    }

    public void reset() {
        try {
            this.zzcqH = 0;
            this.zzcqI = null;
            this.zzcqG.reset();
        } catch (Throwable e) {
            this.zzbNK = e;
            Log.e("NetworkRequestProxy", "reset failed with a RemoteException:", e);
        }
    }

    public <TResult> void zza(TaskCompletionSource<TResult> taskCompletionSource, TResult tResult) {
        Throwable exception = getException();
        if (zzadK() && exception == null) {
            taskCompletionSource.setResult(tResult);
            return;
        }
        Exception fromExceptionAndHttpCode = StorageException.fromExceptionAndHttpCode(exception, getResultCode());
        if ($assertionsDisabled || fromExceptionAndHttpCode != null) {
            taskCompletionSource.setException(fromExceptionAndHttpCode);
            return;
        }
        throw new AssertionError();
    }

    public void zzaD(String str, String str2) {
        try {
            this.zzcqG.zzaD(str, str2);
        } catch (Throwable e) {
            Throwable th = e;
            String str3 = "NetworkRequestProxy";
            String str4 = "Caught remote exception setting custom header:";
            String valueOf = String.valueOf(str);
            Log.e(str3, valueOf.length() != 0 ? str4.concat(valueOf) : new String(str4), th);
        }
    }

    public void zzadE() {
        try {
            this.zzcqG.zzadE();
        } catch (Throwable e) {
            this.zzbNK = e;
            Log.e("NetworkRequestProxy", "performRequestEnd failed with a RemoteException:", e);
        }
    }

    @Nullable
    public String zzadH() {
        try {
            this.zzcqG.zzadH();
        } catch (Throwable e) {
            this.zzbNK = e;
            Log.e("NetworkRequestProxy", "getRawResult failed with a RemoteException:", e);
        }
        return null;
    }

    public boolean zzadK() {
        boolean z = false;
        try {
            if (this.zzcqH != -2 && this.zzcqI == null) {
                z = this.zzcqG.zzadK();
            }
        } catch (Throwable e) {
            this.zzbNK = e;
            Log.e("NetworkRequestProxy", "isResultSuccess failed with a RemoteException:", e);
        }
        return z;
    }

    public int zzadL() {
        try {
            return this.zzcqG.zzadL();
        } catch (Throwable e) {
            this.zzbNK = e;
            Log.e("NetworkRequestProxy", "getResultingContentLength failed with a RemoteException:", e);
            return 0;
        }
    }

    @NonNull
    public JSONObject zzadN() throws RemoteException {
        return (JSONObject) zzd.zzF(this.zzcqG.zzadG());
    }

    public void zzd(@Nullable String str, @NonNull Context context) {
        try {
            if (zzcH(context)) {
                this.zzcqG.zzkf(str);
            }
        } catch (Throwable e) {
            this.zzbNK = e;
            Log.e("NetworkRequestProxy", "performRequest failed with a RemoteException:", e);
        }
    }

    public void zzkg(@Nullable String str) {
        try {
            this.zzcqG.zzkg(str);
        } catch (Throwable e) {
            this.zzbNK = e;
            Log.e("NetworkRequestProxy", "performRequestStart failed with a RemoteException:", e);
        }
    }

    @Nullable
    public String zzkh(String str) {
        try {
            return this.zzcqG.zzkh(str);
        } catch (Throwable e) {
            Throwable th = e;
            String str2 = "NetworkRequestProxy";
            String str3 = "getResultString failed with a RemoteException:";
            String valueOf = String.valueOf(str);
            Log.e(str2, valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3), th);
            return null;
        }
    }
}
