package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbqe.zza;

public class zzbqd extends zzbqe {
    private final zzboy zzcgJ;

    public zzbqd(zzbqf com_google_android_gms_internal_zzbqf, zzbph com_google_android_gms_internal_zzbph, zzboy com_google_android_gms_internal_zzboy) {
        super(zza.Merge, com_google_android_gms_internal_zzbqf, com_google_android_gms_internal_zzbph);
        this.zzcgJ = com_google_android_gms_internal_zzboy;
    }

    public String toString() {
        return String.format("Merge { path=%s, source=%s, children=%s }", new Object[]{zzWO(), zzZA(), this.zzcgJ});
    }

    public zzboy zzZz() {
        return this.zzcgJ;
    }

    public zzbqe zzc(zzbrq com_google_android_gms_internal_zzbrq) {
        if (!this.zzcai.isEmpty()) {
            return this.zzcai.zzYU().equals(com_google_android_gms_internal_zzbrq) ? new zzbqd(this.zzcgL, this.zzcai.zzYV(), this.zzcgJ) : null;
        } else {
            zzboy zzg = this.zzcgJ.zzg(new zzbph(com_google_android_gms_internal_zzbrq));
            return zzg.isEmpty() ? null : zzg.zzYr() != null ? new zzbqg(this.zzcgL, zzbph.zzYR(), zzg.zzYr()) : new zzbqd(this.zzcgL, zzbph.zzYR(), zzg);
        }
    }
}
