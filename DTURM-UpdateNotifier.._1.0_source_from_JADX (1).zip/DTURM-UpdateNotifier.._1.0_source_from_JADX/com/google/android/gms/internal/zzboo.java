package com.google.android.gms.internal;

public interface zzboo {
    zzboi zzXA();

    String zzXy();

    boolean zzXz();
}
