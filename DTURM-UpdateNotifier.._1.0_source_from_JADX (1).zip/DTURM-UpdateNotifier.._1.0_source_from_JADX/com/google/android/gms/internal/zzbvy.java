package com.google.android.gms.internal;

public final class zzbvy {
    public static void zzaw(boolean z) {
        if (!z) {
            throw new IllegalArgumentException();
        }
    }

    public static <T> T zzw(T t) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException();
    }
}
