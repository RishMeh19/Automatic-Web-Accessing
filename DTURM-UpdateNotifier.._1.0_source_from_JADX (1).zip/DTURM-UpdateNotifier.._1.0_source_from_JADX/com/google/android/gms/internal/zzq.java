package com.google.android.gms.internal;

public class zzq extends zzs {
    public zzq(zzj com_google_android_gms_internal_zzj) {
        super(com_google_android_gms_internal_zzj);
    }
}
