package com.google.android.gms.internal;

public final class zzbvh extends zzbvk {
    public zzbvh(String str) {
        super(str);
    }

    public zzbvh(Throwable th) {
        super(th);
    }
}
