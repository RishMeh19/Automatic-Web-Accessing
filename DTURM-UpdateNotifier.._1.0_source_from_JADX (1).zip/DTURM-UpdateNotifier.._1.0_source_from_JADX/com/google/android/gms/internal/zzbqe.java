package com.google.android.gms.internal;

public abstract class zzbqe {
    protected final zzbph zzcai;
    protected final zza zzcgK;
    protected final zzbqf zzcgL;

    public enum zza {
        Overwrite,
        Merge,
        AckUserWrite,
        ListenComplete
    }

    protected zzbqe(zza com_google_android_gms_internal_zzbqe_zza, zzbqf com_google_android_gms_internal_zzbqf, zzbph com_google_android_gms_internal_zzbph) {
        this.zzcgK = com_google_android_gms_internal_zzbqe_zza;
        this.zzcgL = com_google_android_gms_internal_zzbqf;
        this.zzcai = com_google_android_gms_internal_zzbph;
    }

    public zzbph zzWO() {
        return this.zzcai;
    }

    public zzbqf zzZA() {
        return this.zzcgL;
    }

    public zza zzZB() {
        return this.zzcgK;
    }

    public abstract zzbqe zzc(zzbrq com_google_android_gms_internal_zzbrq);
}
