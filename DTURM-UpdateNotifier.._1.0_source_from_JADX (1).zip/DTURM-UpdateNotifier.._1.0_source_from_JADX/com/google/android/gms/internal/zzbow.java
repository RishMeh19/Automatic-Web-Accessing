package com.google.android.gms.internal;

public interface zzbow {

    public interface zza {
        void onError(String str);

        void zziL(String str);
    }

    public interface zzb {
        void zziU(String str);
    }

    void zza(zzb com_google_android_gms_internal_zzbow_zzb);

    void zza(boolean z, zza com_google_android_gms_internal_zzbow_zza);
}
