package com.google.android.gms.internal;

public class zzbpo {
    private zzbsc zzcfC;

    zzbpo() {
        this.zzcfC = zzbrv.zzabb();
    }

    public zzbpo(zzbsc com_google_android_gms_internal_zzbsc) {
        this.zzcfC = com_google_android_gms_internal_zzbsc;
    }

    public zzbsc zzZh() {
        return this.zzcfC;
    }

    public void zzg(zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc) {
        this.zzcfC = this.zzcfC.zzl(com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbsc);
    }

    public zzbsc zzq(zzbph com_google_android_gms_internal_zzbph) {
        return this.zzcfC.zzO(com_google_android_gms_internal_zzbph);
    }
}
