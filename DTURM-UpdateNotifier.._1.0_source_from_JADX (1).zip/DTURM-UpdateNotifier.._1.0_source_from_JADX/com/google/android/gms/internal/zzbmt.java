package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;

public class zzbmt extends zza {
    public static final Creator<zzbmt> CREATOR = new zzbmu();
    @zzbmb
    public final int zzaiI;
    @zzbvv("email")
    private String zzaka;
    @zzbvv("newEmail")
    private String zzbYM;
    @zzbvv("requestType")
    private String zzbYN;

    public zzbmt() {
        this.zzaiI = 1;
    }

    zzbmt(int i, String str, String str2, String str3) {
        this.zzaiI = i;
        this.zzaka = str;
        this.zzbYM = str2;
        this.zzbYN = str3;
    }

    public String getEmail() {
        return this.zzaka;
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzbmu.zza(this, parcel, i);
    }

    public String zzWk() {
        return this.zzbYM;
    }

    public String zzWl() {
        return this.zzbYN;
    }
}
