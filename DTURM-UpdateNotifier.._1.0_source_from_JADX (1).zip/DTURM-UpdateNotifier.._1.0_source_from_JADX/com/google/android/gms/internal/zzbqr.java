package com.google.android.gms.internal;

public interface zzbqr<T> {
    public static final zzbqr<Object> zzchC = new C05301();

    class C05301 implements zzbqr<Object> {
        C05301() {
        }

        public boolean zzat(Object obj) {
            return true;
        }
    }

    boolean zzat(T t);
}
