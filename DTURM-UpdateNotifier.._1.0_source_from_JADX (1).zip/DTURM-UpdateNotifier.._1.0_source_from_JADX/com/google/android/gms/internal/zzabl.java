package com.google.android.gms.internal;

import com.google.android.gms.common.api.zzc;

public class zzabl {
    public final zzzx zzaDc;
    public final int zzaDd;
    public final zzc<?> zzaDe;

    public zzabl(zzzx com_google_android_gms_internal_zzzx, int i, zzc<?> com_google_android_gms_common_api_zzc_) {
        this.zzaDc = com_google_android_gms_internal_zzzx;
        this.zzaDd = i;
        this.zzaDe = com_google_android_gms_common_api_zzc_;
    }
}
