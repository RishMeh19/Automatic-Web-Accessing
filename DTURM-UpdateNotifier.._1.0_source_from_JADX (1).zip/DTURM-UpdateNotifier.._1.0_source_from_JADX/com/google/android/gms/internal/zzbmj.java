package com.google.android.gms.internal;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import com.google.android.gms.common.internal.safeparcel.zza;
import java.util.List;

public class zzbmj extends zza {
    public static final Creator<zzbmj> CREATOR = new zzbmk();
    @zzbvv("localId")
    private String zzaNX;
    @zzbvv("photoUrl")
    private String zzaQN;
    @zzbmb
    public final int zzaiI;
    @zzbvv("passwordHash")
    private String zzajh;
    @zzbvv("email")
    private String zzaka;
    @zzbvv("displayName")
    private String zzakb;
    @zzbvv("emailVerified")
    private boolean zzbYD;
    @zzbvv("providerUserInfo")
    private zzbmr zzbYE;

    public zzbmj() {
        this.zzaiI = 1;
        this.zzbYE = new zzbmr();
    }

    zzbmj(int i, String str, String str2, boolean z, String str3, String str4, zzbmr com_google_android_gms_internal_zzbmr, String str5) {
        this.zzaiI = i;
        this.zzaNX = str;
        this.zzaka = str2;
        this.zzbYD = z;
        this.zzakb = str3;
        this.zzaQN = str4;
        this.zzbYE = com_google_android_gms_internal_zzbmr == null ? zzbmr.zzWj() : zzbmr.zza(com_google_android_gms_internal_zzbmr);
        this.zzajh = str5;
    }

    @Nullable
    public String getDisplayName() {
        return this.zzakb;
    }

    @Nullable
    public String getEmail() {
        return this.zzaka;
    }

    @NonNull
    public String getLocalId() {
        return this.zzaNX;
    }

    @Nullable
    public String getPassword() {
        return this.zzajh;
    }

    @Nullable
    public Uri getPhotoUri() {
        return !TextUtils.isEmpty(this.zzaQN) ? Uri.parse(this.zzaQN) : null;
    }

    public boolean isEmailVerified() {
        return this.zzbYD;
    }

    public void writeToParcel(Parcel parcel, int i) {
        zzbmk.zza(this, parcel, i);
    }

    @Nullable
    public String zzVN() {
        return this.zzaQN;
    }

    @NonNull
    public List<zzbmp> zzWb() {
        return this.zzbYE.zzWb();
    }

    public zzbmr zzWc() {
        return this.zzbYE;
    }
}
