package com.google.android.gms.internal;

public interface zzbos {
    void zzar(String str, String str2);
}
