package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class zzbrf {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbrf.class.desiredAssertionStatus());
    private static com.google.android.gms.internal.zzbrj.zza zzciz = new C05321();
    private final zzbrj zzciy;

    public static class zza {
        public final zzbre zzcir;
        public final List<zzbqw> zzciv;

        public zza(zzbre com_google_android_gms_internal_zzbre, List<zzbqw> list) {
            this.zzcir = com_google_android_gms_internal_zzbre;
            this.zzciv = list;
        }
    }

    class C05321 implements com.google.android.gms.internal.zzbrj.zza {
        C05321() {
        }

        public zzbsb zza(zzbrw com_google_android_gms_internal_zzbrw, zzbsb com_google_android_gms_internal_zzbsb, boolean z) {
            return null;
        }

        public zzbsc zzh(zzbrq com_google_android_gms_internal_zzbrq) {
            return null;
        }
    }

    private static class zzb implements com.google.android.gms.internal.zzbrj.zza {
        private final zzbpz zzciB;
        private final zzbsc zzciC;
        private final zzbre zzcir;

        public zzb(zzbpz com_google_android_gms_internal_zzbpz, zzbre com_google_android_gms_internal_zzbre, zzbsc com_google_android_gms_internal_zzbsc) {
            this.zzciB = com_google_android_gms_internal_zzbpz;
            this.zzcir = com_google_android_gms_internal_zzbre;
            this.zzciC = com_google_android_gms_internal_zzbsc;
        }

        public zzbsb zza(zzbrw com_google_android_gms_internal_zzbrw, zzbsb com_google_android_gms_internal_zzbsb, boolean z) {
            return this.zzciB.zza(this.zzciC != null ? this.zzciC : this.zzcir.zzaaz(), com_google_android_gms_internal_zzbsb, z, com_google_android_gms_internal_zzbrw);
        }

        public zzbsc zzh(zzbrq com_google_android_gms_internal_zzbrq) {
            zzbqu zzaaw = this.zzcir.zzaaw();
            if (zzaaw.zzf(com_google_android_gms_internal_zzbrq)) {
                return zzaaw.zzWK().zzm(com_google_android_gms_internal_zzbrq);
            }
            return this.zzciB.zza(com_google_android_gms_internal_zzbrq, this.zzciC != null ? new zzbqu(zzbrx.zza(this.zzciC, zzbry.zzabi()), true, false) : this.zzcir.zzaay());
        }
    }

    public zzbrf(zzbrj com_google_android_gms_internal_zzbrj) {
        this.zzciy = com_google_android_gms_internal_zzbrj;
    }

    private zzbre zza(zzbre com_google_android_gms_internal_zzbre, zzbph com_google_android_gms_internal_zzbph, zzboy com_google_android_gms_internal_zzboy, zzbpz com_google_android_gms_internal_zzbpz, zzbsc com_google_android_gms_internal_zzbsc, zzbrg com_google_android_gms_internal_zzbrg) {
        if ($assertionsDisabled || com_google_android_gms_internal_zzboy.zzYr() == null) {
            Entry entry;
            zzbph zzh;
            Iterator it = com_google_android_gms_internal_zzboy.iterator();
            zzbre com_google_android_gms_internal_zzbre2 = com_google_android_gms_internal_zzbre;
            while (it.hasNext()) {
                entry = (Entry) it.next();
                zzh = com_google_android_gms_internal_zzbph.zzh((zzbph) entry.getKey());
                if (zza(com_google_android_gms_internal_zzbre, zzh.zzYU())) {
                    com_google_android_gms_internal_zzbre2 = zza(com_google_android_gms_internal_zzbre2, zzh, (zzbsc) entry.getValue(), com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbsc, com_google_android_gms_internal_zzbrg);
                }
            }
            it = com_google_android_gms_internal_zzboy.iterator();
            while (it.hasNext()) {
                entry = (Entry) it.next();
                zzh = com_google_android_gms_internal_zzbph.zzh((zzbph) entry.getKey());
                if (!zza(com_google_android_gms_internal_zzbre, zzh.zzYU())) {
                    com_google_android_gms_internal_zzbre2 = zza(com_google_android_gms_internal_zzbre2, zzh, (zzbsc) entry.getValue(), com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbsc, com_google_android_gms_internal_zzbrg);
                }
            }
            return com_google_android_gms_internal_zzbre2;
        }
        throw new AssertionError("Can't have a merge that is an overwrite");
    }

    private zzbre zza(zzbre com_google_android_gms_internal_zzbre, zzbph com_google_android_gms_internal_zzbph, zzboy com_google_android_gms_internal_zzboy, zzbpz com_google_android_gms_internal_zzbpz, zzbsc com_google_android_gms_internal_zzbsc, boolean z, zzbrg com_google_android_gms_internal_zzbrg) {
        if (com_google_android_gms_internal_zzbre.zzaay().zzWK().isEmpty() && !com_google_android_gms_internal_zzbre.zzaay().zzZS()) {
            return com_google_android_gms_internal_zzbre;
        }
        if ($assertionsDisabled || com_google_android_gms_internal_zzboy.zzYr() == null) {
            zzbrq com_google_android_gms_internal_zzbrq;
            if (!com_google_android_gms_internal_zzbph.isEmpty()) {
                com_google_android_gms_internal_zzboy = zzboy.zzYq().zzb(com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzboy);
            }
            zzbsc zzWK = com_google_android_gms_internal_zzbre.zzaay().zzWK();
            Map zzYt = com_google_android_gms_internal_zzboy.zzYt();
            zzbre com_google_android_gms_internal_zzbre2 = com_google_android_gms_internal_zzbre;
            for (Entry entry : zzYt.entrySet()) {
                com_google_android_gms_internal_zzbrq = (zzbrq) entry.getKey();
                if (zzWK.zzk(com_google_android_gms_internal_zzbrq)) {
                    com_google_android_gms_internal_zzbre2 = zza(com_google_android_gms_internal_zzbre2, new zzbph(com_google_android_gms_internal_zzbrq), ((zzboy) entry.getValue()).zzb(zzWK.zzm(com_google_android_gms_internal_zzbrq)), com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbsc, z, com_google_android_gms_internal_zzbrg);
                }
            }
            for (Entry entry2 : zzYt.entrySet()) {
                com_google_android_gms_internal_zzbrq = (zzbrq) entry2.getKey();
                Object obj = (com_google_android_gms_internal_zzbre.zzaay().zzf(com_google_android_gms_internal_zzbrq) || ((zzboy) entry2.getValue()).zzYr() != null) ? null : 1;
                if (!zzWK.zzk(com_google_android_gms_internal_zzbrq) && obj == null) {
                    com_google_android_gms_internal_zzbre2 = zza(com_google_android_gms_internal_zzbre2, new zzbph(com_google_android_gms_internal_zzbrq), ((zzboy) entry2.getValue()).zzb(zzWK.zzm(com_google_android_gms_internal_zzbrq)), com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbsc, z, com_google_android_gms_internal_zzbrg);
                }
            }
            return com_google_android_gms_internal_zzbre2;
        }
        throw new AssertionError("Can't have a merge that is an overwrite");
    }

    private zzbre zza(zzbre com_google_android_gms_internal_zzbre, zzbph com_google_android_gms_internal_zzbph, zzbpz com_google_android_gms_internal_zzbpz, com.google.android.gms.internal.zzbrj.zza com_google_android_gms_internal_zzbrj_zza, zzbrg com_google_android_gms_internal_zzbrg) {
        zzbqu zzaaw = com_google_android_gms_internal_zzbre.zzaaw();
        if (com_google_android_gms_internal_zzbpz.zzv(com_google_android_gms_internal_zzbph) != null) {
            return com_google_android_gms_internal_zzbre;
        }
        zzbrx zza;
        zzbsc zza2;
        if (!com_google_android_gms_internal_zzbph.isEmpty()) {
            zzbrq zzYU = com_google_android_gms_internal_zzbph.zzYU();
            if (!zzYU.zzaaM()) {
                zzbsc zzl;
                zzbph zzYV = com_google_android_gms_internal_zzbph.zzYV();
                if (zzaaw.zzf(zzYU)) {
                    zza2 = com_google_android_gms_internal_zzbpz.zza(com_google_android_gms_internal_zzbph, zzaaw.zzWK(), com_google_android_gms_internal_zzbre.zzaay().zzWK());
                    zzl = zza2 != null ? zzaaw.zzWK().zzm(zzYU).zzl(zzYV, zza2) : zzaaw.zzWK().zzm(zzYU);
                } else {
                    zzl = com_google_android_gms_internal_zzbpz.zza(zzYU, com_google_android_gms_internal_zzbre.zzaay());
                }
                zza = zzl != null ? this.zzciy.zza(zzaaw.zzZU(), zzYU, zzl, zzYV, com_google_android_gms_internal_zzbrj_zza, com_google_android_gms_internal_zzbrg) : zzaaw.zzZU();
            } else if ($assertionsDisabled || com_google_android_gms_internal_zzbph.size() == 1) {
                zza2 = com_google_android_gms_internal_zzbpz.zza(com_google_android_gms_internal_zzbph, zzaaw.zzWK(), com_google_android_gms_internal_zzbre.zzaay().zzWK());
                zza = zza2 != null ? this.zzciy.zza(zzaaw.zzZU(), zza2) : zzaaw.zzZU();
            } else {
                throw new AssertionError("Can't have a priority with additional path components");
            }
        } else if ($assertionsDisabled || com_google_android_gms_internal_zzbre.zzaay().zzZS()) {
            if (com_google_android_gms_internal_zzbre.zzaay().zzZT()) {
                zza2 = com_google_android_gms_internal_zzbre.zzaaz();
                if (!(zza2 instanceof zzbrr)) {
                    zza2 = zzbrv.zzabb();
                }
                zza2 = com_google_android_gms_internal_zzbpz.zzd(zza2);
            } else {
                zza2 = com_google_android_gms_internal_zzbpz.zzc(com_google_android_gms_internal_zzbre.zzaaz());
            }
            zza = this.zzciy.zza(com_google_android_gms_internal_zzbre.zzaaw().zzZU(), zzbrx.zza(zza2, this.zzciy.zzaal()), com_google_android_gms_internal_zzbrg);
        } else {
            throw new AssertionError("If change path is empty, we must have complete server data");
        }
        boolean z = zzaaw.zzZS() || com_google_android_gms_internal_zzbph.isEmpty();
        return com_google_android_gms_internal_zzbre.zza(zza, z, this.zzciy.zzaaC());
    }

    private zzbre zza(zzbre com_google_android_gms_internal_zzbre, zzbph com_google_android_gms_internal_zzbph, zzbqq<Boolean> com_google_android_gms_internal_zzbqq_java_lang_Boolean, zzbpz com_google_android_gms_internal_zzbpz, zzbsc com_google_android_gms_internal_zzbsc, zzbrg com_google_android_gms_internal_zzbrg) {
        if (com_google_android_gms_internal_zzbpz.zzv(com_google_android_gms_internal_zzbph) != null) {
            return com_google_android_gms_internal_zzbre;
        }
        boolean zzZT = com_google_android_gms_internal_zzbre.zzaay().zzZT();
        zzbqu zzaay = com_google_android_gms_internal_zzbre.zzaay();
        zzboy zzYq;
        if (com_google_android_gms_internal_zzbqq_java_lang_Boolean.getValue() == null) {
            zzYq = zzboy.zzYq();
            Iterator it = com_google_android_gms_internal_zzbqq_java_lang_Boolean.iterator();
            while (it.hasNext()) {
                zzbph com_google_android_gms_internal_zzbph2 = (zzbph) ((Entry) it.next()).getKey();
                zzbph zzh = com_google_android_gms_internal_zzbph.zzh(com_google_android_gms_internal_zzbph2);
                if (zzaay.zzM(zzh)) {
                    zzYq = zzYq.zze(com_google_android_gms_internal_zzbph2, zzaay.zzWK().zzO(zzh));
                }
            }
            return zza(com_google_android_gms_internal_zzbre, com_google_android_gms_internal_zzbph, zzYq, com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbsc, zzZT, com_google_android_gms_internal_zzbrg);
        } else if ((com_google_android_gms_internal_zzbph.isEmpty() && zzaay.zzZS()) || zzaay.zzM(com_google_android_gms_internal_zzbph)) {
            return zza(com_google_android_gms_internal_zzbre, com_google_android_gms_internal_zzbph, zzaay.zzWK().zzO(com_google_android_gms_internal_zzbph), com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbsc, zzZT, com_google_android_gms_internal_zzbrg);
        } else if (!com_google_android_gms_internal_zzbph.isEmpty()) {
            return com_google_android_gms_internal_zzbre;
        } else {
            zzYq = zzboy.zzYq();
            for (zzbsb com_google_android_gms_internal_zzbsb : zzaay.zzWK()) {
                zzYq = zzYq.zza(com_google_android_gms_internal_zzbsb.zzabl(), com_google_android_gms_internal_zzbsb.zzWK());
            }
            return zza(com_google_android_gms_internal_zzbre, com_google_android_gms_internal_zzbph, zzYq, com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbsc, zzZT, com_google_android_gms_internal_zzbrg);
        }
    }

    private zzbre zza(zzbre com_google_android_gms_internal_zzbre, zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc, zzbpz com_google_android_gms_internal_zzbpz, zzbsc com_google_android_gms_internal_zzbsc2, zzbrg com_google_android_gms_internal_zzbrg) {
        zzbqu zzaaw = com_google_android_gms_internal_zzbre.zzaaw();
        com.google.android.gms.internal.zzbrj.zza com_google_android_gms_internal_zzbrf_zzb = new zzb(com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbre, com_google_android_gms_internal_zzbsc2);
        if (com_google_android_gms_internal_zzbph.isEmpty()) {
            return com_google_android_gms_internal_zzbre.zza(this.zzciy.zza(com_google_android_gms_internal_zzbre.zzaaw().zzZU(), zzbrx.zza(com_google_android_gms_internal_zzbsc, this.zzciy.zzaal()), com_google_android_gms_internal_zzbrg), true, this.zzciy.zzaaC());
        }
        zzbrq zzYU = com_google_android_gms_internal_zzbph.zzYU();
        if (zzYU.zzaaM()) {
            return com_google_android_gms_internal_zzbre.zza(this.zzciy.zza(com_google_android_gms_internal_zzbre.zzaaw().zzZU(), com_google_android_gms_internal_zzbsc), zzaaw.zzZS(), zzaaw.zzZT());
        }
        zzbsc com_google_android_gms_internal_zzbsc3;
        zzbph zzYV = com_google_android_gms_internal_zzbph.zzYV();
        zzbsc zzm = zzaaw.zzWK().zzm(zzYU);
        if (zzYV.isEmpty()) {
            com_google_android_gms_internal_zzbsc3 = com_google_android_gms_internal_zzbsc;
        } else {
            com_google_android_gms_internal_zzbsc3 = com_google_android_gms_internal_zzbrf_zzb.zzh(zzYU);
            if (com_google_android_gms_internal_zzbsc3 == null) {
                com_google_android_gms_internal_zzbsc3 = zzbrv.zzabb();
            } else if (!(zzYV.zzYX().zzaaM() && com_google_android_gms_internal_zzbsc3.zzO(zzYV.zzYW()).isEmpty())) {
                com_google_android_gms_internal_zzbsc3 = com_google_android_gms_internal_zzbsc3.zzl(zzYV, com_google_android_gms_internal_zzbsc);
            }
        }
        return !zzm.equals(com_google_android_gms_internal_zzbsc3) ? com_google_android_gms_internal_zzbre.zza(this.zzciy.zza(zzaaw.zzZU(), zzYU, com_google_android_gms_internal_zzbsc3, zzYV, com_google_android_gms_internal_zzbrf_zzb, com_google_android_gms_internal_zzbrg), zzaaw.zzZS(), this.zzciy.zzaaC()) : com_google_android_gms_internal_zzbre;
    }

    private zzbre zza(zzbre com_google_android_gms_internal_zzbre, zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc, zzbpz com_google_android_gms_internal_zzbpz, zzbsc com_google_android_gms_internal_zzbsc2, boolean z, zzbrg com_google_android_gms_internal_zzbrg) {
        zzbrx zza;
        zzbqu zzaay = com_google_android_gms_internal_zzbre.zzaay();
        zzbrj zzaaB = z ? this.zzciy : this.zzciy.zzaaB();
        if (com_google_android_gms_internal_zzbph.isEmpty()) {
            zza = zzaaB.zza(zzaay.zzZU(), zzbrx.zza(com_google_android_gms_internal_zzbsc, zzaaB.zzaal()), null);
        } else if (!zzaaB.zzaaC() || zzaay.zzZT()) {
            zzbrq zzYU = com_google_android_gms_internal_zzbph.zzYU();
            if (!zzaay.zzM(com_google_android_gms_internal_zzbph) && com_google_android_gms_internal_zzbph.size() > 1) {
                return com_google_android_gms_internal_zzbre;
            }
            zzbph zzYV = com_google_android_gms_internal_zzbph.zzYV();
            zzbsc zzl = zzaay.zzWK().zzm(zzYU).zzl(zzYV, com_google_android_gms_internal_zzbsc);
            zza = zzYU.zzaaM() ? zzaaB.zza(zzaay.zzZU(), zzl) : zzaaB.zza(zzaay.zzZU(), zzYU, zzl, zzYV, zzciz, null);
        } else if ($assertionsDisabled || !com_google_android_gms_internal_zzbph.isEmpty()) {
            zzbrq zzYU2 = com_google_android_gms_internal_zzbph.zzYU();
            zza = zzaaB.zza(zzaay.zzZU(), zzaay.zzZU().zzh(zzYU2, zzaay.zzWK().zzm(zzYU2).zzl(com_google_android_gms_internal_zzbph.zzYV(), com_google_android_gms_internal_zzbsc)), null);
        } else {
            throw new AssertionError("An empty path should have been caught in the other branch");
        }
        boolean z2 = zzaay.zzZS() || com_google_android_gms_internal_zzbph.isEmpty();
        zzbre zzb = com_google_android_gms_internal_zzbre.zzb(zza, z2, zzaaB.zzaaC());
        return zza(zzb, com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbpz, new zzb(com_google_android_gms_internal_zzbpz, zzb, com_google_android_gms_internal_zzbsc2), com_google_android_gms_internal_zzbrg);
    }

    private void zza(zzbre com_google_android_gms_internal_zzbre, zzbre com_google_android_gms_internal_zzbre2, List<zzbqw> list) {
        zzbqu zzaaw = com_google_android_gms_internal_zzbre2.zzaaw();
        if (zzaaw.zzZS()) {
            Object obj = (zzaaw.zzWK().zzaaP() || zzaaw.zzWK().isEmpty()) ? 1 : null;
            if (!list.isEmpty() || !com_google_android_gms_internal_zzbre.zzaaw().zzZS() || ((obj != null && !zzaaw.zzWK().equals(com_google_android_gms_internal_zzbre.zzaax())) || !zzaaw.zzWK().zzaaQ().equals(com_google_android_gms_internal_zzbre.zzaax().zzaaQ()))) {
                list.add(zzbqw.zza(zzaaw.zzZU()));
            }
        }
    }

    private static boolean zza(zzbre com_google_android_gms_internal_zzbre, zzbrq com_google_android_gms_internal_zzbrq) {
        return com_google_android_gms_internal_zzbre.zzaaw().zzf(com_google_android_gms_internal_zzbrq);
    }

    private zzbre zzb(zzbre com_google_android_gms_internal_zzbre, zzbph com_google_android_gms_internal_zzbph, zzbpz com_google_android_gms_internal_zzbpz, zzbsc com_google_android_gms_internal_zzbsc, zzbrg com_google_android_gms_internal_zzbrg) {
        zzbqu zzaay = com_google_android_gms_internal_zzbre.zzaay();
        zzbrx zzZU = zzaay.zzZU();
        boolean z = zzaay.zzZS() || com_google_android_gms_internal_zzbph.isEmpty();
        return zza(com_google_android_gms_internal_zzbre.zzb(zzZU, z, zzaay.zzZT()), com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbpz, zzciz, com_google_android_gms_internal_zzbrg);
    }

    public zzbre zza(zzbre com_google_android_gms_internal_zzbre, zzbph com_google_android_gms_internal_zzbph, zzbpz com_google_android_gms_internal_zzbpz, zzbsc com_google_android_gms_internal_zzbsc, zzbrg com_google_android_gms_internal_zzbrg) {
        if (com_google_android_gms_internal_zzbpz.zzv(com_google_android_gms_internal_zzbph) != null) {
            return com_google_android_gms_internal_zzbre;
        }
        com.google.android.gms.internal.zzbrj.zza com_google_android_gms_internal_zzbrf_zzb = new zzb(com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbre, com_google_android_gms_internal_zzbsc);
        zzbrx zzZU = com_google_android_gms_internal_zzbre.zzaaw().zzZU();
        if (com_google_android_gms_internal_zzbph.isEmpty() || com_google_android_gms_internal_zzbph.zzYU().zzaaM()) {
            zzZU = this.zzciy.zza(zzZU, zzbrx.zza(com_google_android_gms_internal_zzbre.zzaay().zzZS() ? com_google_android_gms_internal_zzbpz.zzc(com_google_android_gms_internal_zzbre.zzaaz()) : com_google_android_gms_internal_zzbpz.zzd(com_google_android_gms_internal_zzbre.zzaay().zzWK()), this.zzciy.zzaal()), com_google_android_gms_internal_zzbrg);
        } else {
            zzbrq zzYU = com_google_android_gms_internal_zzbph.zzYU();
            zzbsc zza = com_google_android_gms_internal_zzbpz.zza(zzYU, com_google_android_gms_internal_zzbre.zzaay());
            if (zza == null && com_google_android_gms_internal_zzbre.zzaay().zzf(zzYU)) {
                zza = zzZU.zzWK().zzm(zzYU);
            }
            if (zza != null) {
                zzZU = this.zzciy.zza(zzZU, zzYU, zza, com_google_android_gms_internal_zzbph.zzYV(), com_google_android_gms_internal_zzbrf_zzb, com_google_android_gms_internal_zzbrg);
            } else if (zza == null && com_google_android_gms_internal_zzbre.zzaaw().zzWK().zzk(zzYU)) {
                zzZU = this.zzciy.zza(zzZU, zzYU, zzbrv.zzabb(), com_google_android_gms_internal_zzbph.zzYV(), com_google_android_gms_internal_zzbrf_zzb, com_google_android_gms_internal_zzbrg);
            }
            if (zzZU.zzWK().isEmpty() && com_google_android_gms_internal_zzbre.zzaay().zzZS()) {
                zzbsc zzc = com_google_android_gms_internal_zzbpz.zzc(com_google_android_gms_internal_zzbre.zzaaz());
                if (zzc.zzaaP()) {
                    zzZU = this.zzciy.zza(zzZU, zzbrx.zza(zzc, this.zzciy.zzaal()), com_google_android_gms_internal_zzbrg);
                }
            }
        }
        boolean z = com_google_android_gms_internal_zzbre.zzaay().zzZS() || com_google_android_gms_internal_zzbpz.zzv(zzbph.zzYR()) != null;
        return com_google_android_gms_internal_zzbre.zza(zzZU, z, this.zzciy.zzaaC());
    }

    public zza zza(zzbre com_google_android_gms_internal_zzbre, zzbqe com_google_android_gms_internal_zzbqe, zzbpz com_google_android_gms_internal_zzbpz, zzbsc com_google_android_gms_internal_zzbsc) {
        zzbre zza;
        zzbrg com_google_android_gms_internal_zzbrg = new zzbrg();
        boolean z;
        switch (com_google_android_gms_internal_zzbqe.zzZB()) {
            case Overwrite:
                zzbqg com_google_android_gms_internal_zzbqg = (zzbqg) com_google_android_gms_internal_zzbqe;
                if (com_google_android_gms_internal_zzbqg.zzZA().zzZC()) {
                    zza = zza(com_google_android_gms_internal_zzbre, com_google_android_gms_internal_zzbqg.zzWO(), com_google_android_gms_internal_zzbqg.zzZG(), com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbsc, com_google_android_gms_internal_zzbrg);
                    break;
                } else if ($assertionsDisabled || com_google_android_gms_internal_zzbqg.zzZA().zzZD()) {
                    z = com_google_android_gms_internal_zzbqg.zzZA().zzZE() || (com_google_android_gms_internal_zzbre.zzaay().zzZT() && !com_google_android_gms_internal_zzbqg.zzWO().isEmpty());
                    zza = zza(com_google_android_gms_internal_zzbre, com_google_android_gms_internal_zzbqg.zzWO(), com_google_android_gms_internal_zzbqg.zzZG(), com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbsc, z, com_google_android_gms_internal_zzbrg);
                    break;
                } else {
                    throw new AssertionError();
                }
                break;
            case Merge:
                zzbqd com_google_android_gms_internal_zzbqd = (zzbqd) com_google_android_gms_internal_zzbqe;
                if (com_google_android_gms_internal_zzbqd.zzZA().zzZC()) {
                    zza = zza(com_google_android_gms_internal_zzbre, com_google_android_gms_internal_zzbqd.zzWO(), com_google_android_gms_internal_zzbqd.zzZz(), com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbsc, com_google_android_gms_internal_zzbrg);
                    break;
                } else if ($assertionsDisabled || com_google_android_gms_internal_zzbqd.zzZA().zzZD()) {
                    z = com_google_android_gms_internal_zzbqd.zzZA().zzZE() || com_google_android_gms_internal_zzbre.zzaay().zzZT();
                    zza = zza(com_google_android_gms_internal_zzbre, com_google_android_gms_internal_zzbqd.zzWO(), com_google_android_gms_internal_zzbqd.zzZz(), com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbsc, z, com_google_android_gms_internal_zzbrg);
                    break;
                } else {
                    throw new AssertionError();
                }
                break;
            case AckUserWrite:
                zzbqb com_google_android_gms_internal_zzbqb = (zzbqb) com_google_android_gms_internal_zzbqe;
                if (!com_google_android_gms_internal_zzbqb.zzZy()) {
                    zza = zza(com_google_android_gms_internal_zzbre, com_google_android_gms_internal_zzbqb.zzWO(), com_google_android_gms_internal_zzbqb.zzZx(), com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbsc, com_google_android_gms_internal_zzbrg);
                    break;
                }
                zza = zza(com_google_android_gms_internal_zzbre, com_google_android_gms_internal_zzbqb.zzWO(), com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbsc, com_google_android_gms_internal_zzbrg);
                break;
            case ListenComplete:
                zza = zzb(com_google_android_gms_internal_zzbre, com_google_android_gms_internal_zzbqe.zzWO(), com_google_android_gms_internal_zzbpz, com_google_android_gms_internal_zzbsc, com_google_android_gms_internal_zzbrg);
                break;
            default:
                String valueOf = String.valueOf(com_google_android_gms_internal_zzbqe.zzZB());
                throw new AssertionError(new StringBuilder(String.valueOf(valueOf).length() + 19).append("Unknown operation: ").append(valueOf).toString());
        }
        List arrayList = new ArrayList(com_google_android_gms_internal_zzbrg.zzaaA());
        zza(com_google_android_gms_internal_zzbre, zza, arrayList);
        return new zza(zza, arrayList);
    }
}
