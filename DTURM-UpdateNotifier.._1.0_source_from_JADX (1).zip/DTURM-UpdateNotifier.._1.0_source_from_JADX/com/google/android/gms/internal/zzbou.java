package com.google.android.gms.internal;

import java.util.Random;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class zzbou {
    private final zzbrn zzcaH;
    private final ScheduledExecutorService zzcav;
    private final long zzcdp;
    private final long zzcdq;
    private final double zzcdr;
    private final double zzcds;
    private final Random zzcdt;
    private ScheduledFuture<?> zzcdu;
    private long zzcdv;
    private boolean zzcdw;

    public static class zza {
        private final zzbrn zzcaH;
        private long zzcdp = 1000;
        private double zzcdr = 0.5d;
        private double zzcds = 1.3d;
        private final ScheduledExecutorService zzcdy;
        private long zzcdz = 30000;

        public zza(ScheduledExecutorService scheduledExecutorService, zzbro com_google_android_gms_internal_zzbro, String str) {
            this.zzcdy = scheduledExecutorService;
            this.zzcaH = new zzbrn(com_google_android_gms_internal_zzbro, str);
        }

        public zzbou zzYk() {
            return new zzbou(this.zzcdy, this.zzcaH, this.zzcdp, this.zzcdz, this.zzcds, this.zzcdr);
        }

        public zza zzaM(long j) {
            this.zzcdp = j;
            return this;
        }

        public zza zzaN(long j) {
            this.zzcdz = j;
            return this;
        }

        public zza zzj(double d) {
            this.zzcds = d;
            return this;
        }

        public zza zzk(double d) {
            if (d < 0.0d || d > 1.0d) {
                throw new IllegalArgumentException("Argument out of range: " + d);
            }
            this.zzcdr = d;
            return this;
        }
    }

    private zzbou(ScheduledExecutorService scheduledExecutorService, zzbrn com_google_android_gms_internal_zzbrn, long j, long j2, double d, double d2) {
        this.zzcdt = new Random();
        this.zzcdw = true;
        this.zzcav = scheduledExecutorService;
        this.zzcaH = com_google_android_gms_internal_zzbrn;
        this.zzcdp = j;
        this.zzcdq = j2;
        this.zzcds = d;
        this.zzcdr = d2;
    }

    public void cancel() {
        if (this.zzcdu != null) {
            this.zzcaH.zzi("Cancelling existing retry attempt", new Object[0]);
            this.zzcdu.cancel(false);
            this.zzcdu = null;
        } else {
            this.zzcaH.zzi("No existing retry attempt to cancel", new Object[0]);
        }
        this.zzcdv = 0;
    }

    public void zzVW() {
        this.zzcdw = true;
        this.zzcdv = 0;
    }

    public void zzYj() {
        this.zzcdv = this.zzcdq;
    }

    public void zzr(final Runnable runnable) {
        long j = 0;
        Runnable c02881 = new Runnable(this) {
            final /* synthetic */ zzbou zzcdx;

            public void run() {
                this.zzcdx.zzcdu = null;
                runnable.run();
            }
        };
        if (this.zzcdu != null) {
            this.zzcaH.zzi("Cancelling previous scheduled retry", new Object[0]);
            this.zzcdu.cancel(false);
            this.zzcdu = null;
        }
        if (!this.zzcdw) {
            if (this.zzcdv == 0) {
                this.zzcdv = this.zzcdp;
            } else {
                this.zzcdv = Math.min((long) (((double) this.zzcdv) * this.zzcds), this.zzcdq);
            }
            j = (long) (((1.0d - this.zzcdr) * ((double) this.zzcdv)) + ((this.zzcdr * ((double) this.zzcdv)) * this.zzcdt.nextDouble()));
        }
        this.zzcdw = false;
        this.zzcaH.zzi("Scheduling retry in %dms", Long.valueOf(j));
        this.zzcdu = this.zzcav.schedule(c02881, j, TimeUnit.MILLISECONDS);
    }
}
