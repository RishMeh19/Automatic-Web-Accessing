package com.google.android.gms.internal;

import android.support.v4.internal.view.SupportMenu;
import android.support.v4.media.TransportMediator;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

class zzbss {
    private final Random zzcdt = new Random();
    private final Thread zzcjY = zzbsm.getThreadFactory().newThread(new C03221(this));
    private zzbsm zzckp;
    private volatile boolean zzcks = false;
    private BlockingQueue<ByteBuffer> zzckt;
    private boolean zzcku = false;
    private WritableByteChannel zzckv;

    class C03221 implements Runnable {
        final /* synthetic */ zzbss zzckw;

        C03221(zzbss com_google_android_gms_internal_zzbss) {
            this.zzckw = com_google_android_gms_internal_zzbss;
        }

        public void run() {
            this.zzckw.zzabG();
        }
    }

    zzbss(zzbsm com_google_android_gms_internal_zzbsm, String str, int i) {
        zzbsm.zzabs().zza(zzabz(), new StringBuilder(String.valueOf(str).length() + 18).append(str).append("Writer-").append(i).toString());
        this.zzckp = com_google_android_gms_internal_zzbsm;
        this.zzckt = new LinkedBlockingQueue();
    }

    private ByteBuffer zza(byte b, boolean z, byte[] bArr) throws IOException {
        int i = 2;
        if (z) {
            i = 6;
        }
        int length = bArr.length;
        if (length >= TransportMediator.KEYCODE_MEDIA_PLAY) {
            i = length <= SupportMenu.USER_MASK ? i + 2 : i + 8;
        }
        ByteBuffer allocate = ByteBuffer.allocate(i + bArr.length);
        allocate.put((byte) (b | -128));
        if (length < TransportMediator.KEYCODE_MEDIA_PLAY) {
            allocate.put((byte) (z ? length | 128 : length));
        } else if (length <= SupportMenu.USER_MASK) {
            allocate.put((byte) (z ? 254 : TransportMediator.KEYCODE_MEDIA_PLAY));
            allocate.putShort((short) length);
        } else {
            i = TransportMediator.KEYCODE_MEDIA_PAUSE;
            if (z) {
                i = 255;
            }
            allocate.put((byte) i);
            allocate.putInt(0);
            allocate.putInt(length);
        }
        if (z) {
            byte[] zzabD = zzabD();
            allocate.put(zzabD);
            for (i = 0; i < bArr.length; i++) {
                allocate.put((byte) (bArr[i] ^ zzabD[i % 4]));
            }
        }
        allocate.flip();
        return allocate;
    }

    private byte[] zzabD() {
        byte[] bArr = new byte[4];
        this.zzcdt.nextBytes(bArr);
        return bArr;
    }

    private void zzabE() throws InterruptedException, IOException {
        this.zzckv.write((ByteBuffer) this.zzckt.take());
    }

    private void zzabG() {
        while (!this.zzcks && !Thread.interrupted()) {
            try {
                zzabE();
            } catch (Throwable e) {
                zzc(new zzbso("IO Exception", e));
                return;
            } catch (InterruptedException e2) {
                return;
            }
        }
        for (int i = 0; i < this.zzckt.size(); i++) {
            zzabE();
        }
    }

    private void zzc(zzbso com_google_android_gms_internal_zzbso) {
        this.zzckp.zzb(com_google_android_gms_internal_zzbso);
    }

    void zzabF() {
        this.zzcks = true;
    }

    Thread zzabz() {
        return this.zzcjY;
    }

    synchronized void zzb(byte b, boolean z, byte[] bArr) throws IOException {
        ByteBuffer zza = zza(b, z, bArr);
        if (!this.zzcks || (!this.zzcku && b == (byte) 8)) {
            if (b == (byte) 8) {
                this.zzcku = true;
            }
            this.zzckt.add(zza);
        } else {
            throw new zzbso("Shouldn't be sending");
        }
    }

    void zzb(OutputStream outputStream) {
        this.zzckv = Channels.newChannel(outputStream);
    }
}
