package com.google.android.gms.internal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class zzbwq extends zzbvs<Object> {
    public static final zzbvt zzcsz = new C05611();
    private final zzbva zzcrv;

    static class C05611 implements zzbvt {
        C05611() {
        }

        public <T> zzbvs<T> zza(zzbva com_google_android_gms_internal_zzbva, zzbww<T> com_google_android_gms_internal_zzbww_T) {
            return com_google_android_gms_internal_zzbww_T.zzaey() == Object.class ? new zzbwq(com_google_android_gms_internal_zzbva) : null;
        }
    }

    private zzbwq(zzbva com_google_android_gms_internal_zzbva) {
        this.zzcrv = com_google_android_gms_internal_zzbva;
    }

    public void zza(zzbwz com_google_android_gms_internal_zzbwz, Object obj) throws IOException {
        if (obj == null) {
            com_google_android_gms_internal_zzbwz.zzaex();
            return;
        }
        zzbvs zzj = this.zzcrv.zzj(obj.getClass());
        if (zzj instanceof zzbwq) {
            com_google_android_gms_internal_zzbwz.zzaev();
            com_google_android_gms_internal_zzbwz.zzaew();
            return;
        }
        zzj.zza(com_google_android_gms_internal_zzbwz, obj);
    }

    public Object zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
        switch (com_google_android_gms_internal_zzbwx.zzaen()) {
            case BEGIN_ARRAY:
                List arrayList = new ArrayList();
                com_google_android_gms_internal_zzbwx.beginArray();
                while (com_google_android_gms_internal_zzbwx.hasNext()) {
                    arrayList.add(zzb(com_google_android_gms_internal_zzbwx));
                }
                com_google_android_gms_internal_zzbwx.endArray();
                return arrayList;
            case BEGIN_OBJECT:
                Map com_google_android_gms_internal_zzbwe = new zzbwe();
                com_google_android_gms_internal_zzbwx.beginObject();
                while (com_google_android_gms_internal_zzbwx.hasNext()) {
                    com_google_android_gms_internal_zzbwe.put(com_google_android_gms_internal_zzbwx.nextName(), zzb(com_google_android_gms_internal_zzbwx));
                }
                com_google_android_gms_internal_zzbwx.endObject();
                return com_google_android_gms_internal_zzbwe;
            case STRING:
                return com_google_android_gms_internal_zzbwx.nextString();
            case NUMBER:
                return Double.valueOf(com_google_android_gms_internal_zzbwx.nextDouble());
            case BOOLEAN:
                return Boolean.valueOf(com_google_android_gms_internal_zzbwx.nextBoolean());
            case NULL:
                com_google_android_gms_internal_zzbwx.nextNull();
                return null;
            default:
                throw new IllegalStateException();
        }
    }
}
