package com.google.android.gms.internal;

import java.util.List;

public class zzbor {
    private final List<String> zzccG;
    private final List<String> zzccH;
    private final Object zzccI;

    public zzbor(List<String> list, List<String> list2, Object obj) {
        this.zzccG = list;
        this.zzccH = list2;
        this.zzccI = obj;
    }

    public List<String> zzXY() {
        return this.zzccG;
    }

    public List<String> zzXZ() {
        return this.zzccH;
    }

    public Object zzYa() {
        return this.zzccI;
    }
}
