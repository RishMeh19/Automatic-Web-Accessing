package com.google.android.gms.internal;

public interface zzbpd {
    void zzd(zzbpc com_google_android_gms_internal_zzbpc);
}
