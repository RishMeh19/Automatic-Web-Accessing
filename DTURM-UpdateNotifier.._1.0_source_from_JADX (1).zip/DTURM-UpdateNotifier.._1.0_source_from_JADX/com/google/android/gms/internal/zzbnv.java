package com.google.android.gms.internal;

import android.content.Context;
import android.os.Build.VERSION;
import android.os.Handler;
import android.util.Log;
import com.google.android.gms.internal.zzbop.zza;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseApp.zzb;
import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.connection.idl.zzc;
import com.google.firebase.database.connection.idl.zze;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ScheduledExecutorService;

public class zzbnv implements zzbpi {
    private final Set<String> zzcaB = new HashSet();
    private final FirebaseApp zzcaw;
    private final Context zzqo;

    public zzbnv(FirebaseApp firebaseApp) {
        this.zzcaw = firebaseApp;
        if (this.zzcaw == null) {
            Log.e("FirebaseDatabase", "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            Log.e("FirebaseDatabase", "ERROR: You must call FirebaseApp.initializeApp() before using Firebase Database.");
            Log.e("FirebaseDatabase", "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            throw new RuntimeException("You need to call FirebaseApp.initializeApp() before using Firebase Database.");
        }
        this.zzqo = this.zzcaw.getApplicationContext();
    }

    public zzbop zza(zzbpa com_google_android_gms_internal_zzbpa, zzbol com_google_android_gms_internal_zzbol, zzbon com_google_android_gms_internal_zzbon, zza com_google_android_gms_internal_zzbop_zza) {
        final zzbop zza = zze.zza(this.zzqo, new zzc(com_google_android_gms_internal_zzbon, com_google_android_gms_internal_zzbpa.zzYg(), null, com_google_android_gms_internal_zzbpa.zzXw(), FirebaseDatabase.getSdkVersion(), com_google_android_gms_internal_zzbpa.zzkn()), com_google_android_gms_internal_zzbol, com_google_android_gms_internal_zzbop_zza);
        this.zzcaw.zza(new zzb(this) {
            public void zzas(boolean z) {
                if (z) {
                    zza.interrupt("app_in_background");
                } else {
                    zza.resume("app_in_background");
                }
            }
        });
        return zza;
    }

    public zzbow zza(ScheduledExecutorService scheduledExecutorService) {
        return new zzbnt(this.zzcaw, scheduledExecutorService);
    }

    public zzbpe zza(zzbpa com_google_android_gms_internal_zzbpa) {
        return new zzbnu();
    }

    public zzbql zza(zzbpa com_google_android_gms_internal_zzbpa, String str) {
        String zzYE = com_google_android_gms_internal_zzbpa.zzYE();
        String stringBuilder = new StringBuilder((String.valueOf(str).length() + 1) + String.valueOf(zzYE).length()).append(str).append("_").append(zzYE).toString();
        if (this.zzcaB.contains(stringBuilder)) {
            throw new DatabaseException(new StringBuilder(String.valueOf(zzYE).length() + 47).append("SessionPersistenceKey '").append(zzYE).append("' has already been used.").toString());
        }
        this.zzcaB.add(stringBuilder);
        return new zzbqi(com_google_android_gms_internal_zzbpa, new zzbnw(this.zzqo, com_google_android_gms_internal_zzbpa, stringBuilder), new zzbqj(com_google_android_gms_internal_zzbpa.zzYB()));
    }

    public zzbro zza(zzbpa com_google_android_gms_internal_zzbpa, zzbro.zza com_google_android_gms_internal_zzbro_zza, List<String> list) {
        return new zzbrl(com_google_android_gms_internal_zzbro_zza, list);
    }

    public zzbpm zzb(zzbpa com_google_android_gms_internal_zzbpa) {
        final zzbrn zziV = com_google_android_gms_internal_zzbpa.zziV("RunLoop");
        return new zzbsy(this) {
            final /* synthetic */ zzbnv zzcaD;

            public void zzj(final Throwable th) {
                final String zzl = zzbsy.zzl(th);
                zziV.zzd(zzl, th);
                new Handler(this.zzcaD.zzqo.getMainLooper()).post(new Runnable(this) {
                    public void run() {
                        throw new RuntimeException(zzl, th);
                    }
                });
                zzXv().shutdownNow();
            }
        };
    }

    public String zzc(zzbpa com_google_android_gms_internal_zzbpa) {
        return VERSION.SDK_INT + "/Android";
    }
}
