package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.zzaa;

public class zztv extends zza {
    public static final Creator<zztv> CREATOR = new zztw();
    public final int id;
    final Bundle zzahq;

    zztv(int i, Bundle bundle) {
        this.id = i;
        this.zzahq = bundle;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof zztv)) {
            return false;
        }
        zztv com_google_android_gms_internal_zztv = (zztv) obj;
        return zzaa.equal(Integer.valueOf(com_google_android_gms_internal_zztv.id), Integer.valueOf(this.id)) && zzaa.equal(com_google_android_gms_internal_zztv.zzahq, this.zzahq);
    }

    public int hashCode() {
        return zzaa.hashCode(Integer.valueOf(this.id), this.zzahq);
    }

    public void writeToParcel(Parcel parcel, int i) {
        zztw.zza(this, parcel, i);
    }
}
