package com.google.android.gms.internal;

import android.content.Context;
import android.net.Uri;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import com.google.android.gms.dynamic.zzd;
import com.google.android.gms.dynamite.DynamiteModule;
import com.google.android.gms.internal.zzbus.zza;
import com.google.firebase.FirebaseApp;
import org.json.JSONObject;

public class zzbut {
    private static final Object zzcqD = new Object();
    static volatile zzbut zzcqE;
    private Context mContext;
    private FirebaseApp zzclm;
    private zzbus zzcqF;

    protected zzbut(@NonNull FirebaseApp firebaseApp) throws RemoteException {
        this.mContext = firebaseApp.getApplicationContext();
        this.zzclm = firebaseApp;
        try {
            this.zzcqF = zza.zzfT(DynamiteModule.zza(this.mContext, DynamiteModule.zzaRU, "com.google.android.gms.firebasestorage").zzdT("com.google.firebase.storage.network.NetworkRequestFactoryImpl"));
            if (this.zzcqF == null) {
                Log.e("NetworkRqFactoryProxy", "Unable to load Firebase Storage Network layer.");
                throw new RemoteException();
            }
        } catch (Throwable e) {
            Log.e("NetworkRqFactoryProxy", "NetworkRequestFactoryProxy failed with a RemoteException:", e);
            throw new RemoteException();
        }
    }

    private zzbuu zzf(zzbuu com_google_android_gms_internal_zzbuu) {
        com_google_android_gms_internal_zzbuu.zzaD("x-firebase-gmpid", this.zzclm.getOptions().getApplicationId());
        return com_google_android_gms_internal_zzbuu;
    }

    public static zzbut zzj(@NonNull FirebaseApp firebaseApp) throws RemoteException {
        if (zzcqE == null) {
            synchronized (zzcqD) {
                if (zzcqE == null) {
                    zzcqE = new zzbut(firebaseApp);
                }
            }
        }
        return zzcqE;
    }

    @Nullable
    public String zzA(Uri uri) {
        try {
            return this.zzcqF.zzA(uri);
        } catch (Throwable e) {
            Log.e("NetworkRqFactoryProxy", "getDefaultURL failed with a RemoteException:", e);
            return null;
        }
    }

    @NonNull
    public zzbuu zzC(Uri uri) throws RemoteException {
        return zzf(new zzbuu(this.zzcqF.zza(uri, zzd.zzA(this.mContext))));
    }

    @NonNull
    public zzbuu zzD(Uri uri) throws RemoteException {
        return zzf(new zzbuu(this.zzcqF.zzb(uri, zzd.zzA(this.mContext))));
    }

    @NonNull
    public zzbuu zza(Uri uri, long j) throws RemoteException {
        return zzf(new zzbuu(this.zzcqF.zza(uri, zzd.zzA(this.mContext), j)));
    }

    @Nullable
    public zzbuu zza(Uri uri, String str) throws RemoteException {
        return zzf(new zzbuu(this.zzcqF.zzb(uri, zzd.zzA(this.mContext), str)));
    }

    @NonNull
    public zzbuu zza(Uri uri, String str, byte[] bArr, long j, int i, boolean z) throws RemoteException {
        return zzf(new zzbuu(this.zzcqF.zza(uri, zzd.zzA(this.mContext), str, zzd.zzA(bArr), j, i, z)));
    }

    @NonNull
    public zzbuu zza(Uri uri, JSONObject jSONObject) throws RemoteException {
        return zzf(new zzbuu(this.zzcqF.zza(uri, zzd.zzA(this.mContext), zzd.zzA(jSONObject))));
    }

    @NonNull
    public zzbuu zza(Uri uri, JSONObject jSONObject, String str) throws RemoteException {
        return zzf(new zzbuu(this.zzcqF.zza(uri, zzd.zzA(this.mContext), zzd.zzA(jSONObject), str)));
    }

    @Nullable
    public String zzadM() {
        try {
            return this.zzcqF.zzadM();
        } catch (Throwable e) {
            Log.e("NetworkRqFactoryProxy", "getBackendAuthority failed with a RemoteException:", e);
            return null;
        }
    }

    @NonNull
    public zzbuu zzb(Uri uri, String str) throws RemoteException {
        return zzf(new zzbuu(this.zzcqF.zzc(uri, zzd.zzA(this.mContext), str)));
    }
}
