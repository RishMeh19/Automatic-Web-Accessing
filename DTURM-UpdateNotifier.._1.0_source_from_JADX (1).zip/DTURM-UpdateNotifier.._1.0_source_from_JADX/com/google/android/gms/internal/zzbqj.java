package com.google.android.gms.internal;

public class zzbqj implements zzbqh {
    public final long zzchf;

    public zzbqj(long j) {
        this.zzchf = j;
    }

    public float zzZH() {
        return 0.2f;
    }

    public long zzZI() {
        return 1000;
    }

    public boolean zzaR(long j) {
        return j > 1000;
    }

    public boolean zzk(long j, long j2) {
        return j > this.zzchf || j2 > 1000;
    }
}
