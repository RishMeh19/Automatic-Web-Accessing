package com.google.android.gms.internal;

import java.io.IOException;
import java.io.Writer;

public final class zzbwh {

    private static final class zza extends Writer {
        private final Appendable zzcss;
        private final zza zzcst;

        static class zza implements CharSequence {
            char[] zzcsu;

            zza() {
            }

            public char charAt(int i) {
                return this.zzcsu[i];
            }

            public int length() {
                return this.zzcsu.length;
            }

            public CharSequence subSequence(int i, int i2) {
                return new String(this.zzcsu, i, i2 - i);
            }
        }

        private zza(Appendable appendable) {
            this.zzcst = new zza();
            this.zzcss = appendable;
        }

        public void close() {
        }

        public void flush() {
        }

        public void write(int i) throws IOException {
            this.zzcss.append((char) i);
        }

        public void write(char[] cArr, int i, int i2) throws IOException {
            this.zzcst.zzcsu = cArr;
            this.zzcss.append(this.zzcst, i, i + i2);
        }
    }

    public static Writer zza(Appendable appendable) {
        return appendable instanceof Writer ? (Writer) appendable : new zza(appendable);
    }

    public static void zzb(zzbvg com_google_android_gms_internal_zzbvg, zzbwz com_google_android_gms_internal_zzbwz) throws IOException {
        zzbwv.zzctR.zza(com_google_android_gms_internal_zzbwz, com_google_android_gms_internal_zzbvg);
    }

    public static zzbvg zzh(zzbwx com_google_android_gms_internal_zzbwx) throws zzbvk {
        Object obj = 1;
        try {
            com_google_android_gms_internal_zzbwx.zzaen();
            obj = null;
            return (zzbvg) zzbwv.zzctR.zzb(com_google_android_gms_internal_zzbwx);
        } catch (Throwable e) {
            if (obj != null) {
                return zzbvi.zzcrn;
            }
            throw new zzbvp(e);
        } catch (Throwable e2) {
            throw new zzbvp(e2);
        } catch (Throwable e22) {
            throw new zzbvh(e22);
        } catch (Throwable e222) {
            throw new zzbvp(e222);
        }
    }
}
