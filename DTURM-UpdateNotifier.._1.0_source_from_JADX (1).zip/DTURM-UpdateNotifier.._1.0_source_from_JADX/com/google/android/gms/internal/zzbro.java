package com.google.android.gms.internal;

public interface zzbro {

    public enum zza {
        DEBUG,
        INFO,
        WARN,
        ERROR,
        NONE
    }

    zza zzYg();

    void zzb(zza com_google_android_gms_internal_zzbro_zza, String str, String str2, long j);
}
