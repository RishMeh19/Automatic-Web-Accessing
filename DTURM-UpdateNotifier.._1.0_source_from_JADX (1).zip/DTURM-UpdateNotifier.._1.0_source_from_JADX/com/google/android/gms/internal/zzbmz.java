package com.google.android.gms.internal;

import android.support.annotation.NonNull;
import com.google.firebase.auth.FirebaseUser;

public interface zzbmz {
    void zza(@NonNull zzbmn com_google_android_gms_internal_zzbmn, @NonNull FirebaseUser firebaseUser);
}
