package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;

public class zzbrs {
    private final List<zzbph> zzcbr;
    private final List<String> zzcbs;

    static class zza {
        private StringBuilder zzcjd = null;
        private Stack<zzbrq> zzcje = new Stack();
        private int zzcjf = -1;
        private int zzcjg;
        private boolean zzcjh = true;
        private final List<zzbph> zzcji = new ArrayList();
        private final List<String> zzcjj = new ArrayList();
        private final zzc zzcjk;

        public zza(zzc com_google_android_gms_internal_zzbrs_zzc) {
            this.zzcjk = com_google_android_gms_internal_zzbrs_zzc;
        }

        private void zza(StringBuilder stringBuilder, zzbrq com_google_android_gms_internal_zzbrq) {
            stringBuilder.append(zzbte.zzji(com_google_android_gms_internal_zzbrq.asString()));
        }

        private void zzaaX() {
            if (!zzaaU()) {
                this.zzcjd = new StringBuilder();
                this.zzcjd.append("(");
                Iterator it = zzqD(this.zzcjg).iterator();
                while (it.hasNext()) {
                    zza(this.zzcjd, (zzbrq) it.next());
                    this.zzcjd.append(":(");
                }
                this.zzcjh = false;
            }
        }

        private void zzaaY() {
            this.zzcjg--;
            if (zzaaU()) {
                this.zzcjd.append(")");
            }
            this.zzcjh = true;
        }

        private void zzaaZ() {
            zzbte.zzb(this.zzcjg == 0, "Can't finish hashing in the middle processing a child");
            if (zzaaU()) {
                zzaba();
            }
            this.zzcjj.add("");
        }

        private void zzaba() {
            zzbte.zzb(zzaaU(), "Can't end range without starting a range!");
            for (int i = 0; i < this.zzcjg; i++) {
                this.zzcjd.append(")");
            }
            this.zzcjd.append(")");
            zzbph zzqD = zzqD(this.zzcjf);
            this.zzcjj.add(zzbte.zzjh(this.zzcjd.toString()));
            this.zzcji.add(zzqD);
            this.zzcjd = null;
        }

        private void zzb(zzbrz<?> com_google_android_gms_internal_zzbrz_) {
            zzaaX();
            this.zzcjf = this.zzcjg;
            this.zzcjd.append(com_google_android_gms_internal_zzbrz_.zza(com.google.android.gms.internal.zzbsc.zza.V2));
            this.zzcjh = true;
            if (this.zzcjk.zze(this)) {
                zzaba();
            }
        }

        private void zzn(zzbrq com_google_android_gms_internal_zzbrq) {
            zzaaX();
            if (this.zzcjh) {
                this.zzcjd.append(",");
            }
            zza(this.zzcjd, com_google_android_gms_internal_zzbrq);
            this.zzcjd.append(":(");
            if (this.zzcjg == this.zzcje.size()) {
                this.zzcje.add(com_google_android_gms_internal_zzbrq);
            } else {
                this.zzcje.set(this.zzcjg, com_google_android_gms_internal_zzbrq);
            }
            this.zzcjg++;
            this.zzcjh = false;
        }

        private zzbph zzqD(int i) {
            zzbrq[] com_google_android_gms_internal_zzbrqArr = new zzbrq[i];
            for (int i2 = 0; i2 < i; i2++) {
                com_google_android_gms_internal_zzbrqArr[i2] = (zzbrq) this.zzcje.get(i2);
            }
            return new zzbph(com_google_android_gms_internal_zzbrqArr);
        }

        public boolean zzaaU() {
            return this.zzcjd != null;
        }

        public int zzaaV() {
            return this.zzcjd.length();
        }

        public zzbph zzaaW() {
            return zzqD(this.zzcjg);
        }
    }

    public interface zzc {
        boolean zze(zza com_google_android_gms_internal_zzbrs_zza);
    }

    private static class zzb implements zzc {
        private final long zzcjl;

        public zzb(zzbsc com_google_android_gms_internal_zzbsc) {
            this.zzcjl = Math.max(512, (long) Math.sqrt((double) (zzbsz.zzt(com_google_android_gms_internal_zzbsc) * 100)));
        }

        public boolean zze(zza com_google_android_gms_internal_zzbrs_zza) {
            return ((long) com_google_android_gms_internal_zzbrs_zza.zzaaV()) > this.zzcjl && (com_google_android_gms_internal_zzbrs_zza.zzaaW().isEmpty() || !com_google_android_gms_internal_zzbrs_zza.zzaaW().zzYX().equals(zzbrq.zzaaK()));
        }
    }

    class C06371 extends com.google.android.gms.internal.zzbrr.zza {
        final /* synthetic */ zza zzcjc;

        C06371(zza com_google_android_gms_internal_zzbrs_zza) {
            this.zzcjc = com_google_android_gms_internal_zzbrs_zza;
        }

        public void zzb(zzbrq com_google_android_gms_internal_zzbrq, zzbsc com_google_android_gms_internal_zzbsc) {
            this.zzcjc.zzn(com_google_android_gms_internal_zzbrq);
            zzbrs.zza(com_google_android_gms_internal_zzbsc, this.zzcjc);
            this.zzcjc.zzaaY();
        }
    }

    private zzbrs(List<zzbph> list, List<String> list2) {
        if (list.size() != list2.size() - 1) {
            throw new IllegalArgumentException("Number of posts need to be n-1 for n hashes in CompoundHash");
        }
        this.zzcbr = list;
        this.zzcbs = list2;
    }

    public static zzbrs zza(zzbsc com_google_android_gms_internal_zzbsc, zzc com_google_android_gms_internal_zzbrs_zzc) {
        if (com_google_android_gms_internal_zzbsc.isEmpty()) {
            return new zzbrs(Collections.emptyList(), Collections.singletonList(""));
        }
        zza com_google_android_gms_internal_zzbrs_zza = new zza(com_google_android_gms_internal_zzbrs_zzc);
        zza(com_google_android_gms_internal_zzbsc, com_google_android_gms_internal_zzbrs_zza);
        com_google_android_gms_internal_zzbrs_zza.zzaaZ();
        return new zzbrs(com_google_android_gms_internal_zzbrs_zza.zzcji, com_google_android_gms_internal_zzbrs_zza.zzcjj);
    }

    private static void zza(zzbsc com_google_android_gms_internal_zzbsc, zza com_google_android_gms_internal_zzbrs_zza) {
        if (com_google_android_gms_internal_zzbsc.zzaaP()) {
            com_google_android_gms_internal_zzbrs_zza.zzb((zzbrz) com_google_android_gms_internal_zzbsc);
        } else if (com_google_android_gms_internal_zzbsc.isEmpty()) {
            throw new IllegalArgumentException("Can't calculate hash on empty node!");
        } else if (com_google_android_gms_internal_zzbsc instanceof zzbrr) {
            ((zzbrr) com_google_android_gms_internal_zzbsc).zza(new C06371(com_google_android_gms_internal_zzbrs_zza), true);
        } else {
            String valueOf = String.valueOf(com_google_android_gms_internal_zzbsc);
            throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 33).append("Expected children node, but got: ").append(valueOf).toString());
        }
    }

    public static zzbrs zzi(zzbsc com_google_android_gms_internal_zzbsc) {
        return zza(com_google_android_gms_internal_zzbsc, new zzb(com_google_android_gms_internal_zzbsc));
    }

    public List<zzbph> zzXr() {
        return Collections.unmodifiableList(this.zzcbr);
    }

    public List<String> zzXs() {
        return Collections.unmodifiableList(this.zzcbs);
    }
}
