package com.google.android.gms.internal;

public class zzbpk {
    public String host;
    public boolean secure;
    public String zzaGP;
    public String zzcfu;

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        zzbpk com_google_android_gms_internal_zzbpk = (zzbpk) obj;
        return (this.secure == com_google_android_gms_internal_zzbpk.secure && this.host.equals(com_google_android_gms_internal_zzbpk.host)) ? this.zzaGP.equals(com_google_android_gms_internal_zzbpk.zzaGP) : false;
    }

    public int hashCode() {
        return (((this.secure ? 1 : 0) + (this.host.hashCode() * 31)) * 31) + this.zzaGP.hashCode();
    }

    public String toString() {
        String str = this.secure ? "s" : "";
        String str2 = this.host;
        return new StringBuilder((String.valueOf(str).length() + 7) + String.valueOf(str2).length()).append("http").append(str).append("://").append(str2).toString();
    }
}
