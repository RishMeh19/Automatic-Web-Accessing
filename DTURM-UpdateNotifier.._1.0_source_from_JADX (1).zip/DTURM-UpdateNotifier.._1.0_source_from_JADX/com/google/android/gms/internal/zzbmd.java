package com.google.android.gms.internal;

import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzac;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseUser;

abstract class zzbmd<SuccessT, CallbackT> {
    private boolean zzbNI;
    protected FirebaseApp zzbXI;
    protected final int zzbYk;
    protected final zza zzbYl = new zza();
    protected FirebaseUser zzbYm;
    protected zzblz zzbYn;
    protected CallbackT zzbYo;
    protected zzbmc<SuccessT> zzbYp;
    protected zzbmn zzbYq;
    protected zzbmj zzbYr;
    protected zzbmh zzbYs;
    protected zzbmt zzbYt;
    protected String zzbYu;
    boolean zzbYv;
    SuccessT zzbYw;
    Status zzbYx;

    private class zza extends com.google.android.gms.internal.zzbly.zza {
        final /* synthetic */ zzbmd zzbYy;

        private zza(zzbmd com_google_android_gms_internal_zzbmd) {
            this.zzbYy = com_google_android_gms_internal_zzbmd;
        }

        public void onFailure(@NonNull Status status) throws RemoteException {
            this.zzbYy.zzcf(status);
        }

        public void zzVT() throws RemoteException {
            zzac.zza(this.zzbYy.zzbYk == 5, "Unexpected response type " + this.zzbYy.zzbYk);
            this.zzbYy.zzVX();
        }

        public void zzVU() throws RemoteException {
            zzac.zza(this.zzbYy.zzbYk == 6, "Unexpected response type " + this.zzbYy.zzbYk);
            this.zzbYy.zzVX();
        }

        public void zza(@NonNull zzbmh com_google_android_gms_internal_zzbmh) throws RemoteException {
            zzac.zza(this.zzbYy.zzbYk == 3, "Unexpected response type " + this.zzbYy.zzbYk);
            this.zzbYy.zzbYs = com_google_android_gms_internal_zzbmh;
            this.zzbYy.zzVX();
        }

        public void zza(@NonNull zzbmn com_google_android_gms_internal_zzbmn, @NonNull zzbmj com_google_android_gms_internal_zzbmj) throws RemoteException {
            zzac.zza(this.zzbYy.zzbYk == 2, "Unexpected response type: " + this.zzbYy.zzbYk);
            this.zzbYy.zzbYq = com_google_android_gms_internal_zzbmn;
            this.zzbYy.zzbYr = com_google_android_gms_internal_zzbmj;
            this.zzbYy.zzVX();
        }

        public void zza(@Nullable zzbmt com_google_android_gms_internal_zzbmt) throws RemoteException {
            zzac.zza(this.zzbYy.zzbYk == 4, "Unexpected response type " + this.zzbYy.zzbYk);
            this.zzbYy.zzbYt = com_google_android_gms_internal_zzbmt;
            this.zzbYy.zzVX();
        }

        public void zzb(@NonNull zzbmn com_google_android_gms_internal_zzbmn) throws RemoteException {
            boolean z = true;
            if (this.zzbYy.zzbYk != 1) {
                z = false;
            }
            zzac.zza(z, "Unexpected response type: " + this.zzbYy.zzbYk);
            this.zzbYy.zzbYq = com_google_android_gms_internal_zzbmn;
            this.zzbYy.zzVX();
        }

        public void zzix(@NonNull String str) throws RemoteException {
            zzac.zza(this.zzbYy.zzbYk == 7, "Unexpected response type " + this.zzbYy.zzbYk);
            this.zzbYy.zzbYu = str;
            this.zzbYy.zzVX();
        }
    }

    public zzbmd(int i) {
        this.zzbYk = i;
    }

    private void zzVX() {
        zzVQ();
        zzac.zza(this.zzbNI, (Object) "no success or failure set on method implementation");
    }

    protected abstract void dispatch() throws RemoteException;

    public abstract void zzVQ();

    public void zzVW() {
        zzaf(null);
    }

    public zzbmd<SuccessT, CallbackT> zza(zzbmc<SuccessT> com_google_android_gms_internal_zzbmc_SuccessT) {
        this.zzbYp = com_google_android_gms_internal_zzbmc_SuccessT;
        return this;
    }

    public void zza(zzblz com_google_android_gms_internal_zzblz) throws RemoteException {
        this.zzbYn = com_google_android_gms_internal_zzblz;
        dispatch();
    }

    public zzbmd<SuccessT, CallbackT> zzae(CallbackT callbackT) {
        this.zzbYo = zzac.zzb((Object) callbackT, (Object) "external callback cannot be null");
        return this;
    }

    public void zzaf(SuccessT successT) {
        this.zzbNI = true;
        this.zzbYv = true;
        this.zzbYw = successT;
        this.zzbYp.zza(successT, null);
    }

    public void zzcf(Status status) {
        this.zzbNI = true;
        this.zzbYv = false;
        this.zzbYx = status;
        this.zzbYp.zza(null, status);
    }

    public zzbmd<SuccessT, CallbackT> zze(FirebaseApp firebaseApp) {
        this.zzbXI = (FirebaseApp) zzac.zzb((Object) firebaseApp, (Object) "firebaseApp cannot be null");
        return this;
    }

    public zzbmd<SuccessT, CallbackT> zze(FirebaseUser firebaseUser) {
        this.zzbYm = (FirebaseUser) zzac.zzb((Object) firebaseUser, (Object) "firebaseUser cannot be null");
        return this;
    }
}
