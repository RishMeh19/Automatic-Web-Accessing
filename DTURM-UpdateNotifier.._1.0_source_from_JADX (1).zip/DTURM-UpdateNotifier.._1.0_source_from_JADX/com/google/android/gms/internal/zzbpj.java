package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbpr.zzd;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.DatabaseReference.CompletionListener;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.Transaction.Handler;
import com.google.firebase.database.Transaction.Result;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class zzbpj implements com.google.android.gms.internal.zzbop.zza {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbpj.class.desiredAssertionStatus());
    private final zzbpk zzbZZ;
    private final zzbop zzcdg;
    private zzbpr zzceA;
    private FirebaseDatabase zzceB;
    private boolean zzceC = false;
    private long zzceD = 0;
    private final zzbta zzcen = new zzbta(new zzbsx(), 0);
    private zzbpo zzceo;
    private zzbpp zzcep;
    private zzbqs<List<zza>> zzceq;
    private boolean zzcer = false;
    private final zzbra zzces;
    private final zzbpa zzcet;
    private final zzbrn zzceu;
    private final zzbrn zzcev;
    private final zzbrn zzcew;
    public long zzcex = 0;
    private long zzcey = 1;
    private zzbpr zzcez;

    class C02931 implements Runnable {
        final /* synthetic */ zzbpj zzceE;

        C02931(zzbpj com_google_android_gms_internal_zzbpj) {
            this.zzceE = com_google_android_gms_internal_zzbpj;
        }

        public void run() {
            this.zzceE.zzYZ();
        }
    }

    private static class zza implements Comparable<zza> {
        private int retryCount;
        private zzbph zzcai;
        private Handler zzcfd;
        private ValueEventListener zzcfe;
        private zzb zzcff;
        private long zzcfg;
        private boolean zzcfh;
        private DatabaseError zzcfi;
        private long zzcfj;
        private zzbsc zzcfk;
        private zzbsc zzcfl;
        private zzbsc zzcfm;

        private zza(zzbph com_google_android_gms_internal_zzbph, Handler handler, ValueEventListener valueEventListener, zzb com_google_android_gms_internal_zzbpj_zzb, boolean z, long j) {
            this.zzcai = com_google_android_gms_internal_zzbph;
            this.zzcfd = handler;
            this.zzcfe = valueEventListener;
            this.zzcff = com_google_android_gms_internal_zzbpj_zzb;
            this.retryCount = 0;
            this.zzcfh = z;
            this.zzcfg = j;
            this.zzcfi = null;
            this.zzcfk = null;
            this.zzcfl = null;
            this.zzcfm = null;
        }

        public /* synthetic */ int compareTo(Object obj) {
            return zza((zza) obj);
        }

        public int zza(zza com_google_android_gms_internal_zzbpj_zza) {
            return this.zzcfg < com_google_android_gms_internal_zzbpj_zza.zzcfg ? -1 : this.zzcfg == com_google_android_gms_internal_zzbpj_zza.zzcfg ? 0 : 1;
        }
    }

    private enum zzb {
        INITIALIZING,
        RUN,
        SENT,
        COMPLETED,
        SENT_NEEDS_ABORT,
        NEEDS_ABORT
    }

    class C05085 implements ValueEventListener {
        C05085(zzbpj com_google_android_gms_internal_zzbpj) {
        }

        public void onCancelled(DatabaseError databaseError) {
        }

        public void onDataChange(DataSnapshot dataSnapshot) {
        }
    }

    class C05097 implements com.google.android.gms.internal.zzbqs.zzb<List<zza>> {
        final /* synthetic */ zzbpj zzceE;

        C05097(zzbpj com_google_android_gms_internal_zzbpj) {
            this.zzceE = com_google_android_gms_internal_zzbpj;
        }

        public void zzd(zzbqs<List<zza>> com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza) {
            this.zzceE.zza((zzbqs) com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza);
        }
    }

    class C05119 implements com.google.android.gms.internal.zzbqs.zzb<List<zza>> {
        final /* synthetic */ zzbpj zzceE;

        C05119(zzbpj com_google_android_gms_internal_zzbpj) {
            this.zzceE = com_google_android_gms_internal_zzbpj;
        }

        public void zzd(zzbqs<List<zza>> com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza) {
            this.zzceE.zzb((zzbqs) com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza);
        }
    }

    zzbpj(zzbpk com_google_android_gms_internal_zzbpk, zzbpa com_google_android_gms_internal_zzbpa, FirebaseDatabase firebaseDatabase) {
        this.zzbZZ = com_google_android_gms_internal_zzbpk;
        this.zzcet = com_google_android_gms_internal_zzbpa;
        this.zzceB = firebaseDatabase;
        this.zzceu = this.zzcet.zziV("RepoOperation");
        this.zzcev = this.zzcet.zziV("Transaction");
        this.zzcew = this.zzcet.zziV("DataOperation");
        this.zzces = new zzbra(this.zzcet);
        this.zzcdg = com_google_android_gms_internal_zzbpa.zza(new zzbon(com_google_android_gms_internal_zzbpk.host, com_google_android_gms_internal_zzbpk.zzaGP, com_google_android_gms_internal_zzbpk.secure), this);
        zzs(new C02931(this));
    }

    private void zzYZ() {
        this.zzcet.zzYF().zza(new com.google.android.gms.internal.zzbow.zzb(this) {
            final /* synthetic */ zzbpj zzceE;

            {
                this.zzceE = r1;
            }

            public void zziU(String str) {
                this.zzceE.zzceu.zzi("Auth token changed, triggering auth token refresh", new Object[0]);
                this.zzceE.zzcdg.zziN(str);
            }
        });
        this.zzcdg.initialize();
        zzbql zziW = this.zzcet.zziW(this.zzbZZ.host);
        this.zzceo = new zzbpo();
        this.zzcep = new zzbpp();
        this.zzceq = new zzbqs();
        this.zzcez = new zzbpr(this.zzcet, new zzbqk(), new zzd(this) {
            final /* synthetic */ zzbpj zzceE;

            {
                this.zzceE = r1;
            }

            public void zza(zzbrc com_google_android_gms_internal_zzbrc, zzbps com_google_android_gms_internal_zzbps) {
            }

            public void zza(final zzbrc com_google_android_gms_internal_zzbrc, zzbps com_google_android_gms_internal_zzbps, zzboo com_google_android_gms_internal_zzboo, final com.google.android.gms.internal.zzbpr.zza com_google_android_gms_internal_zzbpr_zza) {
                this.zzceE.zzs(new Runnable(this) {
                    final /* synthetic */ AnonymousClass17 zzceV;

                    public void run() {
                        zzbsc zzq = this.zzceV.zzceE.zzceo.zzq(com_google_android_gms_internal_zzbrc.zzWO());
                        if (!zzq.isEmpty()) {
                            this.zzceV.zzceE.zzZ(this.zzceV.zzceE.zzcez.zzi(com_google_android_gms_internal_zzbrc.zzWO(), zzq));
                            com_google_android_gms_internal_zzbpr_zza.zzb(null);
                        }
                    }
                });
            }
        });
        this.zzceA = new zzbpr(this.zzcet, zziW, new zzd(this) {
            final /* synthetic */ zzbpj zzceE;

            {
                this.zzceE = r1;
            }

            public void zza(zzbrc com_google_android_gms_internal_zzbrc, zzbps com_google_android_gms_internal_zzbps) {
                this.zzceE.zzcdg.zza(com_google_android_gms_internal_zzbrc.zzWO().zzYT(), com_google_android_gms_internal_zzbrc.zzaas().zzaao());
            }

            public void zza(zzbrc com_google_android_gms_internal_zzbrc, zzbps com_google_android_gms_internal_zzbps, zzboo com_google_android_gms_internal_zzboo, final com.google.android.gms.internal.zzbpr.zza com_google_android_gms_internal_zzbpr_zza) {
                this.zzceE.zzcdg.zza(com_google_android_gms_internal_zzbrc.zzWO().zzYT(), com_google_android_gms_internal_zzbrc.zzaas().zzaao(), com_google_android_gms_internal_zzboo, com_google_android_gms_internal_zzbps != null ? Long.valueOf(com_google_android_gms_internal_zzbps.zzZn()) : null, new zzbos(this) {
                    final /* synthetic */ AnonymousClass18 zzceX;

                    public void zzar(String str, String str2) {
                        this.zzceX.zzceE.zzZ(com_google_android_gms_internal_zzbpr_zza.zzb(zzbpj.zzas(str, str2)));
                    }
                });
            }
        });
        zza(zziW);
        zzb(zzboz.zzcdQ, Boolean.valueOf(false));
        zzb(zzboz.zzcdR, Boolean.valueOf(false));
    }

    private void zzZ(List<? extends zzbqy> list) {
        if (!list.isEmpty()) {
            this.zzces.zzab(list);
        }
    }

    private long zzZd() {
        long j = this.zzcey;
        this.zzcey = 1 + j;
        return j;
    }

    private void zzZe() {
        zzbpp zza = zzbpn.zza(this.zzcep, zzbpn.zza(this.zzcen));
        final List arrayList = new ArrayList();
        zza.zza(zzbph.zzYR(), new com.google.android.gms.internal.zzbpp.zzb(this) {
            final /* synthetic */ zzbpj zzceE;

            public void zzf(zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc) {
                arrayList.addAll(this.zzceE.zzceA.zzi(com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbsc));
                this.zzceE.zzo(this.zzceE.zzb(com_google_android_gms_internal_zzbph, -9));
            }
        });
        this.zzcep = new zzbpp();
        zzZ(arrayList);
    }

    private void zzZf() {
        zzbqs com_google_android_gms_internal_zzbqs = this.zzceq;
        zzb(com_google_android_gms_internal_zzbqs);
        zza(com_google_android_gms_internal_zzbqs);
    }

    private long zzZg() {
        long j = this.zzceD;
        this.zzceD = 1 + j;
        return j;
    }

    private zzbsc zza(zzbph com_google_android_gms_internal_zzbph, List<Long> list) {
        zzbsc zzc = this.zzceA.zzc(com_google_android_gms_internal_zzbph, list);
        return zzc == null ? zzbrv.zzabb() : zzc;
    }

    private void zza(long j, zzbph com_google_android_gms_internal_zzbph, DatabaseError databaseError) {
        if (databaseError == null || databaseError.getCode() != -25) {
            List zza = this.zzceA.zza(j, !(databaseError == null), true, this.zzcen);
            if (zza.size() > 0) {
                zzo(com_google_android_gms_internal_zzbph);
            }
            zzZ(zza);
        }
    }

    private void zza(zzbql com_google_android_gms_internal_zzbql) {
        List<zzbpv> zzWQ = com_google_android_gms_internal_zzbql.zzWQ();
        Map zza = zzbpn.zza(this.zzcen);
        long j = Long.MIN_VALUE;
        for (final zzbpv com_google_android_gms_internal_zzbpv : zzWQ) {
            zzbos anonymousClass19 = new zzbos(this) {
                final /* synthetic */ zzbpj zzceE;

                public void zzar(String str, String str2) {
                    DatabaseError zzat = zzbpj.zzas(str, str2);
                    this.zzceE.zza("Persisted write", com_google_android_gms_internal_zzbpv.zzWO(), zzat);
                    this.zzceE.zza(com_google_android_gms_internal_zzbpv.zzZo(), com_google_android_gms_internal_zzbpv.zzWO(), zzat);
                }
            };
            if (j >= com_google_android_gms_internal_zzbpv.zzZo()) {
                throw new IllegalStateException("Write ids were not in order.");
            }
            long zzZo = com_google_android_gms_internal_zzbpv.zzZo();
            this.zzcey = com_google_android_gms_internal_zzbpv.zzZo() + 1;
            if (com_google_android_gms_internal_zzbpv.zzZr()) {
                if (this.zzceu.zzaaF()) {
                    this.zzceu.zzi("Restoring overwrite with id " + com_google_android_gms_internal_zzbpv.zzZo(), new Object[0]);
                }
                this.zzcdg.zza(com_google_android_gms_internal_zzbpv.zzWO().zzYT(), com_google_android_gms_internal_zzbpv.zzZp().getValue(true), anonymousClass19);
                this.zzceA.zza(com_google_android_gms_internal_zzbpv.zzWO(), com_google_android_gms_internal_zzbpv.zzZp(), zzbpn.zza(com_google_android_gms_internal_zzbpv.zzZp(), zza), com_google_android_gms_internal_zzbpv.zzZo(), true, false);
            } else {
                if (this.zzceu.zzaaF()) {
                    this.zzceu.zzi("Restoring merge with id " + com_google_android_gms_internal_zzbpv.zzZo(), new Object[0]);
                }
                this.zzcdg.zza(com_google_android_gms_internal_zzbpv.zzWO().zzYT(), com_google_android_gms_internal_zzbpv.zzZq().zzbd(true), anonymousClass19);
                this.zzceA.zza(com_google_android_gms_internal_zzbpv.zzWO(), com_google_android_gms_internal_zzbpv.zzZq(), zzbpn.zza(com_google_android_gms_internal_zzbpv.zzZq(), zza), com_google_android_gms_internal_zzbpv.zzZo(), false);
            }
            j = zzZo;
        }
    }

    private void zza(zzbqs<List<zza>> com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza) {
        if (((List) com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza.getValue()) != null) {
            List<zza> zzc = zzc((zzbqs) com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza);
            if ($assertionsDisabled || zzc.size() > 0) {
                Boolean valueOf;
                Boolean valueOf2 = Boolean.valueOf(true);
                for (zza zzd : zzc) {
                    if (zzd.zzcff != zzb.RUN) {
                        valueOf = Boolean.valueOf(false);
                        break;
                    }
                }
                valueOf = valueOf2;
                if (valueOf.booleanValue()) {
                    zza((List) zzc, com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza.zzWO());
                    return;
                }
                return;
            }
            throw new AssertionError();
        } else if (com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza.hasChildren()) {
            com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza.zzb(new C05097(this));
        }
    }

    private void zza(zzbqs<List<zza>> com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza, int i) {
        List list = (List) com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza.getValue();
        List arrayList = new ArrayList();
        if (list != null) {
            DatabaseError zziD;
            List<Runnable> arrayList2 = new ArrayList();
            if (i == -9) {
                zziD = DatabaseError.zziD("overriddenBySet");
            } else {
                zzbte.zzb(i == -25, "Unknown transaction abort reason: " + i);
                zziD = DatabaseError.zzqv(-25);
            }
            int i2 = 0;
            int i3 = -1;
            while (i2 < list.size()) {
                int i4;
                final zza com_google_android_gms_internal_zzbpj_zza = (zza) list.get(i2);
                if (com_google_android_gms_internal_zzbpj_zza.zzcff == zzb.SENT_NEEDS_ABORT) {
                    i4 = i3;
                } else if (com_google_android_gms_internal_zzbpj_zza.zzcff == zzb.SENT) {
                    if ($assertionsDisabled || i3 == i2 - 1) {
                        com_google_android_gms_internal_zzbpj_zza.zzcff = zzb.SENT_NEEDS_ABORT;
                        com_google_android_gms_internal_zzbpj_zza.zzcfi = zziD;
                        i4 = i2;
                    } else {
                        throw new AssertionError();
                    }
                } else if ($assertionsDisabled || com_google_android_gms_internal_zzbpj_zza.zzcff == zzb.RUN) {
                    zze(new zzbpx(this, com_google_android_gms_internal_zzbpj_zza.zzcfe, zzbrc.zzN(com_google_android_gms_internal_zzbpj_zza.zzcai)));
                    if (i == -9) {
                        arrayList.addAll(this.zzceA.zza(com_google_android_gms_internal_zzbpj_zza.zzcfj, true, false, this.zzcen));
                    } else {
                        zzbte.zzb(i == -25, "Unknown transaction abort reason: " + i);
                    }
                    arrayList2.add(new Runnable(this) {
                        public void run() {
                            com_google_android_gms_internal_zzbpj_zza.zzcfd.onComplete(zziD, false, null);
                        }
                    });
                    i4 = i3;
                } else {
                    throw new AssertionError();
                }
                i2++;
                i3 = i4;
            }
            if (i3 == -1) {
                com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza.setValue(null);
            } else {
                com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza.setValue(list.subList(0, i3 + 1));
            }
            zzZ(arrayList);
            for (Runnable zzq : arrayList2) {
                zzq(zzq);
            }
        }
    }

    private void zza(String str, zzbph com_google_android_gms_internal_zzbph, DatabaseError databaseError) {
        if (databaseError != null && databaseError.getCode() != -1 && databaseError.getCode() != -25) {
            zzbrn com_google_android_gms_internal_zzbrn = this.zzceu;
            String valueOf = String.valueOf(com_google_android_gms_internal_zzbph.toString());
            String valueOf2 = String.valueOf(databaseError.toString());
            com_google_android_gms_internal_zzbrn.warn(new StringBuilder(((String.valueOf(str).length() + 13) + String.valueOf(valueOf).length()) + String.valueOf(valueOf2).length()).append(str).append(" at ").append(valueOf).append(" failed: ").append(valueOf2).toString());
        }
    }

    private void zza(final List<zza> list, final zzbph com_google_android_gms_internal_zzbph) {
        List arrayList = new ArrayList();
        for (zza zzc : list) {
            arrayList.add(Long.valueOf(zzc.zzcfj));
        }
        zzbsc zza = zza(com_google_android_gms_internal_zzbph, arrayList);
        String zzaaO = zza.zzaaO();
        zzbsc com_google_android_gms_internal_zzbsc = zza;
        for (zza zzc2 : list) {
            if ($assertionsDisabled || zzc2.zzcff == zzb.RUN) {
                zzc2.zzcff = zzb.SENT;
                zzc2.retryCount = zzc2.retryCount + 1;
                com_google_android_gms_internal_zzbsc = com_google_android_gms_internal_zzbsc.zzl(zzbph.zza(com_google_android_gms_internal_zzbph, zzc2.zzcai), zzc2.zzcfl);
            } else {
                throw new AssertionError();
            }
        }
        this.zzcdg.zza(com_google_android_gms_internal_zzbph.zzYT(), com_google_android_gms_internal_zzbsc.getValue(true), zzaaO, new zzbos(this) {
            final /* synthetic */ zzbpj zzceE;

            public void zzar(String str, String str2) {
                int i = 0;
                DatabaseError zzat = zzbpj.zzas(str, str2);
                this.zzceE.zza("Transaction", com_google_android_gms_internal_zzbph, zzat);
                List arrayList = new ArrayList();
                if (zzat == null) {
                    List arrayList2 = new ArrayList();
                    for (final zza com_google_android_gms_internal_zzbpj_zza : list) {
                        com_google_android_gms_internal_zzbpj_zza.zzcff = zzb.COMPLETED;
                        arrayList.addAll(this.zzceE.zzceA.zza(com_google_android_gms_internal_zzbpj_zza.zzcfj, false, false, this.zzceE.zzcen));
                        final DataSnapshot zza = com.google.firebase.database.zza.zza(com.google.firebase.database.zza.zza(this, com_google_android_gms_internal_zzbpj_zza.zzcai), zzbrx.zzn(com_google_android_gms_internal_zzbpj_zza.zzcfm));
                        arrayList2.add(new Runnable(this) {
                            public void run() {
                                com_google_android_gms_internal_zzbpj_zza.zzcfd.onComplete(null, true, zza);
                            }
                        });
                        this.zzceE.zze(new zzbpx(this.zzceE, com_google_android_gms_internal_zzbpj_zza.zzcfe, zzbrc.zzN(com_google_android_gms_internal_zzbpj_zza.zzcai)));
                    }
                    this.zzceE.zzb(this.zzceE.zzceq.zzL(com_google_android_gms_internal_zzbph));
                    this.zzceE.zzZf();
                    this.zzZ(arrayList);
                    while (i < arrayList2.size()) {
                        this.zzceE.zzq((Runnable) arrayList2.get(i));
                        i++;
                    }
                    return;
                }
                if (zzat.getCode() == -1) {
                    for (zza com_google_android_gms_internal_zzbpj_zza2 : list) {
                        if (com_google_android_gms_internal_zzbpj_zza2.zzcff == zzb.SENT_NEEDS_ABORT) {
                            com_google_android_gms_internal_zzbpj_zza2.zzcff = zzb.NEEDS_ABORT;
                        } else {
                            com_google_android_gms_internal_zzbpj_zza2.zzcff = zzb.RUN;
                        }
                    }
                } else {
                    for (zza com_google_android_gms_internal_zzbpj_zza22 : list) {
                        com_google_android_gms_internal_zzbpj_zza22.zzcff = zzb.NEEDS_ABORT;
                        com_google_android_gms_internal_zzbpj_zza22.zzcfi = zzat;
                    }
                }
                this.zzceE.zzo(com_google_android_gms_internal_zzbph);
            }
        });
    }

    private void zza(final List<zza> list, zzbqs<List<zza>> com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza) {
        List list2 = (List) com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza.getValue();
        if (list2 != null) {
            list.addAll(list2);
        }
        com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza.zzb(new com.google.android.gms.internal.zzbqs.zzb<List<zza>>(this) {
            final /* synthetic */ zzbpj zzceE;

            public void zzd(zzbqs<List<zza>> com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza) {
                this.zzceE.zza(list, (zzbqs) com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza);
            }
        });
    }

    private static DatabaseError zzas(String str, String str2) {
        return str != null ? DatabaseError.zzap(str, str2) : null;
    }

    private zzbph zzb(zzbph com_google_android_gms_internal_zzbph, final int i) {
        zzbph zzWO = zzp(com_google_android_gms_internal_zzbph).zzWO();
        if (this.zzcev.zzaaF()) {
            zzbrn com_google_android_gms_internal_zzbrn = this.zzceu;
            String valueOf = String.valueOf(com_google_android_gms_internal_zzbph);
            String valueOf2 = String.valueOf(zzWO);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder((String.valueOf(valueOf).length() + 44) + String.valueOf(valueOf2).length()).append("Aborting transactions for path: ").append(valueOf).append(". Affected: ").append(valueOf2).toString(), new Object[0]);
        }
        zzbqs zzL = this.zzceq.zzL(com_google_android_gms_internal_zzbph);
        zzL.zza(new com.google.android.gms.internal.zzbqs.zza<List<zza>>(this) {
            final /* synthetic */ zzbpj zzceE;

            public boolean zze(zzbqs<List<zza>> com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza) {
                this.zzceE.zza((zzbqs) com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza, i);
                return false;
            }
        });
        zza(zzL, i);
        zzL.zza(new com.google.android.gms.internal.zzbqs.zzb<List<zza>>(this) {
            final /* synthetic */ zzbpj zzceE;

            public void zzd(zzbqs<List<zza>> com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza) {
                this.zzceE.zza((zzbqs) com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza, i);
            }
        });
        return zzWO;
    }

    private void zzb(zzbqs<List<zza>> com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza) {
        List list = (List) com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza.getValue();
        if (list != null) {
            int i = 0;
            while (i < list.size()) {
                int i2;
                if (((zza) list.get(i)).zzcff == zzb.COMPLETED) {
                    list.remove(i);
                    i2 = i;
                } else {
                    i2 = i + 1;
                }
                i = i2;
            }
            if (list.size() > 0) {
                com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza.setValue(list);
            } else {
                com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza.setValue(null);
            }
        }
        com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza.zzb(new C05119(this));
    }

    private void zzb(zzbrq com_google_android_gms_internal_zzbrq, Object obj) {
        if (com_google_android_gms_internal_zzbrq.equals(zzboz.zzcdP)) {
            this.zzcen.zzaT(((Long) obj).longValue());
        }
        zzbph com_google_android_gms_internal_zzbph = new zzbph(zzboz.zzcdO, com_google_android_gms_internal_zzbrq);
        try {
            zzbsc zzau = zzbsd.zzau(obj);
            this.zzceo.zzg(com_google_android_gms_internal_zzbph, zzau);
            zzZ(this.zzcez.zzi(com_google_android_gms_internal_zzbph, zzau));
        } catch (Throwable e) {
            this.zzceu.zzd("Failed to parse info update", e);
        }
    }

    private void zzb(List<zza> list, zzbph com_google_android_gms_internal_zzbph) {
        if (!list.isEmpty()) {
            List arrayList = new ArrayList();
            List arrayList2 = new ArrayList();
            for (zza zzc : list) {
                arrayList2.add(Long.valueOf(zzc.zzcfj));
            }
            for (final zza com_google_android_gms_internal_zzbpj_zza : list) {
                zzbph zza = zzbph.zza(com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbpj_zza.zzcai);
                ArrayList arrayList3 = new ArrayList();
                if ($assertionsDisabled || zza != null) {
                    Object obj;
                    DatabaseError zzk;
                    if (com_google_android_gms_internal_zzbpj_zza.zzcff == zzb.NEEDS_ABORT) {
                        obj = 1;
                        zzk = com_google_android_gms_internal_zzbpj_zza.zzcfi;
                        if (zzk.getCode() != -25) {
                            arrayList3.addAll(this.zzceA.zza(com_google_android_gms_internal_zzbpj_zza.zzcfj, true, false, this.zzcen));
                        }
                    } else if (com_google_android_gms_internal_zzbpj_zza.zzcff != zzb.RUN) {
                        zzk = null;
                        obj = null;
                    } else if (com_google_android_gms_internal_zzbpj_zza.retryCount >= 25) {
                        obj = 1;
                        zzk = DatabaseError.zziD("maxretries");
                        arrayList3.addAll(this.zzceA.zza(com_google_android_gms_internal_zzbpj_zza.zzcfj, true, false, this.zzcen));
                    } else {
                        Result doTransaction;
                        zzbsc zza2 = zza(com_google_android_gms_internal_zzbpj_zza.zzcai, arrayList2);
                        com_google_android_gms_internal_zzbpj_zza.zzcfk = zza2;
                        try {
                            doTransaction = com_google_android_gms_internal_zzbpj_zza.zzcfd.doTransaction(com.google.firebase.database.zza.zza(zza2));
                            zzk = null;
                        } catch (Throwable th) {
                            DatabaseError fromException = DatabaseError.fromException(th);
                            doTransaction = Transaction.abort();
                            zzk = fromException;
                        }
                        if (doTransaction.isSuccess()) {
                            Long valueOf = Long.valueOf(com_google_android_gms_internal_zzbpj_zza.zzcfj);
                            Map zza3 = zzbpn.zza(this.zzcen);
                            zzbsc zzWK = doTransaction.zzWK();
                            zzbsc zza4 = zzbpn.zza(zzWK, zza3);
                            com_google_android_gms_internal_zzbpj_zza.zzcfl = zzWK;
                            com_google_android_gms_internal_zzbpj_zza.zzcfm = zza4;
                            com_google_android_gms_internal_zzbpj_zza.zzcfj = zzZd();
                            arrayList2.remove(valueOf);
                            arrayList3.addAll(this.zzceA.zza(com_google_android_gms_internal_zzbpj_zza.zzcai, zzWK, zza4, com_google_android_gms_internal_zzbpj_zza.zzcfj, com_google_android_gms_internal_zzbpj_zza.zzcfh, false));
                            arrayList3.addAll(this.zzceA.zza(valueOf.longValue(), true, false, this.zzcen));
                            zzk = null;
                            obj = null;
                        } else {
                            obj = 1;
                            arrayList3.addAll(this.zzceA.zza(com_google_android_gms_internal_zzbpj_zza.zzcfj, true, false, this.zzcen));
                        }
                    }
                    zzZ(arrayList3);
                    if (obj != null) {
                        com_google_android_gms_internal_zzbpj_zza.zzcff = zzb.COMPLETED;
                        final DataSnapshot zza5 = com.google.firebase.database.zza.zza(com.google.firebase.database.zza.zza(this, com_google_android_gms_internal_zzbpj_zza.zzcai), zzbrx.zzn(com_google_android_gms_internal_zzbpj_zza.zzcfk));
                        zzs(new Runnable(this) {
                            final /* synthetic */ zzbpj zzceE;

                            public void run() {
                                this.zzceE.zze(new zzbpx(this.zzceE, com_google_android_gms_internal_zzbpj_zza.zzcfe, zzbrc.zzN(com_google_android_gms_internal_zzbpj_zza.zzcai)));
                            }
                        });
                        arrayList.add(new Runnable(this) {
                            public void run() {
                                com_google_android_gms_internal_zzbpj_zza.zzcfd.onComplete(zzk, false, zza5);
                            }
                        });
                    }
                } else {
                    throw new AssertionError();
                }
            }
            zzb(this.zzceq);
            for (int i = 0; i < arrayList.size(); i++) {
                zzq((Runnable) arrayList.get(i));
            }
            zzZf();
        }
    }

    private List<zza> zzc(zzbqs<List<zza>> com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza) {
        List arrayList = new ArrayList();
        zza(arrayList, (zzbqs) com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza);
        Collections.sort(arrayList);
        return arrayList;
    }

    private zzbsc zzn(zzbph com_google_android_gms_internal_zzbph) {
        return zza(com_google_android_gms_internal_zzbph, new ArrayList());
    }

    private zzbph zzo(zzbph com_google_android_gms_internal_zzbph) {
        zzbqs zzp = zzp(com_google_android_gms_internal_zzbph);
        zzbph zzWO = zzp.zzWO();
        zzb(zzc(zzp), zzWO);
        return zzWO;
    }

    private zzbqs<List<zza>> zzp(zzbph com_google_android_gms_internal_zzbph) {
        zzbqs<List<zza>> com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza = this.zzceq;
        while (!com_google_android_gms_internal_zzbph.isEmpty() && com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza.getValue() == null) {
            com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza = com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza.zzL(new zzbph(com_google_android_gms_internal_zzbph.zzYU()));
            com_google_android_gms_internal_zzbph = com_google_android_gms_internal_zzbph.zzYV();
        }
        return com_google_android_gms_internal_zzbqs_java_util_List_com_google_android_gms_internal_zzbpj_zza;
    }

    public FirebaseDatabase getDatabase() {
        return this.zzceB;
    }

    void interrupt() {
        this.zzcdg.interrupt("repo_interrupt");
    }

    public void onDisconnect() {
        zza(zzboz.zzcdR, Boolean.valueOf(false));
        zzZe();
    }

    public void purgeOutstandingWrites() {
        if (this.zzceu.zzaaF()) {
            this.zzceu.zzi("Purging writes", new Object[0]);
        }
        zzZ(this.zzceA.zzZl());
        zzb(zzbph.zzYR(), -25);
        this.zzcdg.purgeOutstandingWrites();
    }

    void resume() {
        this.zzcdg.resume("repo_interrupt");
    }

    public String toString() {
        return this.zzbZZ.toString();
    }

    public void zzXB() {
        zza(zzboz.zzcdR, Boolean.valueOf(true));
    }

    public zzbpk zzZa() {
        return this.zzbZZ;
    }

    public long zzZb() {
        return this.zzcen.zzabK();
    }

    boolean zzZc() {
        return (this.zzcez.isEmpty() && this.zzceA.isEmpty()) ? false : true;
    }

    public void zza(zzbph com_google_android_gms_internal_zzbph, zzboy com_google_android_gms_internal_zzboy, CompletionListener completionListener, Map<String, Object> map) {
        if (this.zzceu.zzaaF()) {
            zzbrn com_google_android_gms_internal_zzbrn = this.zzceu;
            String valueOf = String.valueOf(com_google_android_gms_internal_zzbph);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder(String.valueOf(valueOf).length() + 8).append("update: ").append(valueOf).toString(), new Object[0]);
        }
        if (this.zzcew.zzaaF()) {
            com_google_android_gms_internal_zzbrn = this.zzcew;
            valueOf = String.valueOf(com_google_android_gms_internal_zzbph);
            String valueOf2 = String.valueOf(map);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder((String.valueOf(valueOf).length() + 9) + String.valueOf(valueOf2).length()).append("update: ").append(valueOf).append(" ").append(valueOf2).toString(), new Object[0]);
        }
        if (com_google_android_gms_internal_zzboy.isEmpty()) {
            if (this.zzceu.zzaaF()) {
                this.zzceu.zzi("update called with no changes. No-op", new Object[0]);
            }
            zza(completionListener, null, com_google_android_gms_internal_zzbph);
            return;
        }
        zzboy zza = zzbpn.zza(com_google_android_gms_internal_zzboy, zzbpn.zza(this.zzcen));
        final long zzZd = zzZd();
        zzZ(this.zzceA.zza(com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzboy, zza, zzZd, true));
        final zzbph com_google_android_gms_internal_zzbph2 = com_google_android_gms_internal_zzbph;
        final CompletionListener completionListener2 = completionListener;
        this.zzcdg.zza(com_google_android_gms_internal_zzbph.zzYT(), (Map) map, new zzbos(this) {
            final /* synthetic */ zzbpj zzceE;

            public void zzar(String str, String str2) {
                DatabaseError zzat = zzbpj.zzas(str, str2);
                this.zzceE.zza("updateChildren", com_google_android_gms_internal_zzbph2, zzat);
                this.zzceE.zza(zzZd, com_google_android_gms_internal_zzbph2, zzat);
                this.zzceE.zza(completionListener2, zzat, com_google_android_gms_internal_zzbph2);
            }
        });
        Iterator it = com_google_android_gms_internal_zzboy.iterator();
        while (it.hasNext()) {
            zzo(zzb(com_google_android_gms_internal_zzbph.zzh((zzbph) ((Entry) it.next()).getKey()), -9));
        }
    }

    public void zza(zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc, CompletionListener completionListener) {
        if (this.zzceu.zzaaF()) {
            zzbrn com_google_android_gms_internal_zzbrn = this.zzceu;
            String valueOf = String.valueOf(com_google_android_gms_internal_zzbph);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder(String.valueOf(valueOf).length() + 5).append("set: ").append(valueOf).toString(), new Object[0]);
        }
        if (this.zzcew.zzaaF()) {
            com_google_android_gms_internal_zzbrn = this.zzcew;
            valueOf = String.valueOf(com_google_android_gms_internal_zzbph);
            String valueOf2 = String.valueOf(com_google_android_gms_internal_zzbsc);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder((String.valueOf(valueOf).length() + 6) + String.valueOf(valueOf2).length()).append("set: ").append(valueOf).append(" ").append(valueOf2).toString(), new Object[0]);
        }
        zzbsc zza = zzbpn.zza(com_google_android_gms_internal_zzbsc, zzbpn.zza(this.zzcen));
        final long zzZd = zzZd();
        zzZ(this.zzceA.zza(com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbsc, zza, zzZd, true, true));
        final zzbph com_google_android_gms_internal_zzbph2 = com_google_android_gms_internal_zzbph;
        final CompletionListener completionListener2 = completionListener;
        this.zzcdg.zza(com_google_android_gms_internal_zzbph.zzYT(), com_google_android_gms_internal_zzbsc.getValue(true), new zzbos(this) {
            final /* synthetic */ zzbpj zzceE;

            public void zzar(String str, String str2) {
                DatabaseError zzat = zzbpj.zzas(str, str2);
                this.zzceE.zza("setValue", com_google_android_gms_internal_zzbph2, zzat);
                this.zzceE.zza(zzZd, com_google_android_gms_internal_zzbph2, zzat);
                this.zzceE.zza(completionListener2, zzat, com_google_android_gms_internal_zzbph2);
            }
        });
        zzo(zzb(com_google_android_gms_internal_zzbph, -9));
    }

    public void zza(final zzbph com_google_android_gms_internal_zzbph, final CompletionListener completionListener) {
        this.zzcdg.zza(com_google_android_gms_internal_zzbph.zzYT(), new zzbos(this) {
            final /* synthetic */ zzbpj zzceE;

            public void zzar(String str, String str2) {
                DatabaseError zzat = zzbpj.zzas(str, str2);
                if (zzat == null) {
                    this.zzceE.zzcep.zzr(com_google_android_gms_internal_zzbph);
                }
                this.zzceE.zza(completionListener, zzat, com_google_android_gms_internal_zzbph);
            }
        });
    }

    public void zza(zzbph com_google_android_gms_internal_zzbph, final Handler handler, boolean z) {
        if (this.zzceu.zzaaF()) {
            zzbrn com_google_android_gms_internal_zzbrn = this.zzceu;
            String valueOf = String.valueOf(com_google_android_gms_internal_zzbph);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder(String.valueOf(valueOf).length() + 13).append("transaction: ").append(valueOf).toString(), new Object[0]);
        }
        if (this.zzcew.zzaaF()) {
            com_google_android_gms_internal_zzbrn = this.zzceu;
            valueOf = String.valueOf(com_google_android_gms_internal_zzbph);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder(String.valueOf(valueOf).length() + 13).append("transaction: ").append(valueOf).toString(), new Object[0]);
        }
        if (this.zzcet.zzXw() && !this.zzceC) {
            this.zzceC = true;
            this.zzcev.info("runTransaction() usage detected while persistence is enabled. Please be aware that transactions *will not* be persisted across database restarts.  See https://www.firebase.com/docs/android/guide/offline-capabilities.html#section-handling-transactions-offline for more details.");
        }
        DatabaseReference zza = com.google.firebase.database.zza.zza(this, com_google_android_gms_internal_zzbph);
        ValueEventListener c05085 = new C05085(this);
        zzf(new zzbpx(this, c05085, zza.zzWP()));
        zza com_google_android_gms_internal_zzbpj_zza = new zza(com_google_android_gms_internal_zzbph, handler, c05085, zzb.INITIALIZING, z, zzZg());
        zzbsc zzn = zzn(com_google_android_gms_internal_zzbph);
        com_google_android_gms_internal_zzbpj_zza.zzcfk = zzn;
        Result result;
        DatabaseError databaseError;
        try {
            Result doTransaction = handler.doTransaction(com.google.firebase.database.zza.zza(zzn));
            if (doTransaction == null) {
                throw new NullPointerException("Transaction returned null as result");
            }
            result = doTransaction;
            databaseError = null;
            if (result.isSuccess()) {
                com_google_android_gms_internal_zzbpj_zza.zzcff = zzb.RUN;
                zzbqs zzL = this.zzceq.zzL(com_google_android_gms_internal_zzbph);
                List list = (List) zzL.getValue();
                if (list == null) {
                    list = new ArrayList();
                }
                list.add(com_google_android_gms_internal_zzbpj_zza);
                zzL.setValue(list);
                Map zza2 = zzbpn.zza(this.zzcen);
                zzbsc zzWK = result.zzWK();
                zzbsc zza3 = zzbpn.zza(zzWK, zza2);
                com_google_android_gms_internal_zzbpj_zza.zzcfl = zzWK;
                com_google_android_gms_internal_zzbpj_zza.zzcfm = zza3;
                com_google_android_gms_internal_zzbpj_zza.zzcfj = zzZd();
                zzZ(this.zzceA.zza(com_google_android_gms_internal_zzbph, zzWK, zza3, com_google_android_gms_internal_zzbpj_zza.zzcfj, z, false));
                zzZf();
                return;
            }
            com_google_android_gms_internal_zzbpj_zza.zzcfl = null;
            com_google_android_gms_internal_zzbpj_zza.zzcfm = null;
            final DataSnapshot zza4 = com.google.firebase.database.zza.zza(zza, zzbrx.zzn(com_google_android_gms_internal_zzbpj_zza.zzcfk));
            zzq(new Runnable(this) {
                public void run() {
                    handler.onComplete(databaseError, false, zza4);
                }
            });
        } catch (Throwable th) {
            DatabaseError fromException = DatabaseError.fromException(th);
            databaseError = fromException;
            result = Transaction.abort();
        }
    }

    public void zza(final zzbph com_google_android_gms_internal_zzbph, final Map<zzbph, zzbsc> map, final CompletionListener completionListener, Map<String, Object> map2) {
        this.zzcdg.zzb(com_google_android_gms_internal_zzbph.zzYT(), (Map) map2, new zzbos(this) {
            final /* synthetic */ zzbpj zzceE;

            public void zzar(String str, String str2) {
                DatabaseError zzat = zzbpj.zzas(str, str2);
                this.zzceE.zza("onDisconnect().updateChildren", com_google_android_gms_internal_zzbph, zzat);
                if (zzat == null) {
                    for (Entry entry : map.entrySet()) {
                        this.zzceE.zzcep.zzh(com_google_android_gms_internal_zzbph.zzh((zzbph) entry.getKey()), (zzbsc) entry.getValue());
                    }
                }
                this.zzceE.zza(completionListener, zzat, com_google_android_gms_internal_zzbph);
            }
        });
    }

    public void zza(zzbrc com_google_android_gms_internal_zzbrc, boolean z) {
        if ($assertionsDisabled || com_google_android_gms_internal_zzbrc.zzWO().isEmpty() || !com_google_android_gms_internal_zzbrc.zzWO().zzYU().equals(zzboz.zzcdO)) {
            this.zzceA.zza(com_google_android_gms_internal_zzbrc, z);
            return;
        }
        throw new AssertionError();
    }

    public void zza(zzbrq com_google_android_gms_internal_zzbrq, Object obj) {
        zzb(com_google_android_gms_internal_zzbrq, obj);
    }

    void zza(final CompletionListener completionListener, final DatabaseError databaseError, zzbph com_google_android_gms_internal_zzbph) {
        if (completionListener != null) {
            zzbrq zzYX = com_google_android_gms_internal_zzbph.zzYX();
            final DatabaseReference zza = (zzYX == null || !zzYX.zzaaM()) ? com.google.firebase.database.zza.zza(this, com_google_android_gms_internal_zzbph) : com.google.firebase.database.zza.zza(this, com_google_android_gms_internal_zzbph.zzYW());
            zzq(new Runnable(this) {
                public void run() {
                    completionListener.onComplete(databaseError, zza);
                }
            });
        }
    }

    public void zza(List<String> list, Object obj, boolean z, Long l) {
        List zza;
        zzbph com_google_android_gms_internal_zzbph = new zzbph((List) list);
        if (this.zzceu.zzaaF()) {
            zzbrn com_google_android_gms_internal_zzbrn = this.zzceu;
            String valueOf = String.valueOf(com_google_android_gms_internal_zzbph);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder(String.valueOf(valueOf).length() + 14).append("onDataUpdate: ").append(valueOf).toString(), new Object[0]);
        }
        if (this.zzcew.zzaaF()) {
            com_google_android_gms_internal_zzbrn = this.zzceu;
            valueOf = String.valueOf(com_google_android_gms_internal_zzbph);
            String valueOf2 = String.valueOf(obj);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder((String.valueOf(valueOf).length() + 15) + String.valueOf(valueOf2).length()).append("onDataUpdate: ").append(valueOf).append(" ").append(valueOf2).toString(), new Object[0]);
        }
        this.zzcex++;
        if (l != null) {
            try {
                zzbps com_google_android_gms_internal_zzbps = new zzbps(l.longValue());
                if (z) {
                    Map hashMap = new HashMap();
                    for (Entry entry : ((Map) obj).entrySet()) {
                        hashMap.put(new zzbph((String) entry.getKey()), zzbsd.zzau(entry.getValue()));
                    }
                    zza = this.zzceA.zza(com_google_android_gms_internal_zzbph, hashMap, com_google_android_gms_internal_zzbps);
                } else {
                    zza = this.zzceA.zza(com_google_android_gms_internal_zzbph, zzbsd.zzau(obj), com_google_android_gms_internal_zzbps);
                }
            } catch (Throwable e) {
                this.zzceu.zzd("FIREBASE INTERNAL ERROR", e);
                return;
            }
        } else if (z) {
            Map hashMap2 = new HashMap();
            for (Entry entry2 : ((Map) obj).entrySet()) {
                hashMap2.put(new zzbph((String) entry2.getKey()), zzbsd.zzau(entry2.getValue()));
            }
            zza = this.zzceA.zza(com_google_android_gms_internal_zzbph, hashMap2);
        } else {
            zza = this.zzceA.zzi(com_google_android_gms_internal_zzbph, zzbsd.zzau(obj));
        }
        if (zza.size() > 0) {
            zzo(com_google_android_gms_internal_zzbph);
        }
        zzZ(zza);
    }

    public void zza(List<String> list, List<zzbor> list2, Long l) {
        zzbph com_google_android_gms_internal_zzbph = new zzbph((List) list);
        if (this.zzceu.zzaaF()) {
            zzbrn com_google_android_gms_internal_zzbrn = this.zzceu;
            String valueOf = String.valueOf(com_google_android_gms_internal_zzbph);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder(String.valueOf(valueOf).length() + 20).append("onRangeMergeUpdate: ").append(valueOf).toString(), new Object[0]);
        }
        if (this.zzcew.zzaaF()) {
            com_google_android_gms_internal_zzbrn = this.zzceu;
            valueOf = String.valueOf(com_google_android_gms_internal_zzbph);
            String valueOf2 = String.valueOf(list2);
            com_google_android_gms_internal_zzbrn.zzi(new StringBuilder((String.valueOf(valueOf).length() + 21) + String.valueOf(valueOf2).length()).append("onRangeMergeUpdate: ").append(valueOf).append(" ").append(valueOf2).toString(), new Object[0]);
        }
        this.zzcex++;
        List arrayList = new ArrayList(list2.size());
        for (zzbor com_google_android_gms_internal_zzbsh : list2) {
            arrayList.add(new zzbsh(com_google_android_gms_internal_zzbsh));
        }
        List zza = l != null ? this.zzceA.zza(com_google_android_gms_internal_zzbph, arrayList, new zzbps(l.longValue())) : this.zzceA.zzb(com_google_android_gms_internal_zzbph, arrayList);
        if (zza.size() > 0) {
            zzo(com_google_android_gms_internal_zzbph);
        }
        zzZ(zza);
    }

    public void zzax(Map<String, Object> map) {
        for (Entry entry : map.entrySet()) {
            zzb(zzbrq.zzja((String) entry.getKey()), entry.getValue());
        }
    }

    public void zzb(final zzbph com_google_android_gms_internal_zzbph, final zzbsc com_google_android_gms_internal_zzbsc, final CompletionListener completionListener) {
        this.zzcdg.zzb(com_google_android_gms_internal_zzbph.zzYT(), com_google_android_gms_internal_zzbsc.getValue(true), new zzbos(this) {
            final /* synthetic */ zzbpj zzceE;

            public void zzar(String str, String str2) {
                DatabaseError zzat = zzbpj.zzas(str, str2);
                this.zzceE.zza("onDisconnect().setValue", com_google_android_gms_internal_zzbph, zzat);
                if (zzat == null) {
                    this.zzceE.zzcep.zzh(com_google_android_gms_internal_zzbph, com_google_android_gms_internal_zzbsc);
                }
                this.zzceE.zza(completionListener, zzat, com_google_android_gms_internal_zzbph);
            }
        });
    }

    public void zzbb(boolean z) {
        zza(zzboz.zzcdQ, Boolean.valueOf(z));
    }

    public void zze(zzbpc com_google_android_gms_internal_zzbpc) {
        zzZ(zzboz.zzcdO.equals(com_google_android_gms_internal_zzbpc.zzYp().zzWO().zzYU()) ? this.zzcez.zzh(com_google_android_gms_internal_zzbpc) : this.zzceA.zzh(com_google_android_gms_internal_zzbpc));
    }

    public void zzf(zzbpc com_google_android_gms_internal_zzbpc) {
        zzbrq zzYU = com_google_android_gms_internal_zzbpc.zzYp().zzWO().zzYU();
        List zzg = (zzYU == null || !zzYU.equals(zzboz.zzcdO)) ? this.zzceA.zzg(com_google_android_gms_internal_zzbpc) : this.zzcez.zzg(com_google_android_gms_internal_zzbpc);
        zzZ(zzg);
    }

    public void zzq(Runnable runnable) {
        this.zzcet.zzYw();
        this.zzcet.zzYC().zzq(runnable);
    }

    public void zzs(Runnable runnable) {
        this.zzcet.zzYw();
        this.zzcet.zzYD().zzs(runnable);
    }
}
