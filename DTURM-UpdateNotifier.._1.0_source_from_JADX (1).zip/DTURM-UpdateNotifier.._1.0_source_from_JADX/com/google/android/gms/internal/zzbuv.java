package com.google.android.gms.internal;

import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

final class zzbuv implements zzbvf<Date>, zzbvo<Date> {
    private final DateFormat zzcqJ;
    private final DateFormat zzcqK;
    private final DateFormat zzcqL;

    zzbuv() {
        this(DateFormat.getDateTimeInstance(2, 2, Locale.US), DateFormat.getDateTimeInstance(2, 2));
    }

    public zzbuv(int i, int i2) {
        this(DateFormat.getDateTimeInstance(i, i2, Locale.US), DateFormat.getDateTimeInstance(i, i2));
    }

    zzbuv(String str) {
        this(new SimpleDateFormat(str, Locale.US), new SimpleDateFormat(str));
    }

    zzbuv(DateFormat dateFormat, DateFormat dateFormat2) {
        this.zzcqJ = dateFormat;
        this.zzcqK = dateFormat2;
        this.zzcqL = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        this.zzcqL.setTimeZone(TimeZone.getTimeZone("UTC"));
    }

    private Date zza(zzbvg com_google_android_gms_internal_zzbvg) {
        Date parse;
        synchronized (this.zzcqK) {
            try {
                parse = this.zzcqK.parse(com_google_android_gms_internal_zzbvg.zzadR());
            } catch (ParseException e) {
                try {
                    parse = this.zzcqJ.parse(com_google_android_gms_internal_zzbvg.zzadR());
                } catch (ParseException e2) {
                    try {
                        parse = this.zzcqL.parse(com_google_android_gms_internal_zzbvg.zzadR());
                    } catch (Throwable e3) {
                        throw new zzbvp(com_google_android_gms_internal_zzbvg.zzadR(), e3);
                    }
                }
            }
        }
        return parse;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(zzbuv.class.getSimpleName());
        stringBuilder.append('(').append(this.zzcqK.getClass().getSimpleName()).append(')');
        return stringBuilder.toString();
    }

    public zzbvg zza(Date date, Type type, zzbvn com_google_android_gms_internal_zzbvn) {
        zzbvg com_google_android_gms_internal_zzbvm;
        synchronized (this.zzcqK) {
            com_google_android_gms_internal_zzbvm = new zzbvm(this.zzcqJ.format(date));
        }
        return com_google_android_gms_internal_zzbvm;
    }

    public Date zza(zzbvg com_google_android_gms_internal_zzbvg, Type type, zzbve com_google_android_gms_internal_zzbve) throws zzbvk {
        if (com_google_android_gms_internal_zzbvg instanceof zzbvm) {
            Date zza = zza(com_google_android_gms_internal_zzbvg);
            if (type == Date.class) {
                return zza;
            }
            if (type == Timestamp.class) {
                return new Timestamp(zza.getTime());
            }
            if (type == java.sql.Date.class) {
                return new java.sql.Date(zza.getTime());
            }
            String valueOf = String.valueOf(getClass());
            String valueOf2 = String.valueOf(type);
            throw new IllegalArgumentException(new StringBuilder((String.valueOf(valueOf).length() + 23) + String.valueOf(valueOf2).length()).append(valueOf).append(" cannot deserialize to ").append(valueOf2).toString());
        }
        throw new zzbvk("The date should be a string value");
    }

    public /* synthetic */ Object zzb(zzbvg com_google_android_gms_internal_zzbvg, Type type, zzbve com_google_android_gms_internal_zzbve) throws zzbvk {
        return zza(com_google_android_gms_internal_zzbvg, type, com_google_android_gms_internal_zzbve);
    }
}
