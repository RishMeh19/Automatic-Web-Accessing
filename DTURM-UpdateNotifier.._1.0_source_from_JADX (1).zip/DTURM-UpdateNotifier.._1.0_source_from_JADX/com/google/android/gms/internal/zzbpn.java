package com.google.android.gms.internal;

import com.google.android.gms.internal.zzbpp.zzb;
import com.google.android.gms.internal.zzbrr.zza;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class zzbpn {

    class C05121 implements zzb {
        final /* synthetic */ Map zzcfA;
        final /* synthetic */ zzbpp zzcfz;

        C05121(zzbpp com_google_android_gms_internal_zzbpp, Map map) {
            this.zzcfz = com_google_android_gms_internal_zzbpp;
            this.zzcfA = map;
        }

        public void zzf(zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc) {
            this.zzcfz.zzh(com_google_android_gms_internal_zzbph, zzbpn.zza(com_google_android_gms_internal_zzbsc, this.zzcfA));
        }
    }

    class C06352 extends zza {
        final /* synthetic */ Map zzcfA;
        final /* synthetic */ zzbpo zzcfB;

        C06352(Map map, zzbpo com_google_android_gms_internal_zzbpo) {
            this.zzcfA = map;
            this.zzcfB = com_google_android_gms_internal_zzbpo;
        }

        public void zzb(zzbrq com_google_android_gms_internal_zzbrq, zzbsc com_google_android_gms_internal_zzbsc) {
            zzbsc zza = zzbpn.zza(com_google_android_gms_internal_zzbsc, this.zzcfA);
            if (zza != com_google_android_gms_internal_zzbsc) {
                this.zzcfB.zzg(new zzbph(com_google_android_gms_internal_zzbrq.asString()), zza);
            }
        }
    }

    public static zzboy zza(zzboy com_google_android_gms_internal_zzboy, Map<String, Object> map) {
        zzboy zzYq = zzboy.zzYq();
        Iterator it = com_google_android_gms_internal_zzboy.iterator();
        zzboy com_google_android_gms_internal_zzboy2 = zzYq;
        while (it.hasNext()) {
            Entry entry = (Entry) it.next();
            com_google_android_gms_internal_zzboy2 = com_google_android_gms_internal_zzboy2.zze((zzbph) entry.getKey(), zza((zzbsc) entry.getValue(), (Map) map));
        }
        return com_google_android_gms_internal_zzboy2;
    }

    public static zzbpp zza(zzbpp com_google_android_gms_internal_zzbpp, Map<String, Object> map) {
        zzbpp com_google_android_gms_internal_zzbpp2 = new zzbpp();
        com_google_android_gms_internal_zzbpp.zza(new zzbph(""), new C05121(com_google_android_gms_internal_zzbpp2, map));
        return com_google_android_gms_internal_zzbpp2;
    }

    public static zzbsc zza(zzbsc com_google_android_gms_internal_zzbsc, Map<String, Object> map) {
        Object value = com_google_android_gms_internal_zzbsc.zzaaQ().getValue();
        if (value instanceof Map) {
            Map map2 = (Map) value;
            if (map2.containsKey(".sv")) {
                value = map.get((String) map2.get(".sv"));
            }
        }
        zzbsc zzav = zzbsg.zzav(value);
        if (com_google_android_gms_internal_zzbsc.zzaaP()) {
            value = zza(com_google_android_gms_internal_zzbsc.getValue(), (Map) map);
            return (value.equals(com_google_android_gms_internal_zzbsc.getValue()) && zzav.equals(com_google_android_gms_internal_zzbsc.zzaaQ())) ? com_google_android_gms_internal_zzbsc : zzbsd.zza(value, zzav);
        } else if (com_google_android_gms_internal_zzbsc.isEmpty()) {
            return com_google_android_gms_internal_zzbsc;
        } else {
            zzbrr com_google_android_gms_internal_zzbrr = (zzbrr) com_google_android_gms_internal_zzbsc;
            zzbpo com_google_android_gms_internal_zzbpo = new zzbpo(com_google_android_gms_internal_zzbrr);
            com_google_android_gms_internal_zzbrr.zza(new C06352(map, com_google_android_gms_internal_zzbpo));
            return !com_google_android_gms_internal_zzbpo.zzZh().zzaaQ().equals(zzav) ? com_google_android_gms_internal_zzbpo.zzZh().zzg(zzav) : com_google_android_gms_internal_zzbpo.zzZh();
        }
    }

    public static Object zza(Object obj, Map<String, Object> map) {
        if (!(obj instanceof Map)) {
            return obj;
        }
        Map map2 = (Map) obj;
        if (!map2.containsKey(".sv")) {
            return obj;
        }
        String str = (String) map2.get(".sv");
        return map.containsKey(str) ? map.get(str) : obj;
    }

    public static Map<String, Object> zza(zzbsw com_google_android_gms_internal_zzbsw) {
        Map<String, Object> hashMap = new HashMap();
        hashMap.put("timestamp", Long.valueOf(com_google_android_gms_internal_zzbsw.zzabK()));
        return hashMap;
    }
}
