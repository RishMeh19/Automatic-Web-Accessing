package com.google.android.gms.internal;

import java.util.Map;

public class zzbrc {
    private final zzbph zzcai;
    private final zzbrb zzcam;

    public zzbrc(zzbph com_google_android_gms_internal_zzbph, zzbrb com_google_android_gms_internal_zzbrb) {
        this.zzcai = com_google_android_gms_internal_zzbph;
        this.zzcam = com_google_android_gms_internal_zzbrb;
    }

    public static zzbrc zzN(zzbph com_google_android_gms_internal_zzbph) {
        return new zzbrc(com_google_android_gms_internal_zzbph, zzbrb.zzcie);
    }

    public static zzbrc zzb(zzbph com_google_android_gms_internal_zzbph, Map<String, Object> map) {
        return new zzbrc(com_google_android_gms_internal_zzbph, zzbrb.zzaE(map));
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        zzbrc com_google_android_gms_internal_zzbrc = (zzbrc) obj;
        return !this.zzcai.equals(com_google_android_gms_internal_zzbrc.zzcai) ? false : this.zzcam.equals(com_google_android_gms_internal_zzbrc.zzcam);
    }

    public int hashCode() {
        return (this.zzcai.hashCode() * 31) + this.zzcam.hashCode();
    }

    public boolean isDefault() {
        return this.zzcam.isDefault();
    }

    public String toString() {
        String valueOf = String.valueOf(this.zzcai);
        String valueOf2 = String.valueOf(this.zzcam);
        return new StringBuilder((String.valueOf(valueOf).length() + 1) + String.valueOf(valueOf2).length()).append(valueOf).append(":").append(valueOf2).toString();
    }

    public zzbph zzWO() {
        return this.zzcai;
    }

    public zzbrw zzaal() {
        return this.zzcam.zzaal();
    }

    public boolean zzaap() {
        return this.zzcam.zzaap();
    }

    public zzbrb zzaas() {
        return this.zzcam;
    }
}
