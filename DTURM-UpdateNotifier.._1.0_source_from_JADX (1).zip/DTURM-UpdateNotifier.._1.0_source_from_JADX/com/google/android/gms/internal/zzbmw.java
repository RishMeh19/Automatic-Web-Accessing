package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;
import java.util.List;

public class zzbmw implements Creator<zzbmv> {
    static void zza(zzbmv com_google_android_gms_internal_zzbmv, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zzc(parcel, 1, com_google_android_gms_internal_zzbmv.zzaiI);
        zzc.zzb(parcel, 2, com_google_android_gms_internal_zzbmv.zzWm(), false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzlL(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzqs(i);
    }

    public zzbmv zzlL(Parcel parcel) {
        int zzaY = zzb.zzaY(parcel);
        int i = 0;
        List list = null;
        while (parcel.dataPosition() < zzaY) {
            int zzaX = zzb.zzaX(parcel);
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    i = zzb.zzg(parcel, zzaX);
                    break;
                case 2:
                    list = zzb.zzE(parcel, zzaX);
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    break;
            }
        }
        if (parcel.dataPosition() == zzaY) {
            return new zzbmv(i, list);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zzbmv[] zzqs(int i) {
        return new zzbmv[i];
    }
}
