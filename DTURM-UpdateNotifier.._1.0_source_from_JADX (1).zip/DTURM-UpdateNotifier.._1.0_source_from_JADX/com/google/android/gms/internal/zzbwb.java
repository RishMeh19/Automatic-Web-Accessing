package com.google.android.gms.internal;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class zzbwb implements zzbvt, Cloneable {
    public static final zzbwb zzcrP = new zzbwb();
    private double zzcrQ = -1.0d;
    private int zzcrR = 136;
    private boolean zzcrS = true;
    private List<zzbuw> zzcrT = Collections.emptyList();
    private List<zzbuw> zzcrU = Collections.emptyList();

    private boolean zza(zzbvw com_google_android_gms_internal_zzbvw) {
        return com_google_android_gms_internal_zzbvw == null || com_google_android_gms_internal_zzbvw.zzaef() <= this.zzcrQ;
    }

    private boolean zza(zzbvw com_google_android_gms_internal_zzbvw, zzbvx com_google_android_gms_internal_zzbvx) {
        return zza(com_google_android_gms_internal_zzbvw) && zza(com_google_android_gms_internal_zzbvx);
    }

    private boolean zza(zzbvx com_google_android_gms_internal_zzbvx) {
        return com_google_android_gms_internal_zzbvx == null || com_google_android_gms_internal_zzbvx.zzaef() > this.zzcrQ;
    }

    private boolean zzl(Class<?> cls) {
        return !Enum.class.isAssignableFrom(cls) && (cls.isAnonymousClass() || cls.isLocalClass());
    }

    private boolean zzm(Class<?> cls) {
        return cls.isMemberClass() && !zzn(cls);
    }

    private boolean zzn(Class<?> cls) {
        return (cls.getModifiers() & 8) != 0;
    }

    protected /* synthetic */ Object clone() throws CloneNotSupportedException {
        return zzaeh();
    }

    public <T> zzbvs<T> zza(zzbva com_google_android_gms_internal_zzbva, zzbww<T> com_google_android_gms_internal_zzbww_T) {
        Class zzaey = com_google_android_gms_internal_zzbww_T.zzaey();
        final boolean zza = zza(zzaey, true);
        final boolean zza2 = zza(zzaey, false);
        if (!zza && !zza2) {
            return null;
        }
        final zzbva com_google_android_gms_internal_zzbva2 = com_google_android_gms_internal_zzbva;
        final zzbww<T> com_google_android_gms_internal_zzbww_T2 = com_google_android_gms_internal_zzbww_T;
        return new zzbvs<T>(this) {
            final /* synthetic */ zzbwb zzcrZ;
            private zzbvs<T> zzcre;

            private zzbvs<T> zzaed() {
                zzbvs<T> com_google_android_gms_internal_zzbvs_T = this.zzcre;
                if (com_google_android_gms_internal_zzbvs_T != null) {
                    return com_google_android_gms_internal_zzbvs_T;
                }
                com_google_android_gms_internal_zzbvs_T = com_google_android_gms_internal_zzbva2.zza(this.zzcrZ, com_google_android_gms_internal_zzbww_T2);
                this.zzcre = com_google_android_gms_internal_zzbvs_T;
                return com_google_android_gms_internal_zzbvs_T;
            }

            public void zza(zzbwz com_google_android_gms_internal_zzbwz, T t) throws IOException {
                if (zza) {
                    com_google_android_gms_internal_zzbwz.zzaex();
                } else {
                    zzaed().zza(com_google_android_gms_internal_zzbwz, t);
                }
            }

            public T zzb(zzbwx com_google_android_gms_internal_zzbwx) throws IOException {
                if (!zza2) {
                    return zzaed().zzb(com_google_android_gms_internal_zzbwx);
                }
                com_google_android_gms_internal_zzbwx.skipValue();
                return null;
            }
        };
    }

    public zzbwb zza(zzbuw com_google_android_gms_internal_zzbuw, boolean z, boolean z2) {
        zzbwb zzaeh = zzaeh();
        if (z) {
            zzaeh.zzcrT = new ArrayList(this.zzcrT);
            zzaeh.zzcrT.add(com_google_android_gms_internal_zzbuw);
        }
        if (z2) {
            zzaeh.zzcrU = new ArrayList(this.zzcrU);
            zzaeh.zzcrU.add(com_google_android_gms_internal_zzbuw);
        }
        return zzaeh;
    }

    public boolean zza(Class<?> cls, boolean z) {
        if (this.zzcrQ != -1.0d && !zza((zzbvw) cls.getAnnotation(zzbvw.class), (zzbvx) cls.getAnnotation(zzbvx.class))) {
            return true;
        }
        if (!this.zzcrS && zzm(cls)) {
            return true;
        }
        if (zzl(cls)) {
            return true;
        }
        for (zzbuw zzg : z ? this.zzcrT : this.zzcrU) {
            if (zzg.zzg(cls)) {
                return true;
            }
        }
        return false;
    }

    public boolean zza(Field field, boolean z) {
        if ((this.zzcrR & field.getModifiers()) != 0) {
            return true;
        }
        if (this.zzcrQ != -1.0d && !zza((zzbvw) field.getAnnotation(zzbvw.class), (zzbvx) field.getAnnotation(zzbvx.class))) {
            return true;
        }
        if (field.isSynthetic()) {
            return true;
        }
        if (!this.zzcrS && zzm(field.getType())) {
            return true;
        }
        if (zzl(field.getType())) {
            return true;
        }
        List<zzbuw> list = z ? this.zzcrT : this.zzcrU;
        if (!list.isEmpty()) {
            zzbux com_google_android_gms_internal_zzbux = new zzbux(field);
            for (zzbuw zza : list) {
                if (zza.zza(com_google_android_gms_internal_zzbux)) {
                    return true;
                }
            }
        }
        return false;
    }

    protected zzbwb zzaeh() {
        try {
            return (zzbwb) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }

    public zzbwb zzg(int... iArr) {
        int i = 0;
        zzbwb zzaeh = zzaeh();
        zzaeh.zzcrR = 0;
        int length = iArr.length;
        while (i < length) {
            zzaeh.zzcrR = iArr[i] | zzaeh.zzcrR;
            i++;
        }
        return zzaeh;
    }
}
