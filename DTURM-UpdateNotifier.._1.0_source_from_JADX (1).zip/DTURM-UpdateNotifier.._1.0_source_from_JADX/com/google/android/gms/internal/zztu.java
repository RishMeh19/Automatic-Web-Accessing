package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzb.zza;
import com.google.android.gms.common.internal.safeparcel.zzc;

public class zztu implements Creator<zztt> {
    static void zza(zztt com_google_android_gms_internal_zztt, Parcel parcel, int i) {
        int zzaZ = zzc.zzaZ(parcel);
        zzc.zza(parcel, 1, com_google_android_gms_internal_zztt.zzahm, false);
        zzc.zza(parcel, 3, com_google_android_gms_internal_zztt.zzahn, i, false);
        zzc.zzc(parcel, 4, com_google_android_gms_internal_zztt.zzaho);
        zzc.zza(parcel, 5, com_google_android_gms_internal_zztt.zzahp, false);
        zzc.zzJ(parcel, zzaZ);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return zzA(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return zzaL(i);
    }

    public zztt zzA(Parcel parcel) {
        byte[] bArr = null;
        int zzaY = zzb.zzaY(parcel);
        int i = -1;
        zzub com_google_android_gms_internal_zzub = null;
        String str = null;
        while (parcel.dataPosition() < zzaY) {
            int i2;
            zzub com_google_android_gms_internal_zzub2;
            String zzq;
            byte[] bArr2;
            int zzaX = zzb.zzaX(parcel);
            byte[] bArr3;
            switch (zzb.zzdc(zzaX)) {
                case 1:
                    bArr3 = bArr;
                    i2 = i;
                    com_google_android_gms_internal_zzub2 = com_google_android_gms_internal_zzub;
                    zzq = zzb.zzq(parcel, zzaX);
                    bArr2 = bArr3;
                    break;
                case 3:
                    zzq = str;
                    int i3 = i;
                    com_google_android_gms_internal_zzub2 = (zzub) zzb.zza(parcel, zzaX, zzub.CREATOR);
                    bArr2 = bArr;
                    i2 = i3;
                    break;
                case 4:
                    com_google_android_gms_internal_zzub2 = com_google_android_gms_internal_zzub;
                    zzq = str;
                    bArr3 = bArr;
                    i2 = zzb.zzg(parcel, zzaX);
                    bArr2 = bArr3;
                    break;
                case 5:
                    bArr2 = zzb.zzt(parcel, zzaX);
                    i2 = i;
                    com_google_android_gms_internal_zzub2 = com_google_android_gms_internal_zzub;
                    zzq = str;
                    break;
                default:
                    zzb.zzb(parcel, zzaX);
                    bArr2 = bArr;
                    i2 = i;
                    com_google_android_gms_internal_zzub2 = com_google_android_gms_internal_zzub;
                    zzq = str;
                    break;
            }
            str = zzq;
            com_google_android_gms_internal_zzub = com_google_android_gms_internal_zzub2;
            i = i2;
            bArr = bArr2;
        }
        if (parcel.dataPosition() == zzaY) {
            return new zztt(str, com_google_android_gms_internal_zzub, i, bArr);
        }
        throw new zza("Overread allowed size end=" + zzaY, parcel);
    }

    public zztt[] zzaL(int i) {
        return new zztt[i];
    }
}
