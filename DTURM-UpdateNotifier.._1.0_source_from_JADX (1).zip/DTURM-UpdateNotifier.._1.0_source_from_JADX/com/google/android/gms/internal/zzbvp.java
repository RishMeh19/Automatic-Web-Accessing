package com.google.android.gms.internal;

public final class zzbvp extends zzbvk {
    public zzbvp(String str) {
        super(str);
    }

    public zzbvp(String str, Throwable th) {
        super(str, th);
    }

    public zzbvp(Throwable th) {
        super(th);
    }
}
