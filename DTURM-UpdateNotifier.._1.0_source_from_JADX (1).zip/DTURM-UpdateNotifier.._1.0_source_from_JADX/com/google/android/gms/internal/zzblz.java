package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.firebase.auth.UserProfileChangeRequest;

public interface zzblz extends IInterface {

    public static abstract class zza extends Binder implements zzblz {

        private static class zza implements zzblz {
            private IBinder zzrk;

            zza(IBinder iBinder) {
                this.zzrk = iBinder;
            }

            public IBinder asBinder() {
                return this.zzrk;
            }

            public void zza(zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(16, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(zzbmx com_google_android_gms_internal_zzbmx, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    if (com_google_android_gms_internal_zzbmx != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_internal_zzbmx.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(String str, zzbmx com_google_android_gms_internal_zzbmx, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    if (com_google_android_gms_internal_zzbmx != null) {
                        obtain.writeInt(1);
                        com_google_android_gms_internal_zzbmx.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(12, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(String str, UserProfileChangeRequest userProfileChangeRequest, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    if (userProfileChangeRequest != null) {
                        obtain.writeInt(1);
                        userProfileChangeRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(String str, String str2, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(5, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zza(String str, String str2, String str3, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeString(str3);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(11, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zzb(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zzb(String str, String str2, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(6, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zzc(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(9, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zzc(String str, String str2, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(7, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zzd(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(10, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zzd(String str, String str2, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(8, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zze(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(13, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zze(String str, String str2, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(14, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zzf(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(15, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zzf(String str, String str2, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(21, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zzg(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(17, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zzh(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(18, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zzi(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(19, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void zzj(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    obtain.writeString(str);
                    obtain.writeStrongBinder(com_google_android_gms_internal_zzbly != null ? com_google_android_gms_internal_zzbly.asBinder() : null);
                    this.zzrk.transact(20, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public static zzblz zzfL(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof zzblz)) ? new zza(iBinder) : (zzblz) queryLocalInterface;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            zzbmx com_google_android_gms_internal_zzbmx = null;
            String readString;
            switch (i) {
                case 1:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zza(parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 2:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zzb(parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 3:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_internal_zzbmx = (zzbmx) zzbmx.CREATOR.createFromParcel(parcel);
                    }
                    zza(com_google_android_gms_internal_zzbmx, com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 4:
                    UserProfileChangeRequest userProfileChangeRequest;
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    readString = parcel.readString();
                    if (parcel.readInt() != 0) {
                        userProfileChangeRequest = (UserProfileChangeRequest) UserProfileChangeRequest.CREATOR.createFromParcel(parcel);
                    }
                    zza(readString, userProfileChangeRequest, com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 5:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zza(parcel.readString(), parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 6:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zzb(parcel.readString(), parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 7:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zzc(parcel.readString(), parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 8:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zzd(parcel.readString(), parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 9:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zzc(parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 10:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zzd(parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 11:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zza(parcel.readString(), parcel.readString(), parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 12:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    readString = parcel.readString();
                    if (parcel.readInt() != 0) {
                        com_google_android_gms_internal_zzbmx = (zzbmx) zzbmx.CREATOR.createFromParcel(parcel);
                    }
                    zza(readString, com_google_android_gms_internal_zzbmx, com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 13:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zze(parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 14:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zze(parcel.readString(), parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 15:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zzf(parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 16:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zza(com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 17:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zzg(parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 18:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zzh(parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 19:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zzi(parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 20:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zzj(parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 21:
                    parcel.enforceInterface("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    zzf(parcel.readString(), parcel.readString(), com.google.android.gms.internal.zzbly.zza.zzfK(parcel.readStrongBinder()));
                    parcel2.writeNoException();
                    return true;
                case 1598968902:
                    parcel2.writeString("com.google.firebase.auth.api.internal.IFirebaseAuthService");
                    return true;
                default:
                    return super.onTransact(i, parcel, parcel2, i2);
            }
        }
    }

    void zza(zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zza(zzbmx com_google_android_gms_internal_zzbmx, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zza(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zza(String str, zzbmx com_google_android_gms_internal_zzbmx, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zza(String str, UserProfileChangeRequest userProfileChangeRequest, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zza(String str, String str2, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zza(String str, String str2, String str3, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zzb(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zzb(String str, String str2, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zzc(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zzc(String str, String str2, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zzd(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zzd(String str, String str2, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zze(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zze(String str, String str2, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zzf(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zzf(String str, String str2, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zzg(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zzh(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zzi(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;

    void zzj(String str, zzbly com_google_android_gms_internal_zzbly) throws RemoteException;
}
