package com.google.android.gms.internal;

import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.google.android.gms.common.internal.zzac;
import com.google.firebase.storage.zzd;
import java.util.concurrent.Executor;

public class zzbup {
    static boolean zzcqC = false;
    private final Handler mHandler;
    private final Executor zzbFP;

    public zzbup(@Nullable Executor executor) {
        this.zzbFP = executor;
        if (this.zzbFP == null) {
            this.mHandler = new Handler(Looper.getMainLooper());
        } else {
            this.mHandler = null;
        }
    }

    public void zzy(@NonNull Runnable runnable) {
        zzac.zzw(runnable);
        if (this.mHandler != null) {
            this.mHandler.post(runnable);
        } else if (this.zzbFP != null) {
            this.zzbFP.execute(runnable);
        } else {
            zzd.zzadp().zzx(runnable);
        }
    }
}
