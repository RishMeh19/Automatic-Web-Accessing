package com.google.android.gms.internal;

public class zzbqo {
    public final long id;
    public final boolean zzbqZ;
    public final zzbrc zzchm;
    public final long zzchn;
    public final boolean zzcho;

    public zzbqo(long j, zzbrc com_google_android_gms_internal_zzbrc, long j2, boolean z, boolean z2) {
        this.id = j;
        if (!com_google_android_gms_internal_zzbrc.zzaap() || com_google_android_gms_internal_zzbrc.isDefault()) {
            this.zzchm = com_google_android_gms_internal_zzbrc;
            this.zzchn = j2;
            this.zzcho = z;
            this.zzbqZ = z2;
            return;
        }
        throw new IllegalArgumentException("Can't create TrackedQuery for a non-default query that loads all data");
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        zzbqo com_google_android_gms_internal_zzbqo = (zzbqo) obj;
        return this.id == com_google_android_gms_internal_zzbqo.id && this.zzchm.equals(com_google_android_gms_internal_zzbqo.zzchm) && this.zzchn == com_google_android_gms_internal_zzbqo.zzchn && this.zzcho == com_google_android_gms_internal_zzbqo.zzcho && this.zzbqZ == com_google_android_gms_internal_zzbqo.zzbqZ;
    }

    public int hashCode() {
        return (((((((Long.valueOf(this.id).hashCode() * 31) + this.zzchm.hashCode()) * 31) + Long.valueOf(this.zzchn).hashCode()) * 31) + Boolean.valueOf(this.zzcho).hashCode()) * 31) + Boolean.valueOf(this.zzbqZ).hashCode();
    }

    public String toString() {
        long j = this.id;
        String valueOf = String.valueOf(this.zzchm);
        long j2 = this.zzchn;
        boolean z = this.zzcho;
        return new StringBuilder(String.valueOf(valueOf).length() + 109).append("TrackedQuery{id=").append(j).append(", querySpec=").append(valueOf).append(", lastUse=").append(j2).append(", complete=").append(z).append(", active=").append(this.zzbqZ).append("}").toString();
    }

    public zzbqo zzZL() {
        return new zzbqo(this.id, this.zzchm, this.zzchn, true, this.zzbqZ);
    }

    public zzbqo zzaS(long j) {
        return new zzbqo(this.id, this.zzchm, j, this.zzcho, this.zzbqZ);
    }

    public zzbqo zzbf(boolean z) {
        return new zzbqo(this.id, this.zzchm, this.zzchn, this.zzcho, z);
    }
}
