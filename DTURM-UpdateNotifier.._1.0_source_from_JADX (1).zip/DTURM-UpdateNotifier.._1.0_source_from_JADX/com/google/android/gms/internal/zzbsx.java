package com.google.android.gms.internal;

public class zzbsx implements zzbsw {
    public long zzabK() {
        return System.currentTimeMillis();
    }
}
