package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

public class zzbsh {
    static final /* synthetic */ boolean $assertionsDisabled = (!zzbsh.class.desiredAssertionStatus());
    private final zzbph zzcjH;
    private final zzbph zzcjI;
    private final zzbsc zzcjJ;

    public zzbsh(zzbor com_google_android_gms_internal_zzbor) {
        zzbph com_google_android_gms_internal_zzbph = null;
        List zzXY = com_google_android_gms_internal_zzbor.zzXY();
        this.zzcjH = zzXY != null ? new zzbph(zzXY) : null;
        List zzXZ = com_google_android_gms_internal_zzbor.zzXZ();
        if (zzXZ != null) {
            com_google_android_gms_internal_zzbph = new zzbph(zzXZ);
        }
        this.zzcjI = com_google_android_gms_internal_zzbph;
        this.zzcjJ = zzbsd.zzau(com_google_android_gms_internal_zzbor.zzYa());
    }

    private zzbsc zzb(zzbph com_google_android_gms_internal_zzbph, zzbsc com_google_android_gms_internal_zzbsc, zzbsc com_google_android_gms_internal_zzbsc2) {
        Object obj = 1;
        int zzj = this.zzcjH == null ? 1 : com_google_android_gms_internal_zzbph.zzj(this.zzcjH);
        int zzj2 = this.zzcjI == null ? -1 : com_google_android_gms_internal_zzbph.zzj(this.zzcjI);
        Object obj2 = (this.zzcjH == null || !com_google_android_gms_internal_zzbph.zzi(this.zzcjH)) ? null : 1;
        if (this.zzcjI == null || !com_google_android_gms_internal_zzbph.zzi(this.zzcjI)) {
            obj = null;
        }
        if (zzj > 0 && zzj2 < 0 && r1 == null) {
            return com_google_android_gms_internal_zzbsc2;
        }
        if (zzj > 0 && r1 != null && com_google_android_gms_internal_zzbsc2.zzaaP()) {
            return com_google_android_gms_internal_zzbsc2;
        }
        if (zzj <= 0 || zzj2 != 0) {
            if (obj2 != null || r1 != null) {
                Collection hashSet = new HashSet();
                for (zzbsb zzabl : com_google_android_gms_internal_zzbsc) {
                    hashSet.add(zzabl.zzabl());
                }
                for (zzbsb zzabl2 : com_google_android_gms_internal_zzbsc2) {
                    hashSet.add(zzabl2.zzabl());
                }
                List<zzbrq> arrayList = new ArrayList(hashSet.size() + 1);
                arrayList.addAll(hashSet);
                if (!(com_google_android_gms_internal_zzbsc2.zzaaQ().isEmpty() && com_google_android_gms_internal_zzbsc.zzaaQ().isEmpty())) {
                    arrayList.add(zzbrq.zzaaK());
                }
                zzbsc com_google_android_gms_internal_zzbsc3 = com_google_android_gms_internal_zzbsc;
                for (zzbrq com_google_android_gms_internal_zzbrq : arrayList) {
                    zzbsc zzm = com_google_android_gms_internal_zzbsc.zzm(com_google_android_gms_internal_zzbrq);
                    zzbsc zzb = zzb(com_google_android_gms_internal_zzbph.zza(com_google_android_gms_internal_zzbrq), com_google_android_gms_internal_zzbsc.zzm(com_google_android_gms_internal_zzbrq), com_google_android_gms_internal_zzbsc2.zzm(com_google_android_gms_internal_zzbrq));
                    com_google_android_gms_internal_zzbsc3 = zzb != zzm ? com_google_android_gms_internal_zzbsc3.zze(com_google_android_gms_internal_zzbrq, zzb) : com_google_android_gms_internal_zzbsc3;
                }
                return com_google_android_gms_internal_zzbsc3;
            } else if ($assertionsDisabled || zzj2 > 0 || zzj <= 0) {
                return com_google_android_gms_internal_zzbsc;
            } else {
                throw new AssertionError();
            }
        } else if (!$assertionsDisabled && r1 == null) {
            throw new AssertionError();
        } else if ($assertionsDisabled || !com_google_android_gms_internal_zzbsc2.zzaaP()) {
            return com_google_android_gms_internal_zzbsc.zzaaP() ? zzbrv.zzabb() : com_google_android_gms_internal_zzbsc;
        } else {
            throw new AssertionError();
        }
    }

    public String toString() {
        String valueOf = String.valueOf(this.zzcjH);
        String valueOf2 = String.valueOf(this.zzcjI);
        String valueOf3 = String.valueOf(this.zzcjJ);
        return new StringBuilder(((String.valueOf(valueOf).length() + 55) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length()).append("RangeMerge{optExclusiveStart=").append(valueOf).append(", optInclusiveEnd=").append(valueOf2).append(", snap=").append(valueOf3).append("}").toString();
    }

    public zzbsc zzr(zzbsc com_google_android_gms_internal_zzbsc) {
        return zzb(zzbph.zzYR(), com_google_android_gms_internal_zzbsc, this.zzcjJ);
    }
}
