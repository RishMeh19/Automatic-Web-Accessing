package com.google.android.gms.internal;

import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;
import java.util.Map;

public class zzbpl {
    private static final zzbpl zzcfv = new zzbpl();
    private final Map<zzbpa, Map<String, zzbpj>> zzcfw = new HashMap();

    class C02961 implements Runnable {
        final /* synthetic */ zzbpj zzceM;

        C02961(zzbpj com_google_android_gms_internal_zzbpj) {
            this.zzceM = com_google_android_gms_internal_zzbpj;
        }

        public void run() {
            this.zzceM.interrupt();
        }
    }

    class C02972 implements Runnable {
        final /* synthetic */ zzbpj zzceM;

        C02972(zzbpj com_google_android_gms_internal_zzbpj) {
            this.zzceM = com_google_android_gms_internal_zzbpj;
        }

        public void run() {
            this.zzceM.resume();
        }
    }

    public static zzbpj zza(zzbpa com_google_android_gms_internal_zzbpa, zzbpk com_google_android_gms_internal_zzbpk, FirebaseDatabase firebaseDatabase) throws DatabaseException {
        return zzcfv.zzb(com_google_android_gms_internal_zzbpa, com_google_android_gms_internal_zzbpk, firebaseDatabase);
    }

    private zzbpj zzb(zzbpa com_google_android_gms_internal_zzbpa, zzbpk com_google_android_gms_internal_zzbpk, FirebaseDatabase firebaseDatabase) throws DatabaseException {
        zzbpj com_google_android_gms_internal_zzbpj;
        com_google_android_gms_internal_zzbpa.zzYl();
        String str = com_google_android_gms_internal_zzbpk.host;
        String str2 = com_google_android_gms_internal_zzbpk.zzaGP;
        str2 = new StringBuilder((String.valueOf(str).length() + 9) + String.valueOf(str2).length()).append("https://").append(str).append("/").append(str2).toString();
        synchronized (this.zzcfw) {
            if (!this.zzcfw.containsKey(com_google_android_gms_internal_zzbpa)) {
                this.zzcfw.put(com_google_android_gms_internal_zzbpa, new HashMap());
            }
            Map map = (Map) this.zzcfw.get(com_google_android_gms_internal_zzbpa);
            if (map.containsKey(str2)) {
                throw new IllegalStateException("createLocalRepo() called for existing repo.");
            }
            com_google_android_gms_internal_zzbpj = new zzbpj(com_google_android_gms_internal_zzbpk, com_google_android_gms_internal_zzbpa, firebaseDatabase);
            map.put(str2, com_google_android_gms_internal_zzbpj);
        }
        return com_google_android_gms_internal_zzbpj;
    }

    public static void zzd(zzbpa com_google_android_gms_internal_zzbpa) {
        zzcfv.zzf(com_google_android_gms_internal_zzbpa);
    }

    public static void zze(zzbpa com_google_android_gms_internal_zzbpa) {
        zzcfv.zzg(com_google_android_gms_internal_zzbpa);
    }

    private void zzf(final zzbpa com_google_android_gms_internal_zzbpa) {
        zzbpm zzYD = com_google_android_gms_internal_zzbpa.zzYD();
        if (zzYD != null) {
            zzYD.zzs(new Runnable(this) {
                final /* synthetic */ zzbpl zzcfy;

                public void run() {
                    synchronized (this.zzcfy.zzcfw) {
                        if (this.zzcfy.zzcfw.containsKey(com_google_android_gms_internal_zzbpa)) {
                            Object obj = 1;
                            for (zzbpj com_google_android_gms_internal_zzbpj : ((Map) this.zzcfy.zzcfw.get(com_google_android_gms_internal_zzbpa)).values()) {
                                com_google_android_gms_internal_zzbpj.interrupt();
                                Object obj2 = (obj == null || com_google_android_gms_internal_zzbpj.zzZc()) ? null : 1;
                                obj = obj2;
                            }
                            if (obj != null) {
                                com_google_android_gms_internal_zzbpa.stop();
                            }
                        }
                    }
                }
            });
        }
    }

    private void zzg(final zzbpa com_google_android_gms_internal_zzbpa) {
        zzbpm zzYD = com_google_android_gms_internal_zzbpa.zzYD();
        if (zzYD != null) {
            zzYD.zzs(new Runnable(this) {
                final /* synthetic */ zzbpl zzcfy;

                public void run() {
                    synchronized (this.zzcfy.zzcfw) {
                        if (this.zzcfy.zzcfw.containsKey(com_google_android_gms_internal_zzbpa)) {
                            for (zzbpj resume : ((Map) this.zzcfy.zzcfw.get(com_google_android_gms_internal_zzbpa)).values()) {
                                resume.resume();
                            }
                        }
                    }
                }
            });
        }
    }

    public static void zzk(zzbpj com_google_android_gms_internal_zzbpj) {
        com_google_android_gms_internal_zzbpj.zzs(new C02961(com_google_android_gms_internal_zzbpj));
    }

    public static void zzl(zzbpj com_google_android_gms_internal_zzbpj) {
        com_google_android_gms_internal_zzbpj.zzs(new C02972(com_google_android_gms_internal_zzbpj));
    }
}
