package com.google.android.gms.internal;

import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class zzbvb {
    private final List<zzbvt> zzcqV = new ArrayList();
    private zzbwb zzcrf = zzbwb.zzcrP;
    private zzbvq zzcrg = zzbvq.DEFAULT;
    private zzbuz zzcrh = zzbuy.IDENTITY;
    private final Map<Type, zzbvc<?>> zzcri = new HashMap();
    private final List<zzbvt> zzcrj = new ArrayList();
    private int zzcrk = 2;
    private int zzcrl = 2;
    private boolean zzcrm = true;

    private void zza(String str, int i, int i2, List<zzbvt> list) {
        Object com_google_android_gms_internal_zzbuv;
        if (str != null && !"".equals(str.trim())) {
            com_google_android_gms_internal_zzbuv = new zzbuv(str);
        } else if (i != 2 && i2 != 2) {
            com_google_android_gms_internal_zzbuv = new zzbuv(i, i2);
        } else {
            return;
        }
        list.add(zzbvr.zza(zzbww.zzq(Date.class), com_google_android_gms_internal_zzbuv));
        list.add(zzbvr.zza(zzbww.zzq(Timestamp.class), com_google_android_gms_internal_zzbuv));
        list.add(zzbvr.zza(zzbww.zzq(java.sql.Date.class), com_google_android_gms_internal_zzbuv));
    }

    public zzbvb zza(Type type, Object obj) {
        boolean z = (obj instanceof zzbvo) || (obj instanceof zzbvf) || (obj instanceof zzbvc) || (obj instanceof zzbvs);
        zzbvy.zzaw(z);
        if (obj instanceof zzbvc) {
            this.zzcri.put(type, (zzbvc) obj);
        }
        if ((obj instanceof zzbvo) || (obj instanceof zzbvf)) {
            this.zzcqV.add(zzbvr.zzb(zzbww.zzl(type), obj));
        }
        if (obj instanceof zzbvs) {
            this.zzcqV.add(zzbwv.zza(zzbww.zzl(type), (zzbvs) obj));
        }
        return this;
    }

    public zzbvb zza(zzbuw... com_google_android_gms_internal_zzbuwArr) {
        for (zzbuw zza : com_google_android_gms_internal_zzbuwArr) {
            this.zzcrf = this.zzcrf.zza(zza, true, true);
        }
        return this;
    }

    public zzbvb zzadO() {
        this.zzcrm = false;
        return this;
    }

    public zzbva zzadP() {
        List arrayList = new ArrayList();
        arrayList.addAll(this.zzcqV);
        Collections.reverse(arrayList);
        arrayList.addAll(this.zzcrj);
        zza(null, this.zzcrk, this.zzcrl, arrayList);
        return new zzbva(this.zzcrf, this.zzcrh, this.zzcri, false, false, false, this.zzcrm, false, false, this.zzcrg, arrayList);
    }

    public zzbvb zzf(int... iArr) {
        this.zzcrf = this.zzcrf.zzg(iArr);
        return this;
    }
}
