package com.google.android.gms.internal;

import android.os.DeadObjectException;
import com.google.android.gms.common.api.Api.zze;

public interface zzblt extends zze {
    zzblz zzVR() throws DeadObjectException;
}
