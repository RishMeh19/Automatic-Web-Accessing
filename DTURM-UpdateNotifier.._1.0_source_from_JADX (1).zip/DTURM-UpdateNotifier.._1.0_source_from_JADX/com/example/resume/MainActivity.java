package com.example.resume;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.Settings.System;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.NotificationCompat;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity implements OnClickListener {
    String Name;
    String Pwd;
    EditText T10;
    EditText T8;
    DatabaseReference Users;
    Button f9b;
    Button b2;
    Button b3;
    Button b4;
    FirebaseDatabase database;
    int f10f = 0;
    String f11s;
    String ss;
    TextView t13;
    TextView tt;
    WebView webview;

    class C01852 implements DialogInterface.OnClickListener {
        C01852() {
        }

        public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
        }
    }

    class C01863 implements DialogInterface.OnClickListener {
        C01863() {
        }

        public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0187R.layout.activity_main);
        this.webview = (WebView) findViewById(C0187R.id.web_view);
        this.webview.setVisibility(8);
        this.tt.setMovementMethod(new ScrollingMovementMethod());
        TextView T7 = (TextView) findViewById(C0187R.id.textView7);
        this.t13 = (TextView) findViewById(C0187R.id.textView13);
        this.T8 = (EditText) findViewById(C0187R.id.editText);
        TextView T9 = (TextView) findViewById(C0187R.id.textView9);
        this.T10 = (EditText) findViewById(C0187R.id.editText2);
        this.T8.setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        this.T8.setTextColor(-1);
        this.T10.setBackgroundColor(ViewCompat.MEASURED_STATE_MASK);
        this.T10.setTextColor(-1);
        T7.setText("Enter University Roll No.");
        T9.setText("Enter Password");
        this.b2 = (Button) findViewById(C0187R.id.button2);
        this.b3 = (Button) findViewById(C0187R.id.button3);
        this.f9b = (Button) findViewById(C0187R.id.button);
        this.b2.setOnClickListener(this);
        this.b3.setOnClickListener(this);
        this.f9b.setOnClickListener(this);
    }

    public void start() {
        final MyAppli mApp = new MyAppli();
        final Context cc = this;
        this.f11s = " ";
        this.webview.getSettings().setDomStorageEnabled(true);
        this.webview.getSettings().setJavaScriptEnabled(true);
        this.webview.addJavascriptInterface(new Object() {

            class C01841 implements DialogInterface.OnClickListener {
                C01841() {
                }

                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            }

            @JavascriptInterface
            public void processHTML(String html) {
                if (html.equals("Invalid Roll Number/Password!")) {
                    AlertDialog alertDialog1 = new Builder(MainActivity.this).create();
                    alertDialog1.setTitle("");
                    alertDialog1.setMessage("Invalid Roll Number/Password!");
                    alertDialog1.setButton(-3, "OK", new C01841());
                    alertDialog1.show();
                }
                if (MainActivity.this.f10f == 1) {
                    String s1 = html.substring(html.length() - 7, html.length());
                    MainActivity.this.f11s += s1 + " ";
                    MainActivity.this.f10f = 0;
                    return;
                }
                MainActivity.this.f11s += html;
                if (!MainActivity.this.f11s.equals(mApp.getGlobalVarValue())) {
                    mApp.setGlobalVarValue(MainActivity.this.f11s);
                    NotificationCompat.Builder mBuilder = (NotificationCompat.Builder) new NotificationCompat.Builder(cc).setSmallIcon(C0187R.mipmap.ic_launcher).setLargeIcon(BitmapFactory.decodeResource(cc.getResources(), C0187R.mipmap.ic_launcher)).setAutoCancel(true).setContentTitle("DTU Resume Manager").setContentText("Resume manager has been updated").setSound(System.DEFAULT_NOTIFICATION_URI).setPriority(2);
                    mBuilder.setContentIntent(PendingIntent.getActivity(MainActivity.this, 0, new Intent(MainActivity.this, MainActivity.class), 134217728));
                    ((NotificationManager) MainActivity.this.getSystemService("notification")).notify(1, mBuilder.build());
                }
                MainActivity.this.tt.setText("Resume Manager Last Updated -: " + MainActivity.this.f11s + " ");
            }
        }, "HTMLOUT");
        this.webview.loadUrl("http://tnp.dtu.ac.in/rm_2016-17/intern/intern_login");
        this.webview.setWebViewClient(new WebViewClient() {

            class C01781 implements DialogInterface.OnClickListener {
                C01781() {
                }

                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            }

            class C01822 extends WebViewClient {

                class C01791 implements DialogInterface.OnClickListener {
                    C01791() {
                    }

                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }

                class C01812 extends WebViewClient {

                    class C01801 implements DialogInterface.OnClickListener {
                        C01801() {
                        }

                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    }

                    C01812() {
                    }

                    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                        AlertDialog alertDialog1 = new Builder(MainActivity.this).create();
                        alertDialog1.setTitle("");
                        alertDialog1.setMessage("Check Your Internet Connetion");
                        alertDialog1.setButton(-3, "OK", new C01801());
                        alertDialog1.show();
                        NotificationCompat.Builder mBuilder = (NotificationCompat.Builder) new NotificationCompat.Builder(cc).setSmallIcon(C0187R.mipmap.ic_launcher).setAutoCancel(true).setContentTitle("DTU Resume Manager").setContentText("Application Stopped: Check Your Internet Connetion").setSound(System.DEFAULT_NOTIFICATION_URI).setPriority(2);
                        mBuilder.setContentIntent(PendingIntent.getActivity(MainActivity.this, 0, new Intent(MainActivity.this, MainActivity.class), 134217728));
                        ((NotificationManager) MainActivity.this.getSystemService("notification")).notify(2, mBuilder.build());
                        MainActivity.this.t13.setText("Application stopped");
                    }

                    public void onPageFinished(WebView view, String url) {
                        MainActivity.this.f10f = 1;
                        MainActivity.this.webview.loadUrl("javascript:window.HTMLOUT.processHTML(document.getElementsByClassName('time')[0].innerHTML);");
                        MainActivity.this.webview.loadUrl("javascript:window.HTMLOUT.processHTML(document.getElementsByClassName('bg-red')[0].innerHTML);");
                        MainActivity.this.start();
                    }
                }

                C01822() {
                }

                public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    AlertDialog alertDialog1 = new Builder(MainActivity.this).create();
                    alertDialog1.setTitle("");
                    alertDialog1.setMessage("Check Your Internet Connetion");
                    alertDialog1.setButton(-3, "OK", new C01791());
                    alertDialog1.show();
                    NotificationCompat.Builder mBuilder = (NotificationCompat.Builder) new NotificationCompat.Builder(cc).setSmallIcon(C0187R.mipmap.ic_launcher).setAutoCancel(true).setContentTitle("DTU Resume Manager").setContentText("Application Stopped: Check Your Internet Connetion").setSound(System.DEFAULT_NOTIFICATION_URI).setPriority(2);
                    mBuilder.setContentIntent(PendingIntent.getActivity(MainActivity.this, 0, new Intent(MainActivity.this, MainActivity.class), 134217728));
                    ((NotificationManager) MainActivity.this.getSystemService("notification")).notify(2, mBuilder.build());
                    MainActivity.this.t13.setText("Application stopped");
                }

                public void onPageFinished(WebView view, String url) {
                    MainActivity.this.webview.loadUrl("javascript:window.HTMLOUT.processHTML(document.getElementsByTagName('p')[0].innerHTML);");
                    MainActivity.this.webview.setWebViewClient(new C01812());
                }
            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                AlertDialog alertDialog1 = new Builder(MainActivity.this).create();
                alertDialog1.setTitle("");
                alertDialog1.setMessage("Check Your Internet Connetion");
                alertDialog1.setButton(-3, "OK", new C01781());
                alertDialog1.show();
                NotificationCompat.Builder mBuilder = (NotificationCompat.Builder) new NotificationCompat.Builder(cc).setSmallIcon(C0187R.mipmap.ic_launcher).setAutoCancel(true).setContentTitle("DTU Resume Manager").setContentText("Application Stopped: Check Your Internet Connetion").setSound(System.DEFAULT_NOTIFICATION_URI).setPriority(1);
                mBuilder.setContentIntent(PendingIntent.getActivity(MainActivity.this, 0, new Intent(MainActivity.this, MainActivity.class), 134217728));
                ((NotificationManager) MainActivity.this.getSystemService("notification")).notify(2, mBuilder.build());
                MainActivity.this.t13.setText("Application stopped");
            }

            public void onPageFinished(WebView view, String url) {
                MainActivity.this.f10f = 1;
                MainActivity.this.webview.loadUrl("javascript:var x=document.getElementById('intern_student_username_rollnumber').value ='" + MainActivity.this.Name + "';");
                MainActivity.this.webview.loadUrl("javascript:var x=document.getElementById('intern_student_password').value ='" + MainActivity.this.Pwd + "';");
                MainActivity.this.webview.loadUrl("javascript:document.getElementsByClassName('button button-block')[0].click();");
                MainActivity.this.webview.setWebViewClient(new C01822());
            }
        });
    }

    public void onClick(View view) {
        if (view == this.b2) {
            this.Name = this.T8.getText().toString();
            this.Pwd = this.T10.getText().toString();
            if (this.Name.equals("") || this.Pwd.equals("")) {
                AlertDialog alertDialog1 = new Builder(this).create();
                alertDialog1.setTitle("");
                alertDialog1.setMessage("Please fill the required fields");
                alertDialog1.setButton(-3, "OK", new C01852());
                alertDialog1.show();
            } else {
                this.t13.setText("Application Running");
                start();
            }
        }
        if (view == this.b3) {
            this.t13.setText("Application Stopped");
        }
        if (view == this.f9b) {
            this.Name = this.T8.getText().toString();
            this.Pwd = this.T10.getText().toString();
            if (this.Name.equals("") || this.Pwd.equals("")) {
                alertDialog1 = new Builder(this).create();
                alertDialog1.setTitle("");
                alertDialog1.setMessage("Please fill the required fields");
                alertDialog1.setButton(-3, "OK", new C01863());
                alertDialog1.show();
                return;
            }
            Intent i = new Intent(this, next.class);
            Bundle extras = new Bundle();
            extras.putString("NAME", this.Name);
            extras.putString("Pwd", this.Pwd);
            i.putExtras(extras);
            startActivity(i);
        }
    }
}
