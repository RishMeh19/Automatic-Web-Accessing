package com.example.resume;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

public class next extends AppCompatActivity {
    String Name;
    String Pwd;
    TextView f12t;
    WebView webview;

    class C01921 extends WebViewClient {

        class C01881 implements OnClickListener {
            C01881() {
            }

            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        }

        class C01912 extends WebViewClient {

            class C01891 implements OnClickListener {
                C01891() {
                }

                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            }

            class C01902 extends WebViewClient {
                C01902() {
                }

                public void onPageFinished(WebView view, String url) {
                    next.this.f12t.setText("Go back to App Screen and keep the app running in background to get Notification on Latest Update");
                }
            }

            C01912() {
            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                AlertDialog alertDialog1 = new Builder(next.this).create();
                alertDialog1.setTitle("");
                alertDialog1.setMessage("Check Your Internet Connetion or Web page is being updated");
                alertDialog1.setButton(-3, "OK", new C01891());
                alertDialog1.show();
            }

            public void onPageFinished(WebView view, String url) {
                next.this.webview.setVisibility(0);
                next.this.webview.setWebViewClient(new C01902());
            }
        }

        C01921() {
        }

        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            AlertDialog alertDialog1 = new Builder(next.this).create();
            alertDialog1.setTitle("");
            alertDialog1.setMessage("Check Your Internet Connetion or Web page is being updated");
            alertDialog1.setButton(-3, "OK", new C01881());
            alertDialog1.show();
        }

        public void onPageFinished(WebView view, String url) {
            next.this.webview.loadUrl("javascript:var x=document.getElementById('intern_student_username_rollnumber').value ='" + next.this.Name + "';");
            next.this.webview.loadUrl("javascript:var x=document.getElementById('intern_student_password').value ='" + next.this.Pwd + "';");
            next.this.webview.loadUrl("javascript:document.getElementsByClassName('button button-block')[0].click();");
            next.this.webview.setWebViewClient(new C01912());
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle extras = getIntent().getExtras();
        this.Name = extras.getString("NAME");
        this.Pwd = extras.getString("Pwd");
        setContentView((int) C0187R.layout.next);
        this.f12t = (TextView) findViewById(C0187R.id.textView3);
        this.webview = (WebView) findViewById(C0187R.id.web_view_1);
        this.webview.setVisibility(8);
        this.webview.getSettings().setDomStorageEnabled(true);
        this.webview.getSettings().setJavaScriptEnabled(true);
        this.webview.loadUrl("http://tnp.dtu.ac.in/rm_2016-17/intern/intern_login");
        this.webview.setWebViewClient(new C01921());
    }

    public void onBackPressed() {
        if (this.webview.canGoBack()) {
            this.webview.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
